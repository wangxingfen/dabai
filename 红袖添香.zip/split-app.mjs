import fs from 'fs';
import path from 'path';
import * as parser from '@babel/parser';
import traverseModule from '@babel/traverse';
import * as t from '@babel/types';
import generateModule from '@babel/generator';

const traverse = traverseModule;
const generate = generateModule;

const SRC = 'web/app.js';
const OUT = 'web/app.js';
const OUT_DIR = 'web/js';
const BAK = 'web/app.js.bak';

const code = fs.readFileSync(SRC, 'utf8');

const ast = parser.parse(code, {
  sourceType: 'module',
  plugins: [],
});

// 定位 IIFE
const importStmts = ast.program.body.filter(n => t.isImportDeclaration(n));
const iifeStmt = ast.program.body.findLast(n => t.isExpressionStatement(n));
if (!iifeStmt) throw new Error('Expected IIFE expression statement');
const callExpr = iifeStmt.expression;
if (!t.isCallExpression(callExpr)) throw new Error('Expected call expression');
const arrow = callExpr.callee;
if (!t.isArrowFunctionExpression(arrow)) throw new Error('Expected arrow function IIFE');
const iifeBody = arrow.body;
if (!t.isBlockStatement(iifeBody)) throw new Error('Expected block statement body');

// 收集所有顶层声明名（共享变量/函数）
const shared = new Set();
for (const stmt of iifeBody.body) {
  if (t.isVariableDeclaration(stmt)) {
    for (const decl of stmt.declarations) {
      if (t.isIdentifier(decl.id)) shared.add(decl.id.name);
    }
  } else if (t.isFunctionDeclaration(stmt)) {
    shared.add(stmt.id.name);
  }
}

console.log('共享变量/函数数量:', shared.size);

// 把顶层声明转为 App.xxx 赋值
const newBody = [];
for (const stmt of iifeBody.body) {
  if (t.isVariableDeclaration(stmt)) {
    for (const decl of stmt.declarations) {
      if (t.isIdentifier(decl.id)) {
        const assign = t.expressionStatement(
          t.assignmentExpression(
            '=',
            t.memberExpression(t.identifier('App'), t.identifier(decl.id.name)),
            decl.init || t.identifier('undefined')
          )
        );
        assign.leadingComments = stmt.leadingComments;
        assign.trailingComments = stmt.trailingComments;
        newBody.push(assign);
      } else {
        newBody.push(stmt);
      }
    }
  } else if (t.isFunctionDeclaration(stmt)) {
    const assign = t.expressionStatement(
      t.assignmentExpression(
        '=',
        t.memberExpression(t.identifier('App'), t.identifier(stmt.id.name)),
        t.functionExpression(
          stmt.id,
          stmt.params,
          stmt.body,
          stmt.generator,
          stmt.async
        )
      )
    );
    assign.leadingComments = stmt.leadingComments;
    assign.trailingComments = stmt.trailingComments;
    newBody.push(assign);
  } else {
    newBody.push(stmt);
  }
}

iifeBody.body = newBody;

// 替换所有对共享名称的引用为 App.xxx
traverse(ast, {
  Identifier(pathNode) {
    const name = pathNode.node.name;
    if (!shared.has(name)) return;

    if (t.isVariableDeclarator(pathNode.parent) && pathNode.parent.id === pathNode.node) return;
    if (t.isFunctionDeclaration(pathNode.parent) && pathNode.parent.id === pathNode.node) return;
    if (t.isFunctionExpression(pathNode.parent) && pathNode.parent.id === pathNode.node) return;
    if (t.isMemberExpression(pathNode.parent) && pathNode.parent.property === pathNode.node && !pathNode.parent.computed) return;
    if (t.isObjectProperty(pathNode.parent) && pathNode.parent.key === pathNode.node) return;
    if (t.isObjectMethod(pathNode.parent) && pathNode.parent.key === pathNode.node) return;
    if (t.isClassProperty(pathNode.parent) && pathNode.parent.key === pathNode.node) return;
    if (t.isClassMethod(pathNode.parent) && pathNode.parent.key === pathNode.node) return;
    if (t.isImportSpecifier(pathNode.parent)) return;
    if (t.isImportDefaultSpecifier(pathNode.parent)) return;
    if (t.isImportNamespaceSpecifier(pathNode.parent)) return;
    if (t.isExportSpecifier(pathNode.parent)) return;
    if (t.isFunction(pathNode.parent) && pathNode.parent.params.includes(pathNode.node)) return;
    if (t.isCatchClause(pathNode.parent) && pathNode.parent.param === pathNode.node) return;
    if (t.isLabeledStatement(pathNode.parent) && pathNode.parent.label === pathNode.node) return;
    if (t.isMemberExpression(pathNode.parent) && pathNode.parent.object.name === 'App' && pathNode.parent.property === pathNode.node) return;

    pathNode.replaceWith(t.memberExpression(t.identifier('App'), t.identifier(name)));
  }
});

// 生成转换后的完整 IIFE 代码
const { code: transformedCode } = generate(ast, { retainLines: false, compact: false }, code);

// 重新解析转换后的代码，以便按注释分块
const transformedAst = parser.parse(transformedCode, { sourceType: 'module' });
const tfStmt = transformedAst.program.body.findLast(n => t.isExpressionStatement(n));
if (!tfStmt) throw new Error('Transformed code missing IIFE');
const tfIifeBody = tfStmt.expression.callee.body;

// 按大段注释分块：以包含 "===========" 或 "============" 的 block comment 为分隔（大模块标题）
const chunks = [];
let currentChunk = [];
let currentName = 'start';


// 标题到 ASCII slug 的精确映射（key 为注释中提取的原始标题）
const TITLE_SLUG_MAP = {
  'start': 'start',
  'Three.js 场景': 'three_scene',
  '3D 模型加载 (GLTF / VRM)': 'model_load_gltf_vrm',
  '3D 背景场景加载': 'bg_load',
  '移动模式：选中并平移角色 / 背景模型': 'move_mode',
  '第一人称探索模式': 'fpv_mode',
  '点击角色部位交互': 'click_interact',
  '状态切换': 'state_switch',
  '低功耗模式': 'low_power',
  'WebSocket': 'websocket',
  '场景状态持久化（相机/模型位置/缩放）': 'scene_persist',
  'TTS 播放 + 口型同步': 'tts_lipsync',
  '语音录制': 'voice_record',
  'VAD 自动对话模式（无需按住，说话即录、停顿即发）': 'vad_auto',
  '消息渲染': 'messages',
  'Toast': 'toast',
  '模型管理 UI': 'model_ui',
  '背景场景管理 UI': 'bg_ui',
  '事件绑定': 'events',
  'TTS 语音合成设置': 'tts_settings',
  '启动': 'boot',
};

function chunkNameFromComment(comment) {
  const lines = comment.value.split(/\r?\n/);
  for (const line of lines) {
    const cleaned = line.replace(/^[\s\*=-]+|[\s\*=-]+$/g, '').trim();
    if (cleaned.length >= 2) return cleaned;
  }
  return '';
}

function asciiSlug(raw) {
  if (TITLE_SLUG_MAP[raw]) return TITLE_SLUG_MAP[raw];
  // fallback：清理非 ASCII
  let s = raw.replace(/[^\u0000-\u007f]+/g, '').replace(/[^a-zA-Z0-9_]+/g, '_').replace(/_+/g, '_').replace(/^_|_$/g, '');
  return s || `section_${Date.now()}`;
}

function isBigDivider(comment) {
  if (comment.type !== 'CommentBlock') return false;
  const v = comment.value;
  // 大标题特征：包含大量 = 号且不是小标题 ----
  return /={5,}/.test(v) && !/^[\s\-]+$/.test(v);
}

for (const stmt of tfIifeBody.body) {
  const leading = stmt.leadingComments || [];
  const divider = leading.find(isBigDivider);
  if (divider) {
    if (currentChunk.length > 0) {
      chunks.push({ name: currentName, body: currentChunk });
      currentChunk = [];
    }
    currentName = asciiSlug(chunkNameFromComment(divider)) || `section_${chunks.length + 1}`;
  }
  currentChunk.push(stmt);
}
if (currentChunk.length > 0) {
  chunks.push({ name: currentName, body: currentChunk });
}

console.log('分块数量:', chunks.length);
chunks.forEach((c, i) => console.log(`  ${i + 1}. ${c.name} (${c.body.length} stmts)`));

// 创建输出目录
fs.mkdirSync(OUT_DIR, { recursive: true });
fs.mkdirSync(path.join(OUT_DIR, 'core'), { recursive: true });
fs.mkdirSync(path.join(OUT_DIR, 'character'), { recursive: true });
fs.mkdirSync(path.join(OUT_DIR, 'network'), { recursive: true });
fs.mkdirSync(path.join(OUT_DIR, 'audio'), { recursive: true });
fs.mkdirSync(path.join(OUT_DIR, 'ui'), { recursive: true });

// 写出 app-state.js
const importCode = importStmts.map(s => generate(s, { retainLines: false, compact: false }).code).join('\n');
const appStateCode = `${importCode}

export const App = {
  THREE,
  GLTFLoader,
  VRMLoaderPlugin,
  VRMUtils,
};
`;
fs.writeFileSync(path.join(OUT_DIR, 'core', 'app-state.js'), appStateCode, 'utf8');

// 分块到目录的映射（key 为 ASCII slug，value 为目标目录）
const moduleDirMap = {
  'start': 'core',
  'dom': 'core',
  'state': 'core',
  'three_scene': 'core',
  'procedural_char': 'character',
  '3d_model_load_gltf_vrm': 'character',
  'bg_load': 'character',
  'move_mode_select_pan_char_bg_model': 'character',
  'fpv_mode': 'character',
  'click_interact': 'character',
  'state_switch': 'core',
  'low_power': 'core',
  'websocket': 'network',
  'scene_persist_camera_model_pos_scale': 'core',
  'tts_play_lipsync': 'audio',
  'voice_record': 'audio',
  'vad_auto_nohold_speak_record_stop_send': 'audio',
  'messages': 'ui',
  'toast': 'ui',
  'model_ui': 'ui',
  'bg_ui': 'ui',
  'events': 'ui',
  'tts_settings': 'audio',
  'boot': 'core',
};

// 为每个分块生成模块文件
const modules = [];

for (let i = 0; i < chunks.length; i++) {
  const chunk = chunks[i];
  const dirName = moduleDirMap[chunk.name] || 'core';
  fs.mkdirSync(path.join(OUT_DIR, dirName), { recursive: true });
  const safeName = `${String(i + 1).padStart(2, '0')}_${chunk.name || 'chunk'}`;
  const fileName = `${safeName}.js`;
  const filePath = path.join(OUT_DIR, dirName, fileName);

  const block = t.blockStatement(chunk.body);
  // 在每个模块函数内解构 App 上的 Three.js 相关对象，保持原代码中直接使用 THREE 等名称的写法
  const localBindings = t.variableDeclaration('const', [
    t.variableDeclarator(
      t.objectPattern([
        t.objectProperty(t.identifier('THREE'), t.identifier('THREE')),
        t.objectProperty(t.identifier('GLTFLoader'), t.identifier('GLTFLoader')),
        t.objectProperty(t.identifier('VRMLoaderPlugin'), t.identifier('VRMLoaderPlugin')),
        t.objectProperty(t.identifier('VRMUtils'), t.identifier('VRMUtils')),
      ]),
      t.identifier('App')
    )
  ]);
  block.body.unshift(localBindings);
  const func = t.functionExpression(
    t.identifier('init'),
    [t.identifier('App')],
    block,
    false,
    false
  );
  const exportDefault = t.exportDefaultDeclaration(func);
  const chunkAst = t.file(t.program([exportDefault]));

  const { code: chunkCode } = generate(chunkAst, { retainLines: false, compact: false });
  fs.writeFileSync(filePath, chunkCode, 'utf8');
  modules.push({ fileName, dir: dirName, chunkName: chunk.name || 'chunk', safeName });
}

// 生成新的 app.js 入口
const importLines = modules.map(m => {
  const varName = `init_${m.safeName}`;
  const importPath = `./js/${m.dir}/${m.fileName}`;
  return `import ${varName} from '${importPath}';`;
}).join('\n');

const callLines = modules.map(m => `init_${m.safeName}(App);`).join('\n');

const appCode = `import { App } from './js/core/app-state.js';

${importLines}

${callLines}

// DEBUG expose
Object.defineProperty(window, '_App', { get: () => App });
`;

// 写入新 app.js
fs.writeFileSync(OUT, appCode, 'utf8');

console.log('完成：');
console.log(`  源文件: ${SRC}`);
console.log(`  入口: ${OUT}`);
console.log(`  模块: ${OUT_DIR}`);
