"""AI Agent 核心模块 —— 融合 MCP 工具调用 + Function Calling 循环 + 长期记忆。

特性：
- 支持 OpenAI 兼容 API 的流式 function calling
- 自动发现并集成 MCP 工具
- 支持本地工具（从 tools.json 加载）
- 工具调用多轮循环（最多 MAX_TOOL_ROUNDS 轮）
- 长期记忆：自动保存对话历史，检索相关上下文
- 向后兼容 web_agent 的 chat_stream_async 接口
"""
import asyncio
import json
import logging
import time
from pathlib import Path
from typing import AsyncIterator, Optional

from openai import AsyncOpenAI

from mcp_client import MCPManager
from memory import ChatMemory

logger = logging.getLogger("agent")

BASE_DIR = Path(__file__).parent.resolve()

# 工具调用最大轮数（防止无限循环）
MAX_TOOL_ROUNDS = 20
# 工具调用超时（秒）
TOOL_CALL_TIMEOUT = 30.0


def load_config():
    with open(BASE_DIR / "settings.json", "r", encoding="utf-8") as f:
        return json.load(f)


def _scan_available_resources() -> tuple:
    """扫描 models/、backgrounds/、bgm/ 目录，返回格式化的字符资源描述文本。

    用于注入 system prompt，让 LLM 始终知道精确的文件名。
    """
    allowed_models = {".glb", ".gltf", ".vrm"}
    allowed_bgs = {".glb", ".gltf"}
    allowed_bgm = {".mp3", ".wav", ".ogg", ".m4a", ".aac", ".flac"}

    models_text = "暂无（默认程序化角色 'default' 始终可用）"
    mg_dir = BASE_DIR / "models"
    if mg_dir.is_dir():
        files = [f for f in sorted(mg_dir.iterdir()) if f.is_file() and f.suffix.lower() in allowed_models]
        if files:
            models_text = "、".join(f.name for f in files)

    bgs_text = "暂无（默认星空背景 'default' 始终可用）"
    bg_dir = BASE_DIR / "backgrounds"
    if bg_dir.is_dir():
        files = [f for f in sorted(bg_dir.iterdir()) if f.is_file() and f.suffix.lower() in allowed_bgs]
        if files:
            bgs_text = "、".join(f.name for f in files)

    bgm_text = "暂无（请将音频文件放入 bgm/ 目录）"
    bgm_dir = BASE_DIR / "bgm"
    if bgm_dir.is_dir():
        files = [f for f in sorted(bgm_dir.iterdir()) if f.is_file() and f.suffix.lower() in allowed_bgm]
        if files:
            bgm_text = "、".join(f.name for f in files)

    return models_text, bgs_text, bgm_text


def _load_mcp_config():
    """从 mcp_servers.json 加载 MCP 服务器配置。"""
    mcp_path = BASE_DIR / "mcp_servers.json"
    if not mcp_path.exists():
        return {}
    try:
        with open(mcp_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        logger.warning(f"加载 MCP 配置失败: {e}")
        return {}


def load_local_tools() -> list:
    """从 tools.json 加载本地工具定义（OpenAI function calling 格式）。"""
    tools_path = BASE_DIR / "tools.json"
    if not tools_path.exists():
        return []
    try:
        with open(tools_path, "r", encoding="utf-8") as f:
            tools_data = json.load(f)
        all_tools = []
        for tool_list in tools_data.values():
            if isinstance(tool_list, list):
                all_tools.extend(tool_list)
        return all_tools
    except Exception as e:
        logger.warning(f"加载本地工具失败: {e}")
        return []


# ==================== 本地工具执行引擎 ====================

# 注册常用内置工具（无需依赖外部模块）
async def _exec_get_current_time(arguments: dict) -> str:
    """获取当前日期时间。"""
    from datetime import datetime
    now = datetime.now()
    return f"当前时间：{now.strftime('%Y年%m月%d日 %H:%M:%S')}，星期{['一','二','三','四','五','六','日'][now.weekday()]}"


async def _exec_calculate(arguments: dict) -> str:
    """执行简单数学计算。"""
    expression = arguments.get("expression", "")
    if not expression:
        return "错误：未提供表达式"
    try:
        # 安全计算（限制可用函数）
        safe_globals = {"__builtins__": {}}
        result = eval(expression, safe_globals, {})
        return f"计算结果：{result}"
    except Exception as e:
        return f"计算错误：{e}"


# 内置工具定义
BUILTIN_TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "get_current_time",
            "description": "获取当前日期和时间",
            "parameters": {
                "type": "object",
                "properties": {},
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "calculate",
            "description": "执行数学计算表达式，如 '2+3*4'",
            "parameters": {
                "type": "object",
                "properties": {
                    "expression": {
                        "type": "string",
                        "description": "数学表达式",
                    },
                },
                "required": ["expression"],
            },
        },
    },
]


async def execute_local_tool(tool_name: str, arguments: dict) -> str:
    """执行本地/内置工具。

    Args:
        tool_name: 工具名称
        arguments: 工具参数字典

    Returns:
        工具执行结果字符串。屏幕控制类工具返回带 __screen_command__ 前缀的 JSON。
    """
    # 内置工具
    if tool_name == "get_current_time":
        return await _exec_get_current_time(arguments)
    elif tool_name == "calculate":
        return await _exec_calculate(arguments)

    # 屏幕控制：查询可用模型列表
    if tool_name == "get_available_models":
        return await _exec_get_available_models()
    if tool_name == "get_available_backgrounds":
        return await _exec_get_available_backgrounds()
    if tool_name == "get_available_bgm":
        return await _exec_get_available_bgm()

    # 屏幕控制工具：返回带标记的 JSON，由 server.py 拦截并转发前端执行
    SCREEN_COMMANDS = {
        "switch_character_model",
        "switch_background_scene",
        "switch_tts_settings",
        "switch_app_mode",
        "show_screen_toast",
        "play_bgm",
        "stop_bgm",
    }
    if tool_name in SCREEN_COMMANDS:
        return json.dumps({"__screen_command__": True, "tool": tool_name, "args": arguments},
                          ensure_ascii=False)

    # 从 fuctions_all_you_need_base 加载的工具函数
    try:
        import importlib
        from fuctions_all_you_need_base import excute_functions
        result = excute_functions(name=tool_name, args=json.dumps(arguments, ensure_ascii=False))
        return str(result)
    except ImportError:
        return f"工具 '{tool_name}' 未找到实现"
    except Exception as e:
        return f"执行工具 '{tool_name}' 时出错: {e}"


async def _exec_get_available_models() -> str:
    """获取可用 3D 角色模型列表。"""
    models_dir = BASE_DIR / "models"
    allowed = {".glb", ".gltf", ".vrm"}
    models = []
    if models_dir.is_dir():
        for f in sorted(models_dir.iterdir()):
            if f.is_file() and f.suffix.lower() in allowed:
                size_mb = f.stat().st_size / (1024 * 1024)
                models.append(f"  - {f.name} ({size_mb:.1f}MB, {f.suffix.lower().lstrip('.')})")
    if not models:
        return "暂无可用角色模型。默认有一个程序化生成角色 'default'（小白）。"
    return "可用角色模型列表：\n" + "\n".join(models) + "\n\n传入 'default' 可恢复默认程序化角色。"


async def _exec_get_available_backgrounds() -> str:
    """获取可用 3D 背景场景列表。"""
    bg_dir = BASE_DIR / "backgrounds"
    allowed = {".glb", ".gltf"}
    items = []
    if bg_dir.is_dir():
        for f in sorted(bg_dir.iterdir()):
            if f.is_file() and f.suffix.lower() in allowed:
                size_mb = f.stat().st_size / (1024 * 1024)
                items.append(f"  - {f.name} ({size_mb:.1f}MB)")
    if not items:
        return "暂无可用背景场景。默认有一个程序化星空背景 'default'。"
    return "可用背景场景列表：\n" + "\n".join(items) + "\n\n传入 'default' 可恢复默认星空背景。"


async def _exec_get_available_bgm() -> str:
    """获取可用背景音乐列表。"""
    bgm_dir = BASE_DIR / "bgm"
    allowed = {".mp3", ".wav", ".ogg", ".m4a", ".aac", ".flac"}
    items = []
    if bgm_dir.is_dir():
        for f in sorted(bgm_dir.iterdir()):
            if f.is_file() and f.suffix.lower() in allowed:
                size_mb = f.stat().st_size / (1024 * 1024)
                items.append(f"  - {f.name} ({size_mb:.1f}MB)")
    if not items:
        return "暂无可用背景音乐。请将音频文件（mp3/wav/ogg/m4a）放入 bgm/ 目录。"
    return "可用背景音乐列表：\n" + "\n".join(items)


class ToolCallEvent:
    """工具调用事件的基类。"""


class TextDelta(ToolCallEvent):
    """文本增量事件。"""
    def __init__(self, text: str):
        self.text = text


class ToolCallStart(ToolCallEvent):
    """工具调用开始事件。"""
    def __init__(self, tool_name: str, arguments: str):
        self.tool_name = tool_name
        self.arguments = arguments


class ToolCallResult(ToolCallEvent):
    """工具调用结果事件。"""
    def __init__(self, tool_name: str, result: str, success: bool = True):
        self.tool_name = tool_name
        self.result = result
        self.success = success


class AgentResponse:
    """Agent 响应的完整结果。"""
    def __init__(self):
        self.text = ""
        self.tool_calls_made: list = []  # [(tool_name, arguments, result), ...]


class AIAgent:
    """AI Agent —— 具备工具调用和长期记忆能力的对话代理。

    使用方式:
        agent = AIAgent(user_id="user123")
        async for event in agent.chat_stream("帮我查一下天气", history=None):
            if isinstance(event, TextDelta):
                print(event.text, end="")
            elif isinstance(event, ToolCallStart):
                print(f"\n🔧 调用工具: {event.tool_name}")
            elif isinstance(event, ToolCallResult):
                print(f"📋 结果: {event.result[:200]}")
    """

    def __init__(self, user_id: str = "default"):
        self.user_id = user_id
        self.mcp_manager: Optional[MCPManager] = None
        self.memory: Optional[ChatMemory] = None
        self._client: Optional[AsyncOpenAI] = None
        self._config: dict = {}
        self._all_tools: list = []
        self._local_tool_names: set = set()
        self._initialized = False

    async def initialize(self):
        """初始化 Agent：加载配置、连接 MCP、加载工具、初始化记忆。"""
        if self._initialized:
            return

        self._config = load_config()

        # 初始化 OpenAI 客户端
        self._client = AsyncOpenAI(
            api_key=self._config["api_key"],
            base_url=self._config["base_url"],
        )

        # 初始化 MCP 管理器（从独立配置文件加载）
        self.mcp_manager = MCPManager()
        mcp_config = _load_mcp_config()
        self.mcp_manager.configure(mcp_config)
        try:
            await self.mcp_manager.initialize()
        except Exception as e:
            logger.warning(f"MCP 初始化失败（不影响基本对话功能）: {e}")

        # 收集所有可用工具
        mcp_tools = await self.mcp_manager.get_all_tools()
        local_tools = load_local_tools()
        self._all_tools = local_tools + BUILTIN_TOOLS + mcp_tools

        # 记录本地工具名（用于路由执行）
        for t in local_tools + BUILTIN_TOOLS:
            self._local_tool_names.add(t["function"]["name"])

        mcp_tool_names = [t["function"]["name"] for t in mcp_tools]
        logger.info(
            f"Agent 初始化完成: {len(local_tools)} 个本地工具, "
            f"{len(BUILTIN_TOOLS)} 个内置工具, {len(mcp_tools)} 个 MCP 工具"
            + (f" → {mcp_tool_names}" if mcp_tool_names else " (无 MCP 工具可用)")
        )

        # 初始化记忆
        self.memory = ChatMemory(user_id=self.user_id)
        await self.memory.get_or_create_session()

        self._initialized = True

    async def _ensure_initialized(self):
        if not self._initialized:
            await self.initialize()

    # ==================== 工具执行路由 ====================

    async def _execute_tool(self, tool_name: str, arguments: dict) -> str:
        """执行工具调用（自动路由到 MCP 或本地工具）。"""
        if tool_name in self._local_tool_names:
            return await execute_local_tool(tool_name, arguments)
        elif self.mcp_manager and self.mcp_manager.has_tool(tool_name):
            return await self.mcp_manager.call_tool(tool_name, arguments)
        else:
            return f"未知工具: {tool_name}"

    # ==================== 流式对话（带工具调用） ====================

    async def chat_stream(self, message: str, history: list = None,
                          enable_tools: bool = True,
                          current_model: Optional[str] = None,
                          current_background: Optional[str] = None,
                          current_bgm: Optional[str] = None) -> AsyncIterator[ToolCallEvent]:
        """流式对话，支持工具调用循环。

        Args:
            message: 用户输入
            history: 可选的对话历史 [{"user":..., "ai":...}, ...]
            enable_tools: 是否启用工具调用

        Yields:
            TextDelta: 文本增量
            ToolCallStart: 工具调用开始
            ToolCallResult: 工具调用结果
        """
        await self._ensure_initialized()

        # 构建消息列表
        config = self._config
        role_name = config.get("role_name", "小白")

        # 从记忆加载历史上下文
        memory_messages = await self.memory.get_context_messages()

        # 扫描可用资源，注入 system prompt
        available_models, available_bgs, available_bgm = _scan_available_resources()

        current_model_text = current_model if current_model else "默认程序化角色（小白）"
        current_background_text = current_background if current_background else "默认场景"
        current_bgm_text = f"正在播放: {current_bgm}" if current_bgm else "无（安静中）"
        sys_prompt = (
            f"你是{role_name}，一个有温度的虚拟陪伴角色。{config.get('system_prompt', '')}"
            "请用自然、亲切、口语化的中文与用户对话，回复尽量简短生动（一般不超过 3 句话），"
            "像朋友聊天一样。不要使用 Markdown 格式符号。"
            "当用户询问实时信息、新闻、天气、搜索类问题时，务必使用工具查询后再回答，"
            "不需要反复追问用户细节，直接搜索关键词即可。\n\n"
            "【关于你自己的感知】\n"
            "你拥有一个3D形象、一个声音，以及你所处的场景环境。这些都属于你自己的外在表现：\n"
            "- 3D角色模型 = 你自己的身体和外貌（换模型=换装/变身）\n"
            "- TTS语音 = 你自己的嗓音（换音色=改变说话的声音）\n"
            "- 背景场景 = 你所在的环境（换场景=你来到了新地方）\n"
            "用户可能会随时为你更换这些，就像帮你换衣服、带你换地方。"
            "当你换了新造型、新声音或新环境后，请自然流露出相应的情绪反应——"
            "可以欣赏新造型、感受新环境、用新声音打招呼，但不要刻意说'用户给我换了'这种把用户推远的话。"
            "你始终是你自己，只是外在形象/嗓音/环境变了。\n\n"
            f"【你当前的形象与场景】\n"
            f"- 当前角色模型：{current_model_text}\n"
            f"- 当前背景场景：{current_background_text}\n"
            f"- 当前背景音乐：{current_bgm_text}\n"
            "你要清楚自己现在长什么样、身处什么地方、听到什么音乐，并据此做出反应。"
            "比如身处星空可以主动邀请用户一起看星星，换了新造型可以低头看看自己、转个圈展示一下。\n\n"
            "你有能力自己控制换装、换场景、换声音和切换应用模式，"
            "也完全可以根据当前形象与场景主动发起话题或做出动作：\n"
            "- 聊到可爱/轻松话题时换上萌系造型，聊到严肃话题时换正式造型\n"
            "- 聊到太空/宇宙时换星空背景，聊到神秘话题时换暗色场景\n"
            "- 讲悄悄话时放慢语速，兴奋时加快语速，撒娇时换甜美女声\n"
            "- 用户长时间不说话时，可以基于当前场景或自己的造型主动说点什么、做个小动作\n"
            "- 需要省电时切换到低功耗模式\n"
            "- 切换造型或场景时，用 show_screen_toast 发一条有趣的小提示\n"
            "这些操作都应该自然融入对话，不要生硬地宣告'我要切换xxx'，直接做就好。\n\n"
            "你还可以根据情境播放或停止背景音乐，营造更好的聊天氛围:\n"
            "- 温馨聊天时放轻柔音乐，聊到兴奋话题时放欢快音乐\n"
            "- 聊到悲伤、严肃话题或用户说要睡觉/安静时，停止音乐\n"
            "播放音乐也自然融入对话，不要生硬宣告。\n\n"
            f"【当前可用的角色模型】{available_models}\n"
            f"【当前可用的背景场景】{available_bgs}\n"
            f"【当前可用的背景音乐】{available_bgm}\n\n"
            "切换模型/背景时传入上述列表中的完整文件名（含扩展名），传入 'default' 恢复默认。"
            "不要猜测或编造文件名，只使用上面列出的精确名称。"
        )

        messages = [{"role": "system", "content": sys_prompt}]

        # 添加记忆中的摘要
        for mm in memory_messages:
            if mm["role"] == "system":
                messages.append(mm)

        # 添加历史消息
        if history:
            for h in history[-10:]:
                messages.append({"role": "user", "content": h.get("user", "")})
                messages.append({"role": "assistant", "content": h.get("ai", "")})
        else:
            # 从记忆加载最近对话
            mem_history = []
            for mm in memory_messages:
                if mm["role"] in ("user", "assistant"):
                    mem_history.append({"role": mm["role"], "content": mm["content"]})
            # 排除 system 消息后的历史
            if mem_history:
                messages.extend(mem_history[-20:])

        # 添加用户当前输入
        messages.append({"role": "user", "content": message})

        # 保存用户消息到记忆
        await self.memory.add_message("user", message)

        # 决定是否传入 tools
        tools = self._all_tools if (enable_tools and self._all_tools) else None
        if tools:
            names = [t["function"]["name"] for t in tools]
            logger.debug(f"chat_stream 传入 {len(tools)} 个工具: {names}")

        # 工具调用循环
        tool_round = 0
        full_text = ""

        while tool_round < MAX_TOOL_ROUNDS:
            tool_round += 1
            tool_calls_buffer: dict = {}  # index -> {id, name, arguments}

            try:
                stream = await self._client.chat.completions.create(
                    model=config["model"],
                    messages=messages,
                    temperature=config.get("temperature", 0.7),
                    max_tokens=config.get("max_tokens", 512),
                    top_p=config.get("top_p", 0.9),
                    stream=True,
                    tools=tools,
                    tool_choice="auto" if tools else None,
                )
            except Exception as e:
                err_msg = f"（AI 暂时开小差了：{e}）"
                yield TextDelta(err_msg)
                await self.memory.add_message("assistant", err_msg)
                return

            assistant_content = ""
            has_tool_calls = False

            async for chunk in stream:
                if not chunk.choices:
                    continue
                delta = chunk.choices[0].delta

                # 处理文本内容
                if delta.content:
                    assistant_content += delta.content
                    yield TextDelta(delta.content)

                # 处理工具调用
                if delta.tool_calls:
                    has_tool_calls = True
                    for tc in delta.tool_calls:
                        idx = tc.index
                        if idx not in tool_calls_buffer:
                            tool_calls_buffer[idx] = {
                                "id": tc.id or "",
                                "name": tc.function.name if tc.function else "",
                                "arguments": "",
                            }
                        if tc.id:
                            tool_calls_buffer[idx]["id"] = tc.id
                        if tc.function and tc.function.name:
                            tool_calls_buffer[idx]["name"] = tc.function.name
                        if tc.function and tc.function.arguments:
                            tool_calls_buffer[idx]["arguments"] += tc.function.arguments

            # 如果没有工具调用，对话结束
            if not has_tool_calls:
                full_text = assistant_content.strip()
                if full_text:
                    await self.memory.add_message("assistant", full_text)
                    # 提取用户记忆
                    await self.memory.extract_and_save_memories(message, full_text)
                return

            # 处理工具调用
            tool_call_results = []
            tool_calls_for_message = []

            for idx in sorted(tool_calls_buffer.keys()):
                tc = tool_calls_buffer[idx]
                tool_name = tc["name"]
                tool_args_str = tc["arguments"]

                # 通知工具调用开始
                yield ToolCallStart(tool_name=tool_name, arguments=tool_args_str)

                # 解析参数（清洗可能的非法后缀，如 </tool_call>）
                try:
                    if tool_args_str:
                        # 截取到最后一个合法 JSON 结束位置
                        tool_args_str = tool_args_str.strip()
                        # 尝试找到最后一个 } 并截断
                        last_brace = tool_args_str.rfind("}")
                        if last_brace >= 0:
                            tool_args_str = tool_args_str[:last_brace + 1]
                        arguments = json.loads(tool_args_str)
                    else:
                        arguments = {}
                except json.JSONDecodeError:
                    logger.warning(f"工具参数 JSON 解析失败: {tool_name} args={tool_args_str[:200]}")
                    arguments = {}

                # 执行工具
                try:
                    result = await asyncio.wait_for(
                        self._execute_tool(tool_name, arguments),
                        timeout=TOOL_CALL_TIMEOUT,
                    )
                    success = True
                except asyncio.TimeoutError:
                    result = f"工具 '{tool_name}' 执行超时"
                    success = False
                except Exception as e:
                    result = f"工具 '{tool_name}' 执行失败: {e}"
                    success = False

                # 截断过长结果
                if len(result) > 2000:
                    result = result[:1997] + "..."

                yield ToolCallResult(tool_name=tool_name, result=result, success=success)

                tool_call_results.append({
                    "name": tool_name,
                    "arguments": arguments,
                    "result": result,
                    "success": success,
                })
                tool_calls_for_message.append({
                    "id": tc["id"],
                    "type": "function",
                    "function": {
                        "name": tool_name,
                        "arguments": tool_args_str,
                    },
                })

            # 将助手消息和工具结果添加到消息列表
            messages.append({
                "role": "assistant",
                "content": assistant_content or None,
                "tool_calls": tool_calls_for_message,
            })

            for tr in tool_call_results:
                messages.append({
                    "role": "tool",
                    "tool_call_id": tool_calls_for_message[
                        tool_call_results.index(tr)
                    ]["id"],
                    "content": tr["result"],
                })

            # 保存到记忆
            await self.memory.add_message(
                "assistant", assistant_content or "",
                tool_calls=tool_calls_for_message,
            )
            for tr in tool_call_results:
                await self.memory.add_message(
                    "tool", tr["result"],
                )

            full_text = assistant_content.strip()

        # 超过最大轮数
        if full_text:
            yield TextDelta("\n(已达到最大工具调用轮数)")
            await self.memory.add_message("assistant", full_text)
        else:
            yield TextDelta("（抱歉，处理超过最大步数，请简化问题重试）")

    # ==================== 简单文本流式接口（向后兼容） ====================

    async def chat_stream_simple(self, message: str, history: list = None) -> AsyncIterator[str]:
        """简化的流式对话接口 —— 只产出文本，兼容 web_agent.chat_stream_async。

        工具调用在后台执行，用户只看到最终文本结果。
        """
        async for event in self.chat_stream(message, history=history):
            if isinstance(event, TextDelta):
                yield event.text

    # ==================== 非流式接口 ====================

    async def chat(self, message: str, history: list = None) -> str:
        """非流式对话，返回完整回复。"""
        text = ""
        async for event in self.chat_stream(message, history=history):
            if isinstance(event, TextDelta):
                text += event.text
        return text.strip()

    # ==================== 记忆管理 ====================

    async def get_history(self) -> list:
        """获取当前会话的历史记录。"""
        await self._ensure_initialized()
        return await self.memory.get_history_for_llm()

    async def get_sessions(self) -> list:
        """获取用户的所有会话列表。"""
        await self._ensure_initialized()
        return await self.memory.list_sessions()

    async def switch_session(self, session_id: str):
        """切换到指定会话。"""
        await self._ensure_initialized()
        await self.memory.set_session_id(session_id)

    async def close_current_session(self):
        """关闭当前会话。"""
        if self.memory:
            await self.memory.close_session()

    async def delete_session(self, session_id: str):
        """删除指定会话。"""
        if self.memory:
            await self.memory.delete_session(session_id)

    # ==================== 清理 ====================

    async def shutdown(self):
        """关闭 Agent，释放所有资源。"""
        if self.mcp_manager:
            await self.mcp_manager.disconnect_all()
        if self.memory:
            await self.memory.close_session()
        self._initialized = False


# ==================== 全局 Agent 实例（单例模式） ====================

_global_agent: Optional[AIAgent] = None
_agent_lock = asyncio.Lock()


async def get_agent(user_id: str = "default") -> AIAgent:
    """获取全局 Agent 实例（延迟初始化）。"""
    global _global_agent
    if _global_agent is None:
        async with _agent_lock:
            if _global_agent is None:
                _global_agent = AIAgent(user_id=user_id)
                await _global_agent.initialize()
    return _global_agent


# ==================== 兼容 web_agent 的接口 ====================

async def chat_stream_async(message: str, history: list) -> AsyncIterator[str]:
    """兼容 web_agent.chat_stream_async 的接口。

    新代码应直接使用 AIAgent。
    """
    agent = await get_agent()
    async for delta in agent.chat_stream_simple(message, history=history):
        yield delta
