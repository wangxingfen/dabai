"""3D 虚拟 AI 角色陪聊 —— FastAPI 服务器

特性：
- WebSocket 实时双向通信（文本 + 语音）
- 语音转文字 (SiliconFlow SenseVoiceSmall，API 失败自动降级 faster-whisper 本地模型)
- 文字转语音 (edge-tts)
- 3D 模型导入与管理 (glb/gltf/vrm)
- 静态前端托管 (web/)
- 绑定 0.0.0.0 实现局域网手机访问
- MCP 工具调用 + Function Calling
- 长期记忆（SQLite 持久化）
"""
import asyncio
import base64
import json
import logging
import os
import re
import socket
import subprocess
import sys
import tempfile
import threading
import uuid
from pathlib import Path
from typing import List, Optional

import edge_tts
import uvicorn
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, UploadFile, File, HTTPException
from starlette.websockets import WebSocketState
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from agent import AIAgent, TextDelta, ToolCallStart, ToolCallResult

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(name)s] %(message)s")
logger = logging.getLogger("server")

BASE_DIR = Path(__file__).parent.resolve()
WEB_DIR = BASE_DIR / "web"
AUDIO_DIR = BASE_DIR / "audio_cache"
MODELS_DIR = BASE_DIR / "models"
BACKGROUNDS_DIR = BASE_DIR / "backgrounds"
BGM_DIR = BASE_DIR / "bgm"
AUDIO_DIR.mkdir(exist_ok=True)
MODELS_DIR.mkdir(exist_ok=True)
BACKGROUNDS_DIR.mkdir(exist_ok=True)
BGM_DIR.mkdir(exist_ok=True)

app = FastAPI(title="3D AI 陪聊")

# 托管生成的音频文件
app.mount("/audio", StaticFiles(directory=str(AUDIO_DIR)), name="audio")
# 托管上传的 3D 模型
app.mount("/models", StaticFiles(directory=str(MODELS_DIR)), name="models")
# 托管上传的 3D 背景模型
app.mount("/backgrounds", StaticFiles(directory=str(BACKGROUNDS_DIR)), name="backgrounds")
# 托管背景音乐文件
app.mount("/bgm", StaticFiles(directory=str(BGM_DIR)), name="bgm")
# 托管前端静态资源 (css/js)
app.mount("/static", StaticFiles(directory=str(WEB_DIR)), name="static")

# 允许的 3D 模型扩展名
ALLOWED_MODEL_EXTS = {".glb", ".gltf", ".vrm"}
MAX_MODEL_SIZE = 80 * 1024 * 1024  # 80MB


def get_lan_ip() -> str:
    """获取本机局域网 IP"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def load_config():
    with open(BASE_DIR / "settings.json", "r", encoding="utf-8") as f:
        return json.load(f)


# ---------- TTS（多引擎） ----------
DEFAULT_VOICE = "zh-CN-YunxiNeural"  # 男声云稀，亲切自然

# 句子结束符（用于流式分句 TTS）
SENTENCE_END = re.compile(r"[。！？!?\n…；;~]")

# 全局 TTS 配置（运行时可被前端 /api/tts/config 修改，持久化到 tts_config.json）
TTS_CONFIG_FILE = BASE_DIR / "tts_config.json"
DEFAULT_TTS_CONFIG = {
    "engine": "edge_tts",                       # "edge_tts" | "gpt_sovits"
    "edge_voice": DEFAULT_VOICE,                # edge_tts 音色 ShortName
    "edge_rate": "+8%",                         # 语速
    "gptsovits_url": "http://127.0.0.1:7860/",  # GPT-SoVITS API 服务地址
    "gptsovits_ref_audio": "",                  # 参考音频绝对路径
    "gptsovits_character": "星见雅",
}

def _load_tts_config():
    """从文件加载 TTS 配置，不存在则用默认值。"""
    if TTS_CONFIG_FILE.exists():
        try:
            with open(TTS_CONFIG_FILE, "r", encoding="utf-8") as f:
                saved = json.load(f)
            cfg = {**DEFAULT_TTS_CONFIG, **saved}
            return cfg
        except Exception:
            pass
    return dict(DEFAULT_TTS_CONFIG)

def _save_tts_config(cfg: dict):
    """保存 TTS 配置到文件。"""
    try:
        with open(TTS_CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.warning(f"保存 TTS 配置失败: {e}")

tts_config = _load_tts_config()

# 缓存 edge_tts 中文音色列表
_edge_voices_cache: list | None = None


def cleanup_old_audio():
    """清理旧音频文件，最多保留 5 个（兜底，正常流程已即时销毁）"""
    try:
        files = sorted(AUDIO_DIR.glob("*"), key=lambda p: p.stat().st_mtime)
        for old in files[:-5]:
            old.unlink(missing_ok=True)
    except Exception:
        pass


async def get_edge_voices() -> list:
    """获取 edge_tts 中文音色列表（带缓存）"""
    global _edge_voices_cache
    if _edge_voices_cache is None:
        voices = await edge_tts.list_voices()
        _edge_voices_cache = [
            {
                "name": v["ShortName"],
                "locale": v["Locale"],
                "gender": v.get("Gender", ""),
                "friendly": f"{v.get('Gender','')}声 · {v['ShortName'].split('-')[-1].replace('Neural','')}"
            }
            for v in voices if v["Locale"].startswith("zh-")
        ]
    return _edge_voices_cache


async def generate_tts_edge(text: str, voice: str, rate: str):
    """edge_tts 在线合成 mp3，返回 (audio_bytes, mime_type) 或 None。
    
    音频数据直接返回，不保留持久文件。"""
    clean = re.sub(r"[*_`#>\-\[\]\(\)]", "", text).strip()
    if not clean:
        return None
    # 使用临时文件生成，读完后立即删除
    audio_id = f"{uuid.uuid4().hex}.mp3"
    audio_path = AUDIO_DIR / audio_id
    try:
        communicate = edge_tts.Communicate(clean, voice, rate=rate, volume="+0%")
        await communicate.save(str(audio_path))
        data = audio_path.read_bytes()
        return (data, "audio/mpeg")
    finally:
        try:
            audio_path.unlink(missing_ok=True)
        except Exception:
            pass


def resolve_ref_audio_by_character(character: str) -> str:
    """按角色名从 gpt_sovits.json 读参考音频路径（对齐 voice.py 的 index_tts 逻辑）。

    查找位置（按顺序）：
      1. tools/gpt_sovits/gpt_sovits.json  （voice.py 原路径）
      2. gpt_sovits.json                   （项目根目录）
    json 格式：{ "角色名": { "ref_audio_path": "绝对路径" } }
    """
    if not character:
        return ""
    for rel in ("tools/gpt_sovits/gpt_sovits.json", "gpt_sovits.json"):
        p = BASE_DIR / rel
        if p.exists():
            try:
                with open(p, "r", encoding="utf-8") as f:
                    data = json.load(f)
                return data.get(character, {}).get("ref_audio_path", "")
            except Exception as e:
                print(f"[GPT-SoVITS] 读取 {rel} 失败: {e}")
    return ""


def generate_tts_gptsovits(text: str, ref_audio: str, url: str, character: str = ""):
    """调用本地 GPT-SoVITS（gradio 7860）合成 wav，返回 (audio_bytes, mime_type) 或 None。

    参考音频优先级：显式传入 ref_audio > 按角色名查 gpt_sovits.json > None（服务端默认）。
    音频数据直接返回，不保留持久文件。
    """
    from gradio_client import Client as GradioClient, handle_file
    # 没显式传 ref_audio 时，按角色名从配置文件查（对齐 voice.py）
    if not ref_audio or not os.path.exists(ref_audio):
        ref_audio = resolve_ref_audio_by_character(character)
    client = GradioClient(url)
    prompt = handle_file(ref_audio) if (ref_audio and os.path.exists(ref_audio)) else None
    result = client.predict(
        prompt=prompt,
        text=text,
        infer_mode="批次推理",
        max_text_tokens_per_sentence=120,
        sentences_bucket_max_size=4,
        param_5=True, param_6=0.8, param_7=30, param_8=1,
        param_9=0, param_10=3, param_11=10, param_12=600,
        api_name="/gen_single",
    )
    # result 通常是 [text_output, audio_path, ...]
    src = result[1] if isinstance(result, (list, tuple)) else result.get("value")
    if not src or not os.path.exists(src):
        raise RuntimeError("GPT-SoVITS 未返回有效音频")
    # 直接读二进制，不复制到 audio_cache
    with open(src, "rb") as f:
        data = f.read()
    return (data, "audio/wav")


async def generate_tts(text: str):
    """根据当前引擎生成 TTS，返回 (audio_bytes, mime_type) 或 None，失败自动回退 edge_tts。"""
    engine = tts_config.get("engine", "edge_tts")
    try:
        if engine == "gpt_sovits":
            return await asyncio.to_thread(
                generate_tts_gptsovits,
                text,
                tts_config["gptsovits_ref_audio"],
                tts_config["gptsovits_url"],
                tts_config.get("gptsovits_character", ""),
            )
        return await generate_tts_edge(text, tts_config["edge_voice"], tts_config["edge_rate"])
    except Exception as e:
        print(f"[TTS] {engine} 失败，回退 edge_tts: {e}")
        try:
            return await generate_tts_edge(text, DEFAULT_VOICE, "+8%")
        except Exception as e2:
            print(f"[TTS] edge_tts 也失败: {e2}")
            return None


# ---------- STT ----------
# 本地语音识别模型（懒加载，仅首次使用或 API 失败时初始化）
_local_stt_model = None
_local_stt_lock = threading.Lock()


def _is_valid_audio(path: str) -> bool:
    """快速检查文件是否可能是音频（基于大小和常见魔数）。

    只过滤明显非音频的文件（太小/空文件）。移动端 MediaRecorder
    可能产生非标准封装格式，即使魔数不匹配也交给 ffmpeg 自行判断。
    """
    try:
        file_size = os.path.getsize(path)
        if file_size < 32:
            print(f"[ffmpeg] 跳过空文件: {file_size} 字节")
            return False
        return True  # 放行所有 > 32 字节的文件，ffmpeg 会自动检测格式
    except Exception:
        return False


def _mime_to_ext(mime_type: str) -> str:
    """将 MIME 类型映射为文件扩展名。"""
    mime_lower = (mime_type or "").lower()
    if "ogg" in mime_lower or "opus" in mime_lower:
        return ".ogg"
    if "mp4" in mime_lower or "m4a" in mime_lower or "aac" in mime_lower:
        return ".m4a"
    if "wav" in mime_lower:
        return ".wav"
    return ".webm"


def convert_to_wav(input_path: str, output_path: str) -> bool:
    """用 ffmpeg 把任意音频格式转成 16k 单声道 wav，并做降噪 + 响度归一化提升识别率。

    滤波链：
    - highpass=f=80      去掉低频嗡嗡（电源/空调/手震）
    - lowpass=f=8000     去掉高频无用信号（16k 采样上限 8k）
    - dynaudnorm         动态响度归一化，放大安静部分，小声说话也能被识别
    - afftdn=nr=10       频域降噪，压制稳态背景噪声
    """
    # 预处理：检查文件是否是常见音频格式
    if not _is_valid_audio(input_path):
        print(f"[ffmpeg] 跳过无效音频文件: {os.path.getsize(input_path)} 字节")
        return False

    af = "highpass=f=80,lowpass=f=8000,afftdn=nr=10,dynaudnorm=p=0.9:s=5"
    for attempt, (cmd, label) in enumerate([
        # 方案1: 完整滤波链
        (["ffmpeg", "-y", "-i", input_path,
          "-af", af,
          "-ar", "16000", "-ac", "1", "-sample_fmt", "s16",
          output_path], "滤波版"),
        # 方案2: 基础转换（无滤波）
        (["ffmpeg", "-y", "-i", input_path,
          "-ar", "16000", "-ac", "1",
          output_path], "基础版"),
        # 方案3: 容错 + 修复损坏的 webm（处理 MediaRecorder 未正确封包的情况）
        (["ffmpeg", "-y",
          "-err_detect", "ignore_err",
          "-fflags", "+genpts+igndts",
          "-analyzeduration", "10M",
          "-probesize", "10M",
          "-vn",
          "-i", input_path,
          "-ar", "16000", "-ac", "1",
          output_path], "修复版"),
    ]):
        try:
            result = subprocess.run(cmd, capture_output=True, timeout=30)
            if result.returncode == 0:
                return True
            else:
                stderr_tail = result.stderr.decode("utf-8", errors="replace")[-300:].strip()
                # Windows 上退出码 > 2^31 通常是 ffmpeg 进程崩溃（如访问违例）
                crash_hint = " (疑似崩溃)" if result.returncode > 0x7FFFFFFF else ""
                print(f"[ffmpeg] {label} 失败 (rc={result.returncode}){crash_hint}: {stderr_tail}")
        except subprocess.TimeoutExpired:
            print(f"[ffmpeg] {label} 超时")
        except FileNotFoundError:
            print("[ffmpeg] ffmpeg 未安装或不在 PATH 中")
            return False
        except Exception as e:
            print(f"[ffmpeg] {label} 异常: {e}")

    return False


def _get_local_stt_config():
    """读取 STT 本地降级配置。"""
    cfg = load_config().get("stt", {})
    return {
        "enabled": cfg.get("local_enabled", True),
        "model": cfg.get("local_model", "base"),
        "device": cfg.get("local_device", "cpu"),
        "compute_type": cfg.get("local_compute_type", "int8"),
        "api_timeout": cfg.get("api_timeout", 5),
        "hf_endpoint": cfg.get("hf_endpoint", "https://hf-mirror.com"),
    }


def _load_local_stt_model():
    """懒加载本地 faster-whisper 模型（线程安全，只加载一次）。"""
    global _local_stt_model
    if _local_stt_model is not None:
        return _local_stt_model
    with _local_stt_lock:
        if _local_stt_model is not None:
            return _local_stt_model
        cfg = _get_local_stt_config()

        # 设置 HuggingFace 镜像，国内网络环境下可正常下载模型
        # 注意：必须用直接赋值而非 setdefault，否则已有环境变量会阻止镜像生效
        hf_endpoint = cfg.get("hf_endpoint", "")
        if hf_endpoint:
            os.environ["HF_ENDPOINT"] = hf_endpoint
            os.environ["HF_HUB_ENDPOINT"] = hf_endpoint

        print(f"[STT-Local] 正在加载本地模型 faster-whisper/{cfg['model']}（{cfg['device']}/{cfg['compute_type']}）…")
        try:
            from faster_whisper import WhisperModel
            _local_stt_model = WhisperModel(
                cfg["model"],
                device=cfg["device"],
                compute_type=cfg["compute_type"],
            )
            print(f"[STT-Local] ✅ 本地模型就绪")
        except Exception as e:
            print(f"[STT-Local] ❌ 模型加载失败: {e}")
            _local_stt_model = False  # 标记加载失败，避免反复重试
        return _local_stt_model


def speech_to_text_local(wav_path: str) -> str:
    """使用本地 faster-whisper 模型进行语音识别（API 降级方案）。

    模型首次调用时自动下载（约 142MB），后续调用直接使用缓存。
    """
    model = _load_local_stt_model()
    if model is False:
        raise RuntimeError("本地 STT 模型未就绪")
    segments, info = model.transcribe(wav_path, beam_size=5, language="zh",
                                       vad_filter=True,
                                       vad_parameters=dict(
                                           min_silence_duration_ms=500,
                                           threshold=0.4,
                                       ))
    text = " ".join(seg.text.strip() for seg in segments)
    if not text:
        raise RuntimeError("本地模型未识别到语音内容")
    print(f"[STT-Local] 识别结果: {text[:60]}{'…' if len(text) > 60 else ''}")
    return text


def speech_to_text(wav_path: str) -> str:
    """调用 SiliconFlow 语音识别 API，失败时自动降级到本地模型。"""
    import requests
    config = load_config()
    stt_cfg = _get_local_stt_config()

    # 第一选择：SiliconFlow API（快速、准确）
    url = "https://api.siliconflow.cn/v1/audio/transcriptions"
    headers = {"Authorization": f"Bearer {config['api_key']}"}
    with open(wav_path, "rb") as f:
        files = {"file": ("audio.wav", f, "audio/wav")}
        data = {"model": "FunAudioLLM/SenseVoiceSmall"}
        try:
            resp = requests.post(url, headers=headers, files=files, data=data,
                                 timeout=stt_cfg["api_timeout"])
            resp.raise_for_status()
            text = resp.json().get("text", "").strip()
            if text:
                return text
            # API 返回空文本也视为失败
            raise RuntimeError("API 返回空文本")
        except Exception as e:
            print(f"[STT-API] 失败（{e}），尝试本地降级…")

    # 第二选择：本地 faster-whisper 降级
    if stt_cfg["enabled"]:
        try:
            return speech_to_text_local(wav_path)
        except Exception as e2:
            print(f"[STT-Local] 降级也失败: {e2}")
            raise RuntimeError(f"语音识别失败（API + 本地均失败）") from e2
    raise RuntimeError(f"语音识别失败且本地降级已禁用")


# ---------- 路由 ----------
@app.get("/")
async def index():
    return FileResponse(str(WEB_DIR / "index.html"))


@app.get("/api/info")
async def info():
    return {"lan_ip": get_lan_ip(), "port": 8000}


# ---------- TTS 配置 ----------
@app.get("/api/tts/voices")
async def tts_voices():
    """返回 edge_tts 中文音色列表"""
    try:
        return {"voices": await get_edge_voices()}
    except Exception as e:
        return {"voices": [], "error": str(e)}


@app.get("/api/tts/characters")
async def tts_characters():
    """返回 gpt_sovits.json 里配置的角色列表（对齐 voice.py）"""
    for rel in ("tools/gpt_sovits/gpt_sovits.json", "gpt_sovits.json"):
        p = BASE_DIR / rel
        if p.exists():
            try:
                with open(p, "r", encoding="utf-8") as f:
                    data = json.load(f)
                return {"characters": list(data.keys()), "source": rel}
            except Exception as e:
                return {"characters": [], "error": str(e)}
    return {"characters": [], "error": "未找到 gpt_sovits.json"}


@app.get("/api/tts/config")
async def tts_config_get():
    return tts_config


@app.post("/api/tts/config")
async def tts_config_set(payload: dict):
    """更新 TTS 配置（部分字段）"""
    for k in ("engine", "edge_voice", "edge_rate",
              "gptsovits_url", "gptsovits_ref_audio", "gptsovits_character"):
        if k in payload:
            tts_config[k] = payload[k]
    # 切换音色后清空缓存，便于下次重新拉取
    if "edge_voice" in payload:
        global _edge_voices_cache
        _edge_voices_cache = None
    # 持久化保存
    _save_tts_config({k: tts_config[k] for k in DEFAULT_TTS_CONFIG})
    return {"ok": True, "config": tts_config}


# ---------- 3D 模型管理 ----------
@app.get("/api/models")
async def list_models():
    """列出所有已上传的 3D 模型"""
    models = []
    for f in MODELS_DIR.iterdir():
        if f.is_file() and f.suffix.lower() in ALLOWED_MODEL_EXTS:
            stat = f.stat()
            models.append({
                "name": f.name,
                "url": f"/models/{f.name}",
                "size": stat.st_size,
                "type": f.suffix.lower().lstrip("."),
                "mtime": int(stat.st_mtime),
            })
    models.sort(key=lambda m: m["mtime"], reverse=True)
    return {"models": models}


@app.post("/api/model/upload")
async def upload_model(file: UploadFile = File(...)):
    """上传 3D 模型文件 (glb/gltf/vrm)"""
    if not file.filename:
        raise HTTPException(400, "缺少文件名")
    ext = Path(file.filename).suffix.lower()
    if ext not in ALLOWED_MODEL_EXTS:
        raise HTTPException(400, f"不支持的格式 {ext}，仅支持 {', '.join(ALLOWED_MODEL_EXTS)}")

    # 读取内容并检查大小
    data = await file.read()
    if len(data) > MAX_MODEL_SIZE:
        raise HTTPException(413, f"文件过大 ({len(data)//1024//1024}MB)，上限 {MAX_MODEL_SIZE//1024//1024}MB")

    # 重命名避免覆盖与冲突：保留原名但加时间戳前缀
    safe_name = re.sub(r"[^\w.\-]", "_", file.filename)
    target = MODELS_DIR / f"{int(asyncio.get_event_loop().time() * 1000)}_{safe_name}"
    target.write_bytes(data)
    return {
        "name": target.name,
        "url": f"/models/{target.name}",
        "size": len(data),
        "type": ext.lstrip("."),
    }


@app.delete("/api/model/{name}")
async def delete_model(name: str):
    """删除指定模型"""
    # 防路径穿越
    safe = Path(name).name
    target = MODELS_DIR / safe
    if not target.is_file():
        raise HTTPException(404, "模型不存在")
    if target.suffix.lower() not in ALLOWED_MODEL_EXTS:
        raise HTTPException(400, "非模型文件")
    target.unlink()
    return {"deleted": safe}


@app.put("/api/model/{name}/rename")
async def rename_model(name: str, payload: dict):
    """重命名指定模型（保留扩展名）"""
    new_name = (payload.get("new_name") or "").strip()
    if not new_name:
        raise HTTPException(400, "新名称不能为空")
    # 防路径穿越
    safe_old = Path(name).name
    target = MODELS_DIR / safe_old
    if not target.is_file():
        raise HTTPException(404, "模型不存在")
    if target.suffix.lower() not in ALLOWED_MODEL_EXTS:
        raise HTTPException(400, "非模型文件")
    # 保留原扩展名
    old_suffix = target.suffix
    safe_new = re.sub(r"[^\w.\-]", "_", new_name)
    if not safe_new.lower().endswith(old_suffix.lower()):
        safe_new += old_suffix
    new_path = MODELS_DIR / safe_new
    if new_path.exists():
        raise HTTPException(409, "同名文件已存在")
    target.rename(new_path)
    return {"old_name": safe_old, "new_name": safe_new, "url": f"/models/{safe_new}"}


# ---------- 3D 背景模型管理 ----------
@app.get("/api/backgrounds")
async def list_backgrounds():
    """列出所有已上传的 3D 背景模型"""
    items = []
    for f in BACKGROUNDS_DIR.iterdir():
        if f.is_file() and f.suffix.lower() in ALLOWED_MODEL_EXTS:
            stat = f.stat()
            items.append({
                "name": f.name,
                "url": f"/backgrounds/{f.name}",
                "size": stat.st_size,
                "type": f.suffix.lower().lstrip("."),
                "mtime": int(stat.st_mtime),
            })
    items.sort(key=lambda m: m["mtime"], reverse=True)
    return {"backgrounds": items}


@app.post("/api/background/upload")
async def upload_background(file: UploadFile = File(...)):
    """上传 3D 背景模型文件 (glb/gltf/vrm)"""
    if not file.filename:
        raise HTTPException(400, "缺少文件名")
    ext = Path(file.filename).suffix.lower()
    if ext not in ALLOWED_MODEL_EXTS:
        raise HTTPException(400, f"不支持的格式 {ext}，仅支持 {', '.join(ALLOWED_MODEL_EXTS)}")

    data = await file.read()
    if len(data) > MAX_MODEL_SIZE:
        raise HTTPException(413, f"文件过大 ({len(data)//1024//1024}MB)，上限 {MAX_MODEL_SIZE//1024//1024}MB")

    safe_name = re.sub(r"[^\w.\-]", "_", file.filename)
    target = BACKGROUNDS_DIR / f"{int(asyncio.get_event_loop().time() * 1000)}_{safe_name}"
    target.write_bytes(data)
    return {
        "name": target.name,
        "url": f"/backgrounds/{target.name}",
        "size": len(data),
        "type": ext.lstrip("."),
    }


@app.delete("/api/background/{name}")
async def delete_background(name: str):
    """删除指定背景模型"""
    safe = Path(name).name
    target = BACKGROUNDS_DIR / safe
    if not target.is_file():
        raise HTTPException(404, "背景不存在")
    if target.suffix.lower() not in ALLOWED_MODEL_EXTS:
        raise HTTPException(400, "非模型文件")
    target.unlink()
    return {"deleted": safe}


@app.put("/api/background/{name}/rename")
async def rename_background(name: str, payload: dict):
    """重命名指定背景模型（保留扩展名）"""
    new_name = (payload.get("new_name") or "").strip()
    if not new_name:
        raise HTTPException(400, "新名称不能为空")
    safe_old = Path(name).name
    target = BACKGROUNDS_DIR / safe_old
    if not target.is_file():
        raise HTTPException(404, "背景不存在")
    if target.suffix.lower() not in ALLOWED_MODEL_EXTS:
        raise HTTPException(400, "非模型文件")
    old_suffix = target.suffix
    safe_new = re.sub(r"[^\w.\-]", "_", new_name)
    if not safe_new.lower().endswith(old_suffix.lower()):
        safe_new += old_suffix
    new_path = BACKGROUNDS_DIR / safe_new
    if new_path.exists():
        raise HTTPException(409, "同名文件已存在")
    target.rename(new_path)
    return {"old_name": safe_old, "new_name": safe_new, "url": f"/backgrounds/{safe_new}"}


# ---------- BGM 背景音乐管理 ----------
ALLOWED_BGM_EXTS = {".mp3", ".wav", ".ogg", ".m4a", ".aac", ".flac"}
BGM_MAX_SIZE = 50 * 1024 * 1024  # 50MB


@app.get("/api/bgm")
async def list_bgm():
    """列出所有背景音乐文件"""
    items = []
    for f in BGM_DIR.iterdir():
        if f.is_file() and f.suffix.lower() in ALLOWED_BGM_EXTS:
            stat = f.stat()
            items.append({
                "name": f.name,
                "url": f"/bgm/{f.name}",
                "size": stat.st_size,
                "type": f.suffix.lower().lstrip("."),
                "mtime": int(stat.st_mtime),
            })
    items.sort(key=lambda m: m["mtime"], reverse=True)
    return {"bgm": items}


@app.post("/api/bgm/upload")
async def upload_bgm(file: UploadFile = File(...)):
    """上传背景音乐文件"""
    if not file.filename:
        raise HTTPException(400, "缺少文件名")
    ext = Path(file.filename).suffix.lower()
    if ext not in ALLOWED_BGM_EXTS:
        raise HTTPException(400, f"不支持的格式 {ext}，仅支持 {', '.join(ALLOWED_BGM_EXTS)}")

    data = await file.read()
    if len(data) > BGM_MAX_SIZE:
        raise HTTPException(413, f"文件过大 ({len(data)//1024//1024}MB)，上限 {BGM_MAX_SIZE//1024//1024}MB")

    safe_name = re.sub(r"[^\w.\-]", "_", file.filename)
    target = BGM_DIR / f"{int(asyncio.get_event_loop().time() * 1000)}_{safe_name}"
    target.write_bytes(data)
    return {
        "name": target.name,
        "url": f"/bgm/{target.name}",
        "size": len(data),
        "type": ext.lstrip("."),
    }


@app.delete("/api/bgm/{name}")
async def delete_bgm(name: str):
    """删除指定背景音乐"""
    safe = Path(name).name
    target = BGM_DIR / safe
    if not target.is_file():
        raise HTTPException(404, "BGM不存在")
    if target.suffix.lower() not in ALLOWED_BGM_EXTS:
        raise HTTPException(400, "非音频文件")
    target.unlink()
    return {"deleted": safe}


# ---------- Agent & 记忆管理 API ----------
@app.get("/api/agent/status")
async def agent_status():
    """获取 Agent 状态（已加载的 MCP 工具数等）。"""
    try:
        agent = await get_shared_agent()
        tools_count = len(agent._all_tools) if agent._all_tools else 0
        return {
            "initialized": agent._initialized,
            "tools_count": tools_count,
            "mcp_connected": agent.mcp_manager is not None,
            "has_memory": agent.memory is not None,
        }
    except Exception as e:
        return {"error": str(e)}


@app.get("/api/sessions")
async def list_sessions(user_id: str = "default"):
    """列出用户的所有会话。"""
    agent = await get_shared_agent(user_id)
    sessions = await agent.get_sessions()
    return {"sessions": sessions}


@app.post("/api/sessions/switch")
async def switch_session(payload: dict):
    """切换到指定会话。"""
    user_id = payload.get("user_id", "default")
    session_id = payload.get("session_id", "")
    if not session_id:
        raise HTTPException(400, "缺少 session_id")
    agent = await get_shared_agent(user_id)
    await agent.switch_session(session_id)
    history = await agent.get_history()
    return {"session_id": session_id, "history": history}


@app.post("/api/sessions/new")
async def new_session(payload: dict):
    """创建新会话。"""
    user_id = payload.get("user_id", "default")
    agent = await get_shared_agent(user_id)
    await agent.close_current_session()
    agent.memory.session_id = None
    sid = await agent.memory.get_or_create_session()
    return {"session_id": sid}


@app.delete("/api/sessions/{session_id}")
async def delete_session(session_id: str, user_id: str = "default"):
    """删除指定会话。"""
    agent = await get_shared_agent(user_id)
    await agent.delete_session(session_id)
    return {"deleted": session_id}


# ---------- WebSocket ----------
class ConnectionManager:
    def __init__(self):
        self.active: List[WebSocket] = []

    async def connect(self, ws: WebSocket):
        await ws.accept()
        self.active.append(ws)

    def disconnect(self, ws: WebSocket):
        if ws in self.active:
            self.active.remove(ws)


manager = ConnectionManager()


async def safe_send_json(ws: WebSocket, data: dict) -> bool:
    """安全发送 WebSocket 消息，连接已关闭时静默忽略。"""
    try:
        if ws.client_state != WebSocketState.CONNECTED:
            return False
        await ws.send_json(data)
        return True
    except (RuntimeError, Exception):
        # 连接可能已断开或正在关闭
        return False


# 全局 Agent 实例（所有连接共享，按 user_id 区分记忆）
_shared_agents: dict[str, AIAgent] = {}
_agent_lock = asyncio.Lock()


async def get_shared_agent(user_id: str = "default") -> AIAgent:
    """获取或创建共享 Agent 实例。"""
    if user_id not in _shared_agents:
        async with _agent_lock:
            if user_id not in _shared_agents:
                agent = AIAgent(user_id=user_id)
                await agent.initialize()
                _shared_agents[user_id] = agent
                logger.info(f"创建 Agent: user_id={user_id}")
    return _shared_agents[user_id]


# ---------- 会话状态（per-connection） ----------
class WSState:
    """每个 WebSocket 连接的会话状态，支持打断式流式响应。"""
    def __init__(self):
        self.current_session: Optional[str] = None   # 当前活跃回复 session_id
        self.cancelled: set = set()                  # 已取消的回复 session_id 集合
        self.active_task: Optional[asyncio.Task] = None  # 当前活跃回复 task
        self.user_id: str = "default"                # 用户标识
        self.chat_session_id: Optional[str] = None   # 当前对话会话 ID（持久化用）
        self.current_model: Optional[str] = None     # 当前使用的角色模型名
        self.current_background: Optional[str] = None  # 当前使用的背景场景名
        self.current_bgm: Optional[str] = None       # 当前播放的背景音乐名

    def new_session(self) -> str:
        """开启新回复会话：把旧会话标记为取消，返回新 session_id。"""
        if self.current_session:
            self.cancelled.add(self.current_session)
        sid = uuid.uuid4().hex
        self.current_session = sid
        return sid

    def is_cancelled(self, sid: str) -> bool:
        return sid in self.cancelled

    def cancel_current(self):
        if self.current_session:
            self.cancelled.add(self.current_session)
            self.current_session = None


async def handle_user_message_stream(ws: WebSocket, user_text: str, history: list,
                                      session_id: str, state: WSState,
                                      current_model: Optional[str] = None,
                                      current_background: Optional[str] = None,
                                      current_bgm: Optional[str] = None):
    """流式处理：AI 流式响应（含工具调用）→ 按句切分 → 每句生成 TTS → 推送 audio_chunk。

    支持：
    - MCP 工具调用状态实时推送
    - 长期记忆自动保存
    - 首句延迟 ≈ AI 首句生成时间 + 单句 TTS 时间（通常 1~2s）
    """
    if not user_text.strip():
        return
    await safe_send_json(ws, {"type": "thinking", "session_id": session_id})

    buffer = ""
    full_text = ""
    seq = 0
    SOFT_CUT_LEN = 24
    tool_calls_made = []  # 记录本轮调用的工具

    async def flush(sentence: str):
        """生成单句 TTS 并推送（音频数据 base64 编码，即时销毁）。"""
        nonlocal seq
        sentence = re.sub(r"[*_`#>\-\[\]\(\)]", "", sentence).strip()
        if not sentence or len(sentence) < 2:
            return
        if state.is_cancelled(session_id):
            return
        seq += 1
        audio_b64 = None
        audio_mime = None
        try:
            result = await generate_tts(sentence)
            if result:
                audio_bytes, mime_type = result
                audio_b64 = base64.b64encode(audio_bytes).decode("utf-8")
                audio_mime = mime_type
                del audio_bytes  # 释放内存
        except Exception as e:
            print(f"[TTS] 失败: {e}")
        if state.is_cancelled(session_id):
            return
        await safe_send_json(ws, {
            "type": "audio_chunk",
            "session_id": session_id,
            "seq": seq,
            "text": sentence,
            "audio_b64": audio_b64,
            "audio_mime": audio_mime,
            "final": False,
        })

    try:
        agent = await get_shared_agent(state.user_id)
        # 确保 agent 的 memory session_id 与 state 同步
        if state.chat_session_id and agent.memory:
            agent.memory.session_id = state.chat_session_id

        async for event in agent.chat_stream(
            user_text, history=history,
            current_model=current_model,
            current_background=current_background,
            current_bgm=current_bgm,
        ):
            if state.is_cancelled(session_id):
                break

            if isinstance(event, TextDelta):
                buffer += event.text
                full_text += event.text
                # 按句末标点切分
                while True:
                    m = SENTENCE_END.search(buffer)
                    if m:
                        sentence = buffer[:m.end()]
                        buffer = buffer[m.end():]
                        await flush(sentence)
                    elif len(buffer) >= SOFT_CUT_LEN:
                        await flush(buffer)
                        buffer = ""
                        break
                    else:
                        break

            elif isinstance(event, ToolCallStart):
                tool_calls_made.append({"name": event.tool_name, "arguments": event.arguments})
                await safe_send_json(ws, {
                    "type": "tool_call_start",
                    "session_id": session_id,
                    "tool_name": event.tool_name,
                    "arguments": event.arguments,
                })

            elif isinstance(event, ToolCallResult):
                await safe_send_json(ws, {
                    "type": "tool_call_result",
                    "session_id": session_id,
                    "tool_name": event.tool_name,
                    "result": event.result[:500],
                    "success": event.success,
                })
                # 检测是否为屏幕控制工具，若是则转发给前端执行
                if event.success:
                    try:
                        r = json.loads(event.result)
                        if isinstance(r, dict) and r.get("__screen_command__"):
                            cmd = {"type": "screen_command", "tool": r["tool"], "args": r["args"]}
                            await safe_send_json(ws, cmd)
                            logger.info(f"[ScreenCmd] 已发送: {r['tool']} {r['args']}")
                    except (json.JSONDecodeError, TypeError):
                        pass  # 不是 JSON，忽略

    except Exception as e:
        logger.error(f"Agent 错误: {e}")
        await safe_send_json(ws, {"type": "error", "message": f"AI 出错了：{e}",
                            "session_id": session_id})
        return

    # 处理剩余尾巴
    if buffer.strip():
        await flush(buffer)

    if state.is_cancelled(session_id):
        await safe_send_json(ws, {"type": "interrupted", "session_id": session_id})
        return

    full_text = full_text.strip()
    await safe_send_json(ws, {
        "type": "audio_end",
        "session_id": session_id,
        "full_text": full_text,
        "tool_calls": tool_calls_made if tool_calls_made else None,
    })
    if full_text:
        history.append({"user": user_text, "ai": full_text})


async def _kickoff_response(ws: WebSocket, text: str, history: list, state: WSState):
    """取消当前回复 → 开启新会话 → 启动流式回复 task。"""
    # 取消正在进行的回复（如果有）
    state.cancel_current()
    if state.active_task and not state.active_task.done():
        state.active_task.cancel()
    sid = state.new_session()
    state.active_task = asyncio.create_task(
        handle_user_message_stream(
            ws, text, history, sid, state,
            current_model=state.current_model,
            current_background=state.current_background,
            current_bgm=state.current_bgm,
        )
    )


@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await manager.connect(ws)
    history: list = []
    state = WSState()
    try:
        await safe_send_json(ws, {"type": "ready", "message": "连接成功"})
        while True:
            msg = await ws.receive_json()
            mtype = msg.get("type")

            # === 心跳 ===
            if mtype == "ping":
                await safe_send_json(ws, {"type": "pong"})
                continue

            # === 用户身份设置 ===
            if mtype == "set_user":
                state.user_id = msg.get("user_id", "default")
                # 预初始化该用户的 Agent
                agent = await get_shared_agent(state.user_id)
                state.chat_session_id = agent.memory.session_id if agent.memory else None
                # 加载当前会话的历史消息并返回
                history = await agent.get_history()
                await safe_send_json(ws, {
                    "type": "user_set",
                    "user_id": state.user_id,
                    "chat_session_id": state.chat_session_id,
                    "history": history,
                })
                continue

            # === 会话管理 ===
            if mtype == "list_sessions":
                agent = await get_shared_agent(state.user_id)
                sessions = await agent.get_sessions()
                await safe_send_json(ws, {"type": "session_list", "sessions": sessions})
                continue

            if mtype == "switch_session":
                sid = msg.get("session_id", "")
                if sid:
                    agent = await get_shared_agent(state.user_id)
                    await agent.switch_session(sid)
                    state.chat_session_id = sid
                    history = await agent.get_history()
                    await safe_send_json(ws, {
                        "type": "session_switched",
                        "session_id": sid,
                        "history": history,
                    })
                continue

            if mtype == "new_session":
                agent = await get_shared_agent(state.user_id)
                await agent.close_current_session()
                # 重新初始化会创建新会话
                agent.memory.session_id = None
                await agent.memory.get_or_create_session()
                state.chat_session_id = agent.memory.session_id
                history = []
                await safe_send_json(ws, {
                    "type": "session_created",
                    "session_id": state.chat_session_id,
                })
                continue

            if mtype == "delete_session":
                sid = msg.get("session_id", "")
                if sid:
                    agent = await get_shared_agent(state.user_id)
                    await agent.delete_session(sid)
                    await safe_send_json(ws, {"type": "session_deleted", "session_id": sid})
                continue

            # === 当前形象与场景同步 ===
            if mtype == "set_avatar":
                state.current_model = msg.get("name") or None
                await safe_send_json(ws, {
                    "type": "avatar_set",
                    "name": state.current_model,
                })
                continue

            if mtype == "set_background":
                state.current_background = msg.get("name") or None
                await safe_send_json(ws, {
                    "type": "background_set",
                    "name": state.current_background,
                })
                continue

            if mtype == "set_bgm":
                state.current_bgm = msg.get("name") or None
                await safe_send_json(ws, {
                    "type": "bgm_set",
                    "name": state.current_bgm,
                })
                continue

            # === AI 自主触发 ===
            if mtype == "proactive":
                trigger = "用户暂时没有说话"
                if state.current_model:
                    trigger += f"，你当前的造型是 {state.current_model}"
                if state.current_background:
                    trigger += f"，身处 {state.current_background}"
                if state.current_bgm:
                    trigger += f"，正在播放背景音乐 {state.current_bgm}"
                trigger += "。你可以基于当前形象和场景主动说点什么、做个小动作，或者自然切换到新话题。保持简短自然，不要询问用户是否在线。"
                await _kickoff_response(ws, trigger, history, state)
                continue

            # === 对话打断 ===
            # 客户端主动打断（用户按麦克风开始说话）
            if mtype == "interrupt":
                state.cancel_current()
                if state.active_task and not state.active_task.done():
                    state.active_task.cancel()
                await safe_send_json(ws, {"type": "interrupted"})
                continue

            if mtype == "text":
                text = msg.get("content", "")
                if not text.strip():
                    continue
                await _kickoff_response(ws, text, history, state)

            elif mtype == "audio":
                data = msg.get("data", "")
                if not data:
                    continue
                # 兼容 data URL 与纯 base64
                if "," in data and data.startswith("data:"):
                    data = data.split(",", 1)[1]
                try:
                    audio_bytes = base64.b64decode(data)
                except Exception:
                    await safe_send_json(ws, {"type": "error", "message": "音频解码失败"})
                    continue

                # 根据前端实际录音格式选择扩展名（兼容 webm/ogg/mp4）
                mime_type = msg.get("mime_type", "audio/webm")
                ext = _mime_to_ext(mime_type)
                tmp_in = tempfile.NamedTemporaryFile(delete=False, suffix=ext)
                tmp_in.write(audio_bytes)
                tmp_in.close()
                tmp_wav = tmp_in.name.replace(ext, ".wav")

                # 取消当前 AI 回复（语音输入必然打断 TTS 播放）
                state.cancel_current()
                if state.active_task and not state.active_task.done():
                    state.active_task.cancel()
                await safe_send_json(ws, {"type": "listening"})
                ok = await asyncio.to_thread(convert_to_wav, tmp_in.name, tmp_wav)
                text = ""
                if ok:
                    try:
                        text = await asyncio.to_thread(speech_to_text, tmp_wav)
                    except Exception as e:
                        print(f"[STT] 失败: {e}")
                # 清理临时文件
                for p in (tmp_in.name, tmp_wav):
                    try:
                        os.unlink(p)
                    except Exception:
                        pass
                if not text:
                    await safe_send_json(ws, {"type": "error", "message": "没听清，请再说一遍~"})
                    continue
                await safe_send_json(ws, {"type": "transcript", "text": text})
                sid = state.new_session()
                state.active_task = asyncio.create_task(
                    handle_user_message_stream(ws, text, history, sid, state)
                )

    except WebSocketDisconnect:
        manager.disconnect(ws)
    except Exception as e:
        print(f"[WS] 错误: {e}")
        manager.disconnect(ws)
    finally:
        # 连接已关闭，取消该连接上可能仍在运行的 AI 回复任务
        state.cancel_current()
        if state.active_task and not state.active_task.done():
            state.active_task.cancel()


if __name__ == "__main__":
    import ssl
    ip = get_lan_ip()

    # 检查/生成自签名证书 (HTTPS 解锁手机陀螺仪/摄像头等传感器 API)
    cert_dir = Path(__file__).parent
    cert_file = cert_dir / "cert.pem"
    key_file = cert_dir / "key.pem"
    # 临时强制 HTTP 模式用于本地浏览器测试（测试完后恢复）
    use_https = cert_file.exists() and key_file.exists()

    print("\n" + "=" * 50)
    print("   3D 虚拟 AI 角色陪聊 服务器已启动")
    print("=" * 50)
    if use_https:
        print(f"  本机访问 : https://127.0.0.1:8000")
        print(f"  局域网   : https://{ip}:8000")
        print(f"  ⚠ 手机首次访问会提示证书不安全 → 点「高级」→「继续访问」")
        print(f"  ✅ HTTPS 模式：陀螺仪/传感器 API 已解锁")
    else:
        print(f"  本机访问 : http://127.0.0.1:8000")
        print(f"  局域网   : http://{ip}:8000")
    print(f"  手机请连接同一 Wi-Fi 后访问上述局域网地址")
    print("=" * 50 + "\n")

    if use_https:
        uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info",
                    ssl_certfile=str(cert_file), ssl_keyfile=str(key_file))
    else:
        uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")
