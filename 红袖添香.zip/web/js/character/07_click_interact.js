export default (function init(App) {
  const {
    THREE: THREE,
    GLTFLoader: GLTFLoader,
    VRMLoaderPlugin: VRMLoaderPlugin,
    VRMUtils: VRMUtils
  } = App;
  /* ============================================================
   *  点击角色部位交互
   * ============================================================ */
  App.getWorldCenter = function getWorldCenter(obj) {
    const center = new THREE.Vector3();
    if (obj) {
      const box = new THREE.Box3().setFromObject(obj);
      box.getCenter(center);
    }
    return center;
  }; // 每帧衰减点击击退效果（仅位移，无旋转）
  App.applyClickWobble = function applyClickWobble(target) {
    if (!App.clickWobble.active) return;

    // 撤销上一帧的偏移
    target.position.x -= App.clickWobble.prevPosX;
    target.position.z -= App.clickWobble.prevPosZ;
    target.position.y -= App.clickWobble.prevPosY;

    // 衰减
    App.clickWobble.posX *= App.clickWobble.decay;
    App.clickWobble.posZ *= App.clickWobble.decay;
    App.clickWobble.posY *= App.clickWobble.decay;

    // 检查是否归零
    if (Math.abs(App.clickWobble.posX) < 0.0001 && Math.abs(App.clickWobble.posZ) < 0.0001) {
      App.clickWobble.active = false;
      App.clickWobble.posX = 0;
      App.clickWobble.posZ = 0;
      App.clickWobble.posY = 0;
      App.clickWobble.prevPosX = 0;
      App.clickWobble.prevPosZ = 0;
      App.clickWobble.prevPosY = 0;
      return;
    }

    // 应用新偏移
    target.position.x += App.clickWobble.posX;
    target.position.z += App.clickWobble.posZ;
    target.position.y += App.clickWobble.posY;

    // 保存供下帧撤销
    App.clickWobble.prevPosX = App.clickWobble.posX;
    App.clickWobble.prevPosZ = App.clickWobble.posZ;
    App.clickWobble.prevPosY = App.clickWobble.posY;
  };
  App.identifyProceduralPart = function identifyProceduralPart(hitPoint, hitObject) {
    // 转换到角色本地坐标，正确处理角色旋转
    const lp = App.proceduralChar.worldToLocal(hitPoint.clone());
    const p = hitPoint.clone();
    const hcy = 1.55;
    const headCenter = App.getWorldCenter(App.parts.head);
    const bodyCenter = App.getWorldCenter(App.parts.body);

    // === 头部区域 (Y > 1.35) ===
    if (lp.y > 1.35) {
      const cx = lp.x,
        cy = lp.y - hcy,
        cz = lp.z;
      if (cy > 0.15) return {
        name: '头顶',
        center: headCenter
      };
      // 脖子区域
      if (cy < -0.1 && Math.abs(cx) < 0.2) return {
        name: '脖子',
        center: headCenter
      };
      // 面部前方（本地坐标 +Z = 脸朝前）
      if (cz > 0.18) {
        if (cy > 0.06 && Math.abs(cx) < 0.16) return {
          name: '额头',
          center: headCenter
        };
        if (Math.abs(cy) < 0.07 && Math.abs(cx) < 0.09) return {
          name: '鼻子',
          center: headCenter
        };
        if (cy < -0.05 && Math.abs(cx) < 0.13) return {
          name: '嘴唇',
          center: headCenter
        };
        if (Math.abs(cx) > 0.11) return {
          name: '脸颊',
          center: headCenter
        };
        return {
          name: '脸颊',
          center: headCenter
        };
      }
      if (Math.abs(cx) > 0.26 && Math.abs(cz) < 0.22) return {
        name: '耳朵',
        center: headCenter
      };
      if (cz < -0.15) return {
        name: '后脑勺',
        center: headCenter
      };
      return {
        name: '头顶',
        center: headCenter
      };
    }

    // === 躯干 (Y 0.6~1.35) ===
    if (lp.y > 0.6) {
      if (Math.abs(lp.x) > 0.35) {
        const side = lp.x < 0 ? '左' : '右';
        if (lp.y < 0.75) return {
          name: `${side}手`,
          center: bodyCenter
        };
        if (lp.y < 1.05) return {
          name: `${side}前臂`,
          center: bodyCenter
        };
        return {
          name: `${side}上臂`,
          center: bodyCenter
        };
      }
      if (lp.y > 1.2) return {
        name: '胸口',
        center: bodyCenter
      };
      if (lp.y > 0.95) return {
        name: '肚子',
        center: bodyCenter
      };
      if (lp.y > 0.75) return {
        name: '腰',
        center: bodyCenter
      };
      return {
        name: '小腹',
        center: bodyCenter
      };
    }

    // === 腿部 (Y < 0.6) ===
    const side = lp.x < 0 ? '左' : '右';
    if (lp.y > 0.4) return {
      name: `${side}大腿`,
      center: bodyCenter
    };
    if (lp.y > 0.1) return {
      name: `${side}小腿`,
      center: bodyCenter
    };
    return {
      name: `${side}脚`,
      center: bodyCenter
    };
  };
  App.identifyModelPart = function identifyModelPart(hitPoint) {
    // VRM 模式：找最近骨骼
    if (App.modelType === 'vrm' && Object.keys(App.vrmBones).length > 0) {
      const boneGroups = {
        '头顶': ['head', 'Head', 'HEAD'],
        '脸颊': ['leftEye', 'rightEye', 'Eye_L', 'Eye_R', 'nose', 'Nose', 'jaw', 'Jaw'],
        '耳朵': ['leftEar', 'rightEar', 'Ear_L', 'Ear_R'],
        '脖子': ['neck', 'Neck', 'NECK'],
        '肩膀': ['leftShoulder', 'rightShoulder', 'Shoulder_L', 'Shoulder_R'],
        '胸口': ['chest', 'upperChest', 'Chest', 'Spine1', 'Spine2', 'spine2'],
        '肚子': ['spine', 'Spine', 'SPINE'],
        '腰': ['hips', 'Hips', 'HIPS'],
        '左手': ['leftHand', 'LeftHand', 'Hand_L', 'leftThumbProximal', 'leftIndexProximal'],
        '右手': ['rightHand', 'RightHand', 'Hand_R', 'rightThumbProximal', 'rightIndexProximal'],
        '左臂': ['leftUpperArm', 'LeftUpperArm', 'UpperArm_L', 'leftLowerArm', 'LeftLowerArm', 'LowerArm_L'],
        '右臂': ['rightUpperArm', 'RightUpperArm', 'UpperArm_R', 'rightLowerArm', 'RightLowerArm', 'LowerArm_R'],
        '左大腿': ['leftUpperLeg', 'LeftUpperLeg', 'UpperLeg_L'],
        '右大腿': ['rightUpperLeg', 'RightUpperLeg', 'UpperLeg_R'],
        '左小腿': ['leftLowerLeg', 'LeftLowerLeg', 'LowerLeg_L'],
        '右小腿': ['rightLowerLeg', 'RightLowerLeg', 'LowerLeg_R'],
        '左脚': ['leftFoot', 'LeftFoot', 'Foot_L', 'leftToes', 'LeftToes', 'Toes_L'],
        '右脚': ['rightFoot', 'RightFoot', 'Foot_R', 'rightToes', 'RightToes', 'Toes_R']
      };
      let bestName = '身体',
        bestPos = new THREE.Vector3(),
        bestDist = Infinity;
      for (const [groupName, boneNames] of Object.entries(boneGroups)) {
        for (const boneName of boneNames) {
          const bone = App.vrmBones[boneName];
          if (!bone) continue;
          const pos = new THREE.Vector3();
          bone.getWorldPosition(pos);
          const dist = hitPoint.distanceTo(pos);
          if (dist < bestDist) {
            bestDist = dist;
            bestName = groupName;
            bestPos.copy(pos);
          }
        }
      }
      return {
        name: bestName,
        center: bestPos
      };
    }
    // GLTF 回退：用模型整体包围盒中心 + 高度细分
    const center = App.getWorldCenter(App.modelGroup);
    const p = hitPoint.clone();
    const bbox = new THREE.Box3().setFromObject(App.modelGroup);
    const size = bbox.getSize(new THREE.Vector3());
    const minY = bbox.min.y;
    const height = size.y || 1.8;
    const relY = (p.y - minY) / height;
    if (relY > 0.8) return {
      name: '头顶',
      center: new THREE.Vector3(p.x, minY + height * 0.88, p.z)
    };
    if (relY > 0.6) return {
      name: '胸口',
      center: new THREE.Vector3(p.x, minY + height * 0.7, p.z)
    };
    if (relY > 0.4) return {
      name: '肚子',
      center: new THREE.Vector3(p.x, minY + height * 0.5, p.z)
    };
    if (relY > 0.2) return {
      name: '腰',
      center: new THREE.Vector3(p.x, minY + height * 0.3, p.z)
    };
    return {
      name: '腿',
      center: new THREE.Vector3(p.x, minY + height * 0.1, p.z)
    };
  }; // 退出聚焦模式前保存当前相机偏移，避免跳回原位
  App.exitFocusMode = function exitFocusMode() {
    if (!App.focusPart.active) return;
    App.focusPart.active = false;
    const mcY = 1.0;
    const orbitR = App.DEFAULT_CAM_POS.z * App.camZoom;
    const baseY = mcY + (App.cameraHeight - mcY) * App.camZoom;
    const cp = App.camera.position;
    App.camOffsetX = cp.x - orbitR * Math.sin(App.gyroYaw) * Math.cos(App.gyroPitch);
    App.camOffsetY = cp.y - baseY - orbitR * Math.sin(App.gyroPitch);
    App.camOffsetZ = cp.z - orbitR * Math.cos(App.gyroYaw) * Math.cos(App.gyroPitch);
  };
  App.handleCharacterClick = function handleCharacterClick(e) {
    if (!App.currentAvatar || App.fpvMode || App.moveMode) return;
    App.updatePointerNdc(e);
    App.clickRaycaster.setFromCamera(App.pointerNdc, App.camera);
    const hits = App.clickRaycaster.intersectObjects([App.currentAvatar], true);
    if (hits.length === 0) return;
    const hitPoint = hits[0].point.clone();

    // 识别部位
    let result;
    if (App.modelType === 'procedural') {
      result = App.identifyProceduralPart(hitPoint, hits[0].object);
    } else {
      result = App.identifyModelPart(hitPoint);
    }

    // 触发击退：方向 = 从相机指向点击点
    const wobbleDir = hitPoint.clone().sub(App.camera.position).normalize();
    App.clickWobble.active = true;
    const impulse = 1.4;
    App.clickWobble.posX = wobbleDir.x * impulse * 0.04;
    App.clickWobble.posZ = wobbleDir.z * impulse * 0.04;
    App.clickWobble.posY = wobbleDir.y * impulse * 0.02;
    App.clickWobble.prevPosX = 0;
    App.clickWobble.prevPosZ = 0;
    App.clickWobble.prevPosY = 0;

    // 相机聚焦到该部位
    const camToPart = App.camera.position.clone().sub(result.center).normalize();
    const focusDist = 1.2;
    App.focusPart.active = true;
    App.focusPart.lookAt.copy(result.center);
    App.focusPart.target.copy(result.center).addScaledVector(camToPart, focusDist);
    App.focusPart.target.y = Math.max(0.3, App.focusPart.target.y);
    App.focusPart.time = 0;
    App.focusPart.name = result.name;
    App.showToast(`戳了${result.name}一下~`);

    // 发送互动消息给 AI，触发个性化回复（亲密互动版）
    const pokeMessages = {
      '额头': ['（在你额头上亲了一下）', '（用手摸了摸你的额头）', '（在你的额头上轻轻落下一吻）'],
      '鼻子': ['（用手指刮了一下你的鼻尖）', '（调皮地捏了捏你的鼻子）', '（凑近你，鼻尖轻轻碰了碰你）'],
      '嘴唇': ['（用手指轻轻点了一下你的嘴唇）', '（温柔地亲了你一口）', '（凑近你，在你唇边呵了一口气）'],
      '脸颊': ['（捏了捏你的脸蛋）', '（在你脸颊上亲了一下）', '（双手捧住你的脸）'],
      '耳朵': ['（在耳边轻轻吹了口气）', '（靠近你耳边说悄悄话）', '（轻轻咬了一下你的耳垂）'],
      '头顶': ['（温柔地摸着你的头顶）', '（揉了揉你蓬松的头发）', '（用手臂护住你的头）'],
      '后脑勺': ['（从背后轻轻托住你的后脑勺）', '（揉了揉你的后脑勺）', '（从背后靠近，在你后脑轻吻）'],
      '脖子': ['（把头埋在你颈窝蹭了蹭）', '（亲了一下你的脖子）', '（从背后环住你，下巴搁在你肩上）'],
      '肩膀': ['（双手搭在你肩膀上）', '（从背后抱住你，头靠在你肩上）', '（轻轻按摩你的肩膀）'],
      '胸口': ['（把头贴在你胸口听心跳）', '（用手按在你胸口感受温度）', '（在你胸口画了一个小心心）'],
      '肚子': ['（轻轻戳了戳你的肚子）', '（双手环住你的腰靠着你）', '（摸了摸你的腹肌）'],
      '腰': ['（从背后搂住你的腰）', '（双手轻轻环住你的腰）', '（在你腰间蹭了蹭脸）'],
      '小腹': ['（手掌轻轻贴在你的小腹上）', '（从后面把你整个抱住）', '（双手轻轻按在你的小腹上）'],
      '左手': ['（握住了你的左手，和你十指相扣）', '（牵起你的左手轻轻吻了一下）', '（用两只手捧住你的右手）'],
      '右手': ['（牵住了你的右手）', '（把脸贴在右手心蹭了蹭）', '（握住你的右手放到自己心口）'],
      '左臂': ['（挽住了你的左臂）', '（轻轻抚摸着你的左臂）', '（把脸颊贴在你左臂上）'],
      '右臂': ['（靠在你右臂上）', '（抱住你的右臂不肯松开）', '（枕着你的右臂撒娇）'],
      '左前臂': ['（握住你的左手腕）', '（用手指在左手心画圈圈）', '（把下巴搁在你手心里）'],
      '右前臂': ['（拉过你的右手把玩）', '（掰着你的手指一根一根数）', '（把你的手贴在脸上）'],
      '左上臂': ['（轻轻捏了捏你的左臂肌肉）', '（靠在你的左臂旁取暖）'],
      '右上臂': ['（搭着你的右臂当靠枕）', '（用手指戳了戳你的右手肌肉）'],
      '左大腿': ['（把腿搭在你左腿上）', '（轻轻坐在了你腿上）', '（抱着你的左腿蹭了蹭）'],
      '右大腿': ['（蹭了蹭你的右腿）', '（侧坐在你右腿上）', '（手搭在你大腿上）'],
      '左小腿': ['（用小脚趾蹭了蹭你的左小腿）', '（踩着你的左脚晃啊晃）'],
      '右小腿': ['（轻轻踢了一下你的小腿）', '（脚背碰了碰你的脚踝）'],
      '左脚': ['（踩了踩你的左脚）', '（用脚趾头轻轻戳你的脚）'],
      '右脚': ['（踢了你右脚一下）', '（踮起脚尖踩在你脚上）'],
      '头': ['（亲了亲你的额头）', '（摸了摸你的头）'],
      '身体': ['（从背后抱住了你）', '（把整个人靠在你怀里）'],
      '腿': ['（轻轻踢了一下你）', '（把腿靠近你蹭了蹭）']
    };
    const msgs = pokeMessages[result.name] || pokeMessages['身体'];
    const pokeText = msgs[Math.floor(Math.random() * msgs.length)];

    // 直接发给AI，不在聊天中显示用户消息（更像自然互动）
    if (App.ws && App.ws.readyState === WebSocket.OPEN) {
      App.ws.send(JSON.stringify({
        type: 'text',
        content: pokeText
      }));
      App.setState(App.State.THINKING);
      App.showTyping();
    }
  }; // 通用AI互动：发送用户动作给AI（不显示在聊天中）
  App.sendAIAction = function sendAIAction(message) {
    if (!App.ws || App.ws.readyState !== WebSocket.OPEN) return;
    // 如果AI正在回复，打断后再发新消息
    if (App.currentState === App.State.SPEAKING || App.currentState === App.State.THINKING) {
      App.ws.send(JSON.stringify({
        type: 'interrupt'
      }));
      setTimeout(() => {
        if (App.ws && App.ws.readyState === WebSocket.OPEN) {
          App.ws.send(JSON.stringify({
            type: 'text',
            content: message
          }));
          App.setState(App.State.THINKING);
          App.showTyping();
        }
      }, 300);
    } else {
      App.ws.send(JSON.stringify({
        type: 'text',
        content: message
      }));
      App.setState(App.State.THINKING);
      App.showTyping();
    }
  };
  App.animate = function animate() {
    window._animFrame = requestAnimationFrame(App.animate);
    // 注意：getElapsedTime() 内部会调用 getDelta() 消耗掉时间差，
    // 必须先取 dt 再取 t，否则 dt 恒为 0（曾导致第一人称摇杆移动失效）
    const dt = Math.min(App.clock.getDelta(), 0.05); // 限制 50ms 防止弹簧骨骼爆飞
    const t = App.clock.elapsedTime;

    // 计算音频幅度 (口型同步 / lipsync)
    let mouthOpen = 0;
    if (App.currentState === App.State.SPEAKING) {
      let hasAudioSignal = false;
      if (App.analyserData && App.analyser) {
        App.analyser.getByteTimeDomainData(App.analyserData);
        let sum = 0;
        for (let i = 0; i < App.analyserData.length; i++) {
          const v = (App.analyserData[i] - 128) / 128;
          sum += v * v;
        }
        const raw = Math.sqrt(sum / App.analyserData.length);
        if (raw > 0.015) {
          hasAudioSignal = true;
          // 将语音响度映射到合理的嘴型范围 0~1
          const norm = Math.min(1, (raw - 0.015) / 0.15);
          mouthOpen = norm * norm * (3 - 2 * norm); // smoothstep 曲线，范围 0~1
        }
      }
      // 无音频分析器时用备用动画
      if (!hasAudioSignal && mouthOpen < 0.005) {
        const syllable = Math.max(0, Math.sin(t * 16) * 0.4 + Math.sin(t * 27) * 0.2 + 0.15);
        const phrase = 0.3 + 0.7 * Math.max(0, Math.sin(t * 2.6 + 0.5));
        mouthOpen = 0.5 * syllable * phrase;
      }
    }

    // 统一动作调度：走路 / 摆姿势 / 转圈 等概率轮换（与角色类型无关）
    App.updateActionScheduler(dt);
    if (App.modelType === 'procedural') {
      App.animateProcedural(t, dt, mouthOpen);
    } else {
      App.animateModel(t, dt, mouthOpen);
    }

    // 地面光晕呼吸 + 接触阴影
    if (App.parts.glow) {
      const s = 1 + Math.sin(t * 1.6) * 0.08;
      App.parts.glow.scale.set(s, s, s);
      App.parts.glow.material.opacity = 0.3 + Math.sin(t * 1.6) * 0.08;
    }
    if (App.parts.contactShadow) {
      App.parts.contactShadow.material.opacity = (App.currentState === App.State.SPEAKING ? 0.35 : 0.45) + Math.sin(t * 1.6) * 0.03;
    }
    if (App.fpvMode) {
      // 第一人称相机：由键盘/触摸驱动位置与朝向
      App.updateFPVCamera(dt);
    } else if (App.focusPart.active) {
      // 点击部位聚焦模式：相机锁定不动，仅用户拖拽/缩放时退出
      App.focusPart.time += dt;
      const t_progress = Math.min(1, App.focusPart.time * 1.0);
      App.camera.position.lerp(App.focusPart.target, t_progress < 1 ? 0.08 : 1.0);
      App.camera.lookAt(App.focusPart.lookAt);
    } else {
      // VR级陀螺仪环绕：相机以模型为中心球面环绕
      const mcY = 1.0;
      const orbitR = App.DEFAULT_CAM_POS.z * App.camZoom; // 环绕半径
      const baseY = mcY + (App.cameraHeight - mcY) * App.camZoom; // 基准高度
      // 球面坐标：gyroYaw控制水平环绕，gyroPitch控制垂直视角
      const orbYaw = App.gyroYaw;
      const orbPitch = App.gyroPitch;
      // 摄像机自动跟踪角色：无操作超过15秒，相机跟随角色移动
      const now = Date.now() / 1000;
      const idleDuration = now - App.lastInteractionTime;
      const gazeBoosted = now < App.gazeBoostUntil; // 交互后短暂触发的心有灵犀窗口
      // 心有灵犀：闲置15秒后只在4秒窗口内触发一次，或交互增益窗口激活时短暂触发
      const gazeIdleWindow = idleDuration >= App.AUTO_CAM_DELAY && idleDuration < App.AUTO_CAM_DELAY + App.MUTUAL_GAZE_WINDOW;
      App.mutualGaze = (gazeIdleWindow || gazeBoosted) && App.currentAvatar;
      // 懒初始化 autoLookTarget
      if (!App.autoLookTarget) App.autoLookTarget = new THREE.Vector3(0, mcY, 0);
      // 相机始终以角色为轨道中心（缩放/旋转都围绕角色）
      const rawLookTarget = App.modelGroup ? new THREE.Vector3(App.modelGroup.position.x, mcY, App.modelGroup.position.z) : new THREE.Vector3(0, mcY, 0);
      App.autoLookTarget.lerp(rawLookTarget, 0.08);
      // 倾斜角度：根据当前轨道半径计算 lookAt 目标偏移
      // 正值 = 向上仰视（lookAt 上移），负值 = 向下俯视（lookAt 下移）
      const cameraTiltRad = App.cameraTiltDeg * Math.PI / 180;
      const effectiveDist = orbitR * Math.cos(orbPitch);
      const tiltOffset = effectiveDist * Math.tan(cameraTiltRad);
      App.targetCamPos.set(App.camOffsetX + App.autoLookTarget.x + orbitR * Math.sin(orbYaw) * Math.cos(orbPitch), baseY + App.camOffsetY + orbitR * Math.sin(orbPitch), App.camOffsetZ + App.autoLookTarget.z + orbitR * Math.cos(orbYaw) * Math.cos(orbPitch));
      // 相机平滑过渡
      App.camera.position.lerp(App.targetCamPos, 0.10);
      // 看向带倾斜偏移的角色位置
      App.camera.lookAt(App.autoLookTarget.x, App.autoLookTarget.y + tiltOffset, App.autoLookTarget.z);
    }

    // 背景星空视差 (与陀螺仪反向，营造远景深度)
    if (App.starField) App.starField.rotation.y = App.gyroYaw * 0.6;

    // 3D 背景模型：缓慢自转 + 陀螺仪视差
    if (App.backgroundGroup) {
      if (App.backgroundAutoRotate) App.backgroundGroup.rotation.y += dt * 0.05;
      // 叠加陀螺仪视差（比角色和星空更弱，营造多层次远景感）
      App.backgroundGroup.rotation.x = App.gyroPitch * 0.4;
      // 注意：自转累积在 .rotation.y，陀螺仪偏移单独用 .rotation.z 微调避免冲突
      App.backgroundGroup.rotation.z = App.gyroYaw * 0.2;
    }

    // 选中高亮跟随目标变换（每帧更新边界框）
    if (App.selectionHelper && App.selectedTarget) {
      try {
        App.selectionHelper.update();
      } catch (_) {}
    }

    // AI 自主触发：长时间无交互时主动开口
    App.checkProactiveTrigger();
    App.renderer.render(App.scene, App.camera);
  };
  App.checkProactiveTrigger = function checkProactiveTrigger() {
    if (!App.ws || App.ws.readyState !== WebSocket.OPEN) return;
    if (App.currentState !== App.State.IDLE) return;
    if (App.isRecording || App.isPlayingQueue) return;
    const now = Date.now();
    if (now - App.lastUserActivityTime < App.PROACTIVE_SILENCE_MS) return;
    if (now - App.lastProactiveTime < App.PROACTIVE_COOLDOWN_MS) return;
    App.lastProactiveTime = now;
    App.ws.send(JSON.stringify({
      type: 'proactive'
    }));
  }; // 计算头部看向相机的局部旋转角度 {x: pitch, y: yaw}
  // 在非探索模式下让角色始终注视用户，增强被重视感
  // 统一约定：模型 mesh 前方向为 +Z，相机位于 +Z，因此头部只需轻微调整
  App.computeHeadLookAt = function computeHeadLookAt(modelRoot) {
    if (!modelRoot || App.fpvMode) return null;
    const localCam = App.camera.position.clone();
    modelRoot.worldToLocal(localCam);
    const dx = localCam.x;
    const dz = localCam.z;
    const dy = localCam.y - 1.4; // 近似头部高度
    const horizDist = Math.max(0.01, Math.hypot(dx, dz));
    const yaw = THREE.MathUtils.clamp(Math.atan2(-dx, dz), -0.6, 0.6);
    const pitch = THREE.MathUtils.clamp(Math.atan2(dy, horizDist), -0.35, 0.25);
    return {
      x: pitch,
      y: yaw
    };
  }; // 计算角色身体应转向的世界Y角度（面向相机）
  // 统一约定：模型 mesh 前方向为 +Z，目标角度 = atan2(dx, dz)
  // 可传入 camPos 计算指定相机位置下的目标角度（用于重置时直接对齐默认视角）
  App.computeBodyFaceCam = function computeBodyFaceCam(modelRoot, camPos) {
    if (!modelRoot || App.fpvMode) return 0;
    const p = camPos || App.camera.position;
    const dx = p.x - modelRoot.position.x;
    const dz = p.z - modelRoot.position.z;
    return Math.atan2(dx, dz);
  };
  App.animateProcedural = function animateProcedural(t, dt, mouthOpen) {
    if (!App.proceduralChar) return;
    // 累积 idle 活力周期
    App.idleEnergy += dt * 0.5;
    // 动作子系统更新（procedural 角色支持三种动作大类）
    App.updatePoseTimer(dt);
    App.updateWalkTimer(dt);
    App.updateTurnAction(dt);
    App.updateDanceAction(dt);
    const poseBlend2 = App.computePoseBlend(); // 同步姿态混合进度
    // 走路位移
    let walkProgress = 0;
    if (App.idleWalkTarget && App.idleWalkProgress < 1) {
      walkProgress = App.idleWalkProgress;
      const walkT = Math.max(0, walkProgress);
      const walkProgressSmooth = walkT * walkT * (3 - 2 * walkT);
      App.proceduralChar.position.x = App.idleWalkStart.x + (App.idleWalkTarget.x - App.idleWalkStart.x) * walkProgressSmooth;
      App.proceduralChar.position.z = App.idleWalkStart.z + (App.idleWalkTarget.z - App.idleWalkStart.z) * walkProgressSmooth;
    }
    // 呼吸 + idle 活力 + pose 简单倾斜（procedural 角色对 POSE 动作的反馈）
    if (App.parts.body) {
      const energy2 = App.currentState === App.State.IDLE ? 0.6 + Math.sin(App.idleEnergy) * 0.4 : 1.0;
      const b = Math.sin(t * 1.6) * (0.015 + 0.008 * energy2);
      const sway = Math.sin(App.idleEnergy * 0.7) * 0.015 * energy2;
      let poseTilt = 0;
      if (App.currentPose !== 'rest' && poseBlend2 > 0) {
        const hash = App.currentPose.split('').reduce((a, c) => a + c.charCodeAt(0), 0);
        poseTilt = ((hash % 2 === 0 ? 1 : -1) * 0.06 + Math.sin(t * 1.5) * 0.02) * poseBlend2;
      }
      App.parts.body.scale.y = 1 + b;
      App.parts.body.scale.x = 1 - b * 0.5;
      App.parts.body.rotation.z = sway + poseTilt;
    }
    // 松手后 userRotY/userRotX 缓慢衰减回 0：身体回正 + 自动转身面向用户
    if (!App.isDragging && !App.fpvMode) {
      App.userRotY *= 0.96;
      App.userRotX *= 0.96;
      if (Math.abs(App.userRotY) < 0.001) App.userRotY = 0;
      if (Math.abs(App.userRotX) < 0.001) App.userRotX = 0;
    }
    // 心有灵犀：保持面向用户的注视，不做额外的背向偏转
    if (App.mutualGaze && !App.wasMutualGaze) {
      App.wasMutualGaze = true;
    }
    if (!App.mutualGaze) App.wasMutualGaze = false;
    const isTurning = App.currentAction && App.currentAction.type === App.ActionType.TURN;
    const isWalking = App.idleWalkTarget && App.idleWalkProgress < 1;
    const bodyMicroWobble2 = App.mutualGaze ? 0 : Math.sin(t * 0.35) * 0.008;
    let targetY;
    if (isTurning) {
      targetY = App.smoothRotY;
    } else if (isWalking) {
      targetY = App.walkFacingAngle + App.userRotY + App.gyroYaw * 0.15 + bodyMicroWobble2;
    } else {
      targetY = App.computeBodyFaceCam(App.proceduralChar) + App.userRotY + App.gyroYaw * 0.15 + bodyMicroWobble2;
    }
    const targetX = App.userRotX + App.gyroPitch * 0.15;
    // 自适应旋转平滑：心有灵犀时也要柔和，不能生硬
    // 归一化角度差到 [-PI, PI]，确保走最短路径（修复转身后不自动回看的问题）
    let rotYDiff2 = targetY - App.smoothRotY;
    while (rotYDiff2 > Math.PI) rotYDiff2 -= Math.PI * 2;
    while (rotYDiff2 < -Math.PI) rotYDiff2 += Math.PI * 2;
    const baseRate2 = App.mutualGaze ? 0.035 : 0.03;
    const rotYRate2 = baseRate2 + 0.04 / (1 + Math.abs(rotYDiff2) * 4);
    if (!isTurning) {
      App.smoothRotY += rotYDiff2 * rotYRate2;
      App.smoothRotX = App.lerp(App.smoothRotX, targetX, 0.06);
    }
    App.proceduralChar.rotation.z = Math.sin(t * 0.8) * 0.015;
    App.proceduralChar.rotation.y = App.smoothRotY;
    App.proceduralChar.position.y = Math.sin(t * 1.6) * 0.01 + (walkProgress > 0 ? Math.abs(Math.sin(walkProgress * Math.PI * 4)) * 0.015 : 0);
    App.proceduralChar.rotation.x = App.smoothRotX;

    // 头部 (非探索模式始终看向相机 + 状态微调)
    if (App.parts.head) {
      // 心有灵犀：轻微歪头注视，幅度小、过渡慢
      if (App.mutualGaze) App.gazeHeadTiltAcc = App.lerp(App.gazeHeadTiltAcc, 0.05, 0.025);else App.gazeHeadTiltAcc = App.lerp(App.gazeHeadTiltAcc, 0, 0.04);
      const look = App.computeHeadLookAt(App.proceduralChar);
      let tY, tX;
      if (look) {
        tY = look.y + Math.sin(t * 0.5) * 0.04;
        tX = look.x + Math.sin(t * 0.7) * 0.02 + App.gazeHeadTiltAcc;
      } else {
        tY = Math.sin(t * 0.5) * 0.08;
        tX = Math.sin(t * 0.7) * 0.04 + App.gazeHeadTiltAcc;
      }
      if (App.currentState === App.State.THINKING) {
        tX += -0.15 + Math.sin(t * 1.5) * 0.03;
        tY += 0.1;
      } else if (App.currentState === App.State.LISTENING) {
        tX += 0.06;
        tY += -0.06;
      } else if (App.currentState === App.State.SPEAKING) {
        tY += Math.sin(t * 3) * 0.08;
        tX += Math.sin(t * 2) * 0.03;
      }
      App.parts.head.rotation.y += (tY - App.parts.head.rotation.y) * 0.08;
      App.parts.head.rotation.x += (tX - App.parts.head.rotation.x) * 0.08;
    }

    // 眨眼（增强版，统一使用 App.blinkType / blinkPhase / blinkDuration）
    if (App.parts.eyeL && App.parts.eyeR) {
      App.blinkTimer += dt;
      const isWink = (App.blinkType === 'winkLeft' || App.blinkType === 'winkRight');
      const isCloseHold = (App.blinkType === 'closeHold');
      if (isWink || isCloseHold || App.blinkTimer > App.nextBlinkAt) {
        const duration = App.blinkDuration;
        let elapsed = App.blinkPhase * duration;
        if ((isWink || isCloseHold) && App.blinkPhase === 0) {
          App.blinkTimer = App.nextBlinkAt;
        }
        elapsed += dt;
        App.blinkPhase = Math.min(1, elapsed / duration);
        const p = App.blinkPhase;

        if (App.blinkType === 'double') {
          const t = p * 2;
          let s = 0;
          if (t < 1) s = Math.abs(Math.cos(t * Math.PI));
          else if (t < 2) s = Math.abs(Math.cos((t - 0.15) * Math.PI));
          s = Math.max(0, Math.min(1, s));
          App.parts.eyeL.scale.y = s;
          App.parts.eyeR.scale.y = s;
        } else if (App.blinkType === 'winkLeft') {
          const s = Math.abs(Math.cos(p * Math.PI));
          App.parts.eyeL.scale.y = s;
          App.parts.eyeR.scale.y = 1;
        } else if (App.blinkType === 'winkRight') {
          const s = Math.abs(Math.cos(p * Math.PI));
          App.parts.eyeL.scale.y = 1;
          App.parts.eyeR.scale.y = s;
        } else {
          const s = Math.abs(Math.cos(p * Math.PI));
          App.parts.eyeL.scale.y = s;
          App.parts.eyeR.scale.y = s;
        }

        if (p >= 1) {
          App.parts.eyeL.scale.y = 1;
          App.parts.eyeR.scale.y = 1;
          App.blinkPhase = 0;
          App.blinkTimer = 0;
          App.scheduleNextBlink();
          App.nextBlinkAt = App.blinkTimer + 2 + Math.random() * 4;
        }
      }
    }

    // 瞳孔
    if (App.parts.pupilL && App.parts.pupilR) {
      const px = Math.sin(t * 0.6) * 0.015,
        py = Math.sin(t * 0.4) * 0.01;
      App.parts.pupilL.position.x = px;
      App.parts.pupilL.position.y = py;
      App.parts.pupilR.position.x = px;
      App.parts.pupilR.position.y = py;
    }

    // 嘴巴
    if (App.parts.mouth) {
      let mo = mouthOpen;
      if (App.currentState === App.State.IDLE) mo = Math.max(0, Math.sin(t * 1.6)) * 0.08;else if (App.currentState === App.State.THINKING) mo = 0.03;
      // mouthOpen 范围 0~0.12，procedural 角色嘴部只做小幅开合
      const tSY = 0.30 + mo * 0.8;
      App.parts.mouth.scale.y += (tSY - App.parts.mouth.scale.y) * 0.3;
      App.parts.mouth.scale.x += (1.25 - mo * 0.12 - App.parts.mouth.scale.x) * 0.3;
    }

    // 手臂（增加 idle 活力微摆）
    if (App.parts.armL && App.parts.armR) {
      const energy2 = App.currentState === App.State.IDLE ? 0.6 + Math.sin(App.idleEnergy) * 0.4 : 1.0;
      const idleSwingL = App.currentState === App.State.IDLE ? Math.sin(App.idleEnergy * 0.9) * 0.08 * energy2 : 0;
      const idleSwingR = App.currentState === App.State.IDLE ? -Math.sin(App.idleEnergy * 0.9) * 0.08 * energy2 : 0;
      let aL = 0.25 + idleSwingL,
        aR = -0.25 + idleSwingR;
      if (App.currentState === App.State.SPEAKING) {
        aL = 0.25 + Math.sin(t * 4) * 0.15;
        aR = -0.25 - Math.sin(t * 4 + 1) * 0.15;
      } else if (App.currentState === App.State.THINKING) {
        aR = -1.4;
      } else if (App.currentState === App.State.LISTENING) {
        aL = 0.4;
        aR = -0.4;
      }
      App.parts.armL.rotation.z += (aL - App.parts.armL.rotation.z) * 0.08;
      App.parts.armR.rotation.z += (aR - App.parts.armR.rotation.z) * 0.08;
    }
    // 点击摇摆
    App.applyClickWobble(App.proceduralChar);
  };
  /* 安全设置 VRM 表情：仅在 expressionMap 中存在时才设置 */
  App.setVRMExpression = function setVRMExpression(exp, name, value) {
    if (!exp || !exp.expressionMap) return false;
    if (!exp.expressionMap[name]) return false;
    exp.setValue(name, value);
    return true;
  };
  /* 查找可用的表情名 (VRM 1.0 用小写，VRM 0.x 用大写) */
  App.findExpression = function findExpression(exp, candidates) {
    if (!exp || !exp.expressionMap) return null;
    for (const name of candidates) {
      if (exp.expressionMap[name]) return name;
    }
    return null;
  }; // 缓存表情名，避免每帧查找
  App.exprNames = {
    mouth: null,
    blink: null,
    blinkLeft: null,
    blinkRight: null,
    happy: null,
    angry: null,
    sad: null,
    surprised: null,
    relaxed: null,
    thoughtful: null,
    sorrow: null,
    fun: null,
    lookUp: null,
    lookDown: null,
    neutral: null
  };
  App.refreshExprNames = function refreshExprNames() {
    if (!App.vrm || !App.vrm.expressionManager) {
      App.exprNames = {
        mouth: null,
        blink: null,
        blinkLeft: null,
        blinkRight: null,
        happy: null,
        angry: null,
        sad: null,
        surprised: null,
        relaxed: null,
        thoughtful: null,
        sorrow: null,
        fun: null,
        lookUp: null,
        lookDown: null,
        neutral: null
      };
      return;
    }
    const exp = App.vrm.expressionManager;
    App.exprNames.mouth = App.findExpression(exp, ['aa', 'A', 'oh', 'O', 'ou', 'U', 'ih', 'I']);
    App.exprNames.blink = App.findExpression(exp, ['blink', 'Blink', 'blinkLeft', 'BlinkL']);
    App.exprNames.blinkLeft = App.findExpression(exp, ['blinkLeft', 'BlinkL', 'blink_L', 'Blink_L', 'winkLeft', 'WinkLeft']);
    App.exprNames.blinkRight = App.findExpression(exp, ['blinkRight', 'BlinkR', 'blink_R', 'Blink_R', 'winkRight', 'WinkRight']);
    App.exprNames.happy = App.findExpression(exp, ['happy', 'Joy', 'fun', 'Fun']);
    App.exprNames.angry = App.findExpression(exp, ['angry', 'Angry', 'mad', 'Mad']);
    App.exprNames.sad = App.findExpression(exp, ['sad', 'Sad', 'sorrow', 'Sorrow']);
    App.exprNames.surprised = App.findExpression(exp, ['surprised', 'Surprised', 'surprise', 'Surprise', 'shock', 'Shock']);
    App.exprNames.relaxed = App.findExpression(exp, ['relaxed', 'Relaxed', 'peaceful', 'Peaceful', 'calm', 'Calm']);
    App.exprNames.thoughtful = App.findExpression(exp, ['thoughtful', 'Thoughtful', 'think', 'Think']);
    App.exprNames.sorrow = App.findExpression(exp, ['sorrow', 'Sorrow', 'sad', 'Sad']);
    App.exprNames.fun = App.findExpression(exp, ['fun', 'Fun', 'happy', 'Joy']);
    App.exprNames.lookUp = App.findExpression(exp, ['lookUp', 'LookUp', 'lookup', 'Lookup', 'browUp', 'BrowUp']);
    App.exprNames.lookDown = App.findExpression(exp, ['lookDown', 'LookDown', 'lookdown', 'Lookdown', 'browDown', 'BrowDown']);
    App.exprNames.neutral = App.findExpression(exp, ['neutral', 'Neutral']);
    // 列出可用表情
    const mapped = [];
    for (const k in App.exprNames) { if (App.exprNames[k]) mapped.push(k + ':' + App.exprNames[k]); }
    console.log('[VRM] 表情映射 →', mapped.join(', ') || '(无可用表情)');
  };
  /* ========== 表情状态机 ========== */
  // 表情值：每个表情的当前值 0-1，平滑过渡
  App.exprValues = {};
  App.exprTargets = {};
  App.exprChangeTimer = 0;
  App.exprChangeInterval = 4.0; // 空闲时切换表情的间隔
  App.exprRandomPool = []; // 空闲时从可用表情池中随机选取

  App.initExpressionState = function initExpressionState() {
    App.exprValues = {};
    App.exprTargets = {};
    for (const k in App.exprNames) {
      if (App.exprNames[k]) {
        App.exprValues[k] = 0;
        App.exprTargets[k] = 0;
      }
    }
    // 构建空闲随机表情池：排除 mouth/blink/blinkLeft/blinkRight/lookUp/lookDown/neutral
    const emotionKeys = ['happy', 'fun', 'relaxed', 'surprised', 'thoughtful', 'sad', 'angry', 'sorrow'];
    App.exprRandomPool = emotionKeys.filter(k => App.exprNames[k]);
  };
  // 不在这里驱动的表情（由外部独立控制）
  App.EXPR_EXTERNAL_KEYS = new Set(['mouth', 'blink', 'blinkLeft', 'blinkRight']);
  // 说话时会干扰嘴型的情绪表情（部分 VRM 模型的 happy/surprised 包含嘴部 blendshape）
  App.EXPR_MOUTH_BLOCK_KEYS = new Set(['happy', 'fun', 'surprised', 'sad', 'angry', 'sorrow']);

  /* ========== 眨眼增强系统：五种等概率 ========== */
  App.blinkType = 'normal'; // 'normal' | 'slow' | 'double' | 'winkLeft' | 'winkRight' | 'closeHold'
  App.blinkPhase = 0; // 当前眨眼阶段进度 0~1
  App.blinkDuration = 0.15; // 当前眨眼的持续时间

  // 调度下一个眨眼类型（五种等概率各 20%）
  App.scheduleNextBlink = function scheduleNextBlink() {
    const r = Math.random();
    if (r < 0.2) {
      // 20% 普通眨眼
      App.blinkType = 'normal';
      App.blinkDuration = 0.12 + Math.random() * 0.08; // 0.12~0.20s
    } else if (r < 0.4) {
      // 20% 慢眨眼（放松、满足感）
      App.blinkType = 'slow';
      App.blinkDuration = 0.35 + Math.random() * 0.2; // 0.35~0.55s
    } else if (r < 0.6) {
      // 20% 双连眨
      App.blinkType = 'double';
      App.blinkDuration = 0.1;
    } else if (r < 0.8) {
      // 20% 挤眼（慢挤，50%左眼50%右眼）
      App.blinkType = Math.random() < 0.5 ? 'winkLeft' : 'winkRight';
      App.blinkDuration = 0.35 + Math.random() * 0.2; // 0.35~0.55s 与慢眨眼同速
    } else {
      // 20% 全闭眼停留（仅空闲时，非空闲降级为慢眨眼）
      if (App.currentState === App.State.IDLE) {
        App.blinkType = 'closeHold';
        App.blinkDuration = 0.7 + Math.random() * 0.6; // 0.7~1.3s
      } else {
        App.blinkType = 'slow';
        App.blinkDuration = 0.35 + Math.random() * 0.2;
      }
    }
    App.blinkPhase = 0;
  };

  // 根据状态决定目标表情
  App.computeExprTargetsByState = function computeExprTargetsByState() {
    const targets = {};
    for (const k in App.exprNames) { if (App.exprNames[k]) targets[k] = 0; }
    switch (App.currentState) {
      case App.State.IDLE:
        // 空闲：默认微笑+放松，偶尔随机切换
        targets.happy = 0.4;
        targets.relaxed = 0.3;
        break;
      case App.State.THINKING:
        targets.thoughtful = 0.5;
        targets.relaxed = 0.2;
        // 微微皱眉思考
        if (App.exprNames.sad) targets.sad = 0.15;
        break;
      case App.State.LISTENING:
        // 倾听：兴趣/惊讶+微笑
        targets.happy = 0.35;
        if (App.exprNames.surprised) targets.surprised = 0.3;
        break;
      case App.State.SPEAKING:
        // 说话时只保留眼睛/眉毛/脸颊的表情，避免嘴部相关表情干扰 lipsync
        // 惊讶/开心等表情可能包含嘴部 blendshape，说话时排除这些
        targets.happy = 0.2;
        targets.fun = 0.25;
        if (App.exprNames.relaxed) targets.relaxed = 0.15;
        break;
    }
    return targets;
  };

  // 在空闲状态随机切换表情
  App.updateIdleExpression = function updateIdleExpression(dt) {
    // 原有随机表情切换逻辑
    if (App.currentState !== App.State.IDLE) {
      App.exprChangeTimer = 0;
      App.exprChangeInterval = 4 + Math.random() * 6;
      return;
    }
    App.exprChangeTimer += dt;
    if (App.exprChangeTimer >= App.exprChangeInterval && App.exprRandomPool.length > 0) {
      App.exprChangeTimer = 0;
      App.exprChangeInterval = 4 + Math.random() * 6; // 4~10秒变化一次
      // 合并 lookUp/lookDown 到表情切换中（小概率触发）
      const pool = [...App.exprRandomPool];
      if (App.exprNames.lookUp) pool.push('lookUp');
      if (App.exprNames.lookDown) pool.push('lookDown');
      // 随机选一个表情突出显示
      const pick = pool[Math.floor(Math.random() * pool.length)];
      for (const k in App.exprTargets) {
        App.exprTargets[k] = 0;
      }
      // lookUp/lookDown 强度稍低，避免鬼脸
      if (pick === 'lookUp' || pick === 'lookDown') {
        App.exprTargets[pick] = 0.35 + Math.random() * 0.25;
      } else {
        App.exprTargets[pick] = 0.5;
      }
      // 保留基础微笑
      if (App.exprNames.happy && pick !== 'happy') App.exprTargets.happy = 0.2;
      if (App.exprNames.relaxed && pick !== 'relaxed') App.exprTargets.relaxed = 0.15;
    }
  };

  // 更新所有表情值（平滑过渡 + 根据状态设置目标）
  App.updateExpressions = function updateExpressions(dt) {
    const exp = App.vrm && App.vrm.expressionManager;
    if (!exp || !exp.expressionMap) return;
    // 首次初始化
    if (Object.keys(App.exprValues).length === 0) App.initExpressionState();
    // 根据状态设定目标表情（基础值）
    const baseTargets = App.computeExprTargetsByState();
    // 合并空闲随机表情
    App.updateIdleExpression(dt);
    // 合并：空闲随机优先级高于基础
    if (App.currentState === App.State.IDLE && App.exprChangeTimer > 0) {
      // 空闲随机模式已在 exprTargets 中设定，保留
    } else {
      // 非空闲或未触发随机时，使用基础目标
      for (const k in baseTargets) {
        App.exprTargets[k] = baseTargets[k];
      }
    }
    // 平滑过渡并设置（排除 mouth/blink，它们由外部独立控制）
    // 说话时额外屏蔽可能包含嘴部 blendshape 的情绪表情
    const isSpeaking = App.currentState === App.State.SPEAKING;
    for (const k in App.exprTargets) {
      if (!App.exprNames[k] || App.EXPR_EXTERNAL_KEYS.has(k)) continue;
      if (isSpeaking && App.EXPR_MOUTH_BLOCK_KEYS.has(k)) continue;
      const target = App.exprTargets[k] || 0;
      App.exprValues[k] = App.lerp(App.exprValues[k] || 0, target, 0.04);
      if (Math.abs(App.exprValues[k] - target) < 0.005) App.exprValues[k] = target;
      // 很小的值直接清零避免残留
      if (App.exprValues[k] < 0.01 && target === 0) App.exprValues[k] = 0;
      exp.setValue(App.exprNames[k], App.exprValues[k]);
    }
  };
  /* 调优弹簧骨骼：增大阻尼、降低刚度，防止头发衣物乱摆穿模 */
  App.calmSpringBones = function calmSpringBones() {
    if (!App.vrm || !App.vrm.springBoneManager) {
      console.log('[VRM] 无弹簧骨骼管理器');
      return;
    }
    const mgr = App.vrm.springBoneManager;
    // three-vrm v3: joints 数组 (可能叫 joints / _sortedJoints)
    const joints = mgr.joints || mgr._sortedJoints || Array.from(mgr._joints || []);
    if (!joints || joints.length === 0) {
      console.log('[VRM] 弹簧骨骼列表为空');
      return;
    }

    // 检查碰撞体
    const colliderGroups = mgr.colliderGroups || mgr._colliderGroups || [];
    console.log(`[VRM] 碰撞体组数: ${colliderGroups.length}`);
    let count = 0;
    for (const j of joints) {
      const s = j.settings;
      if (!s) continue;
      // 增大阻尼 (默认 0.4 → 0.9)：减少震荡
      s.dragForce = Math.min(0.95, (s.dragForce ?? 0.4) * 2.5);
      // 降低刚度 (默认 1.0 → 0.35)：减少回弹力度
      s.stiffness = Math.min(0.4, (s.stiffness ?? 1) * 0.35);
      // 降低重力 (减少下垂幅度)
      s.gravityPower = (s.gravityPower ?? 0) * 0.4;
      count++;
    }
    console.log(`[VRM] 弹簧骨骼调优完成: ${count} 个关节 (dragForce↑ stiffness↓ gravity↓)`);

    // 如果模型无碰撞体，添加基础碰撞球防止穿模
    if (colliderGroups.length === 0) {
      App.addBodyColliders(mgr);
    }
  };
  /* 为缺乏碰撞体的模型添加基础身体碰撞球 */
  App.addBodyColliders = function addBodyColliders(mgr) {
    if (!App.vrm.humanoid) return;
    const h = App.vrm.humanoid;
    // 在关键骨骼上添加球体碰撞器
    const colliderDefs = [{
      bone: 'head',
      offset: [0, 0, 0],
      radius: 0.09
    }, {
      bone: 'chest',
      offset: [0, 0, 0],
      radius: 0.12
    }, {
      bone: 'spine',
      offset: [0, 0, 0],
      radius: 0.10
    }, {
      bone: 'hips',
      offset: [0, 0, 0],
      radius: 0.12
    }, {
      bone: 'leftUpperArm',
      offset: [0, -0.1, 0],
      radius: 0.06
    }, {
      bone: 'rightUpperArm',
      offset: [0, -0.1, 0],
      radius: 0.06
    }];
    let added = 0;
    for (const def of colliderDefs) {
      const boneNode = h.getNormalizedBoneNode(def.bone);
      if (!boneNode) continue;
      try {
        // three-vrm v3 API: 创建碰撞体组
        const group = {
          colliders: [{
            position: new THREE.Vector3(def.offset[0], def.offset[1], def.offset[2]),
            radius: def.radius
          }],
          bones: new Set() // empty for now
        };
        // 尝试不同的 API 注册方式
        if (typeof mgr.addColliderGroup === 'function') {
          mgr.addColliderGroup(def.bone, group);
          added++;
        }
      } catch (e) {/* API 不兼容，跳过 */}
    }
    if (added > 0) {
      console.log(`[VRM] 添加了 ${added} 个身体碰撞球`);
    } else {
      console.log('[VRM] 碰撞体 API 不兼容，仅靠阻尼+平滑防穿模');
    }
  }; // VRM 放松站姿常量（normalized 空间：人形面向 -Z，+Y 上）
  // 左臂沿 -X 方向延伸 → 绕 Z 正向旋转使手臂下垂
  // 右臂沿 +X 方向延伸 → 绕 Z 负向旋转使手臂下垂
  App.ARM_REST_Z = 1.35; // 加载后立即应用放松站姿（消除 T-pose）
  App.applyVrmRestPose = function applyVrmRestPose() {
    const B = App.vrmBones;
    if (B.leftUpperArm) B.leftUpperArm.rotation.set(0, 0, App.ARM_REST_Z);
    if (B.rightUpperArm) B.rightUpperArm.rotation.set(0, 0, -App.ARM_REST_Z);
    if (B.leftLowerArm) B.leftLowerArm.rotation.set(-0.15, 0, 0);
    if (B.rightLowerArm) B.rightLowerArm.rotation.set(-0.15, 0, 0);
    if (B.leftHand) B.leftHand.rotation.set(0, 0, 0.1);
    if (B.rightHand) B.rightHand.rotation.set(0, 0, -0.1);
    // 让 VRM 立即更新一次
    if (App.vrm && App.vrm.humanoid) App.vrm.humanoid.update();
  };
  App.animateModel = function animateModel(t, dt, mouthOpen) {
    if (!App.modelGroup) return;
    const B = App.vrmBones;

    // 动作子系统更新（pose/walk/turn）
    App.updatePoseTimer(dt);
    App.updateWalkTimer(dt);
    App.updateTurnAction(dt);
    const blend = App.computePoseBlend(); // 当前姿态混合因子 0-1
    const po = App.ALL_POSES[App.currentPose] || App.ALL_POSES.rest; // 当前姿态偏移（统一姿态库）

    // 辅助：对姿态偏移做混合获取
    function poseVal(bone, axis, base) {
      const cur = po[bone] && po[bone][axis] !== undefined ? po[bone][axis] : 0;
      // 退出时用前一帧残留渐隐，进入时干净切入
      return base + cur * blend;
    }
    function poseValAxis(bone, axis) {
      return po[bone] && po[bone][axis] !== undefined ? po[bone][axis] : 0;
    }

    // 随机移动位置 + 行走弹跳
    let walkProgress = 0;
    let walkProgressSmooth = 0;
    if (App.idleWalkTarget && App.idleWalkProgress < 1) {
      walkProgress = App.idleWalkProgress;
      // smoothstep 起步/停步更自然，腿部动画与平滑后的真实位移同步
      const walkT = Math.max(0, walkProgress);
      walkProgressSmooth = walkT * walkT * (3 - 2 * walkT);
      App.modelGroup.position.x = App.idleWalkStart.x + (App.idleWalkTarget.x - App.idleWalkStart.x) * walkProgressSmooth;
      App.modelGroup.position.z = App.idleWalkStart.z + (App.idleWalkTarget.z - App.idleWalkStart.z) * walkProgressSmooth;
    }

    // 松手后 userRotY/userRotX 缓慢衰减回 0：身体回正 + 自动转身面向用户
    if (!App.isDragging && !App.fpvMode) {
      App.userRotY *= 0.96;
      App.userRotX *= 0.96;
      if (Math.abs(App.userRotY) < 0.001) App.userRotY = 0;
      if (Math.abs(App.userRotX) < 0.001) App.userRotX = 0;
    }
    // 计算一次相机朝向，避免重复调用
    const camFaceY = App.computeBodyFaceCam(App.modelGroup);
    // 随机移动：行走时身体直接面向移动方向；停止后 smoothWalkFaceOff 过渡回看相机
    if (App.idleWalkTarget && App.idleWalkProgress < 1) {
      let rawFaceOff = App.walkFacingAngle - camFaceY;
      // 归一化到 [-PI, PI]
      while (rawFaceOff > Math.PI) rawFaceOff -= Math.PI * 2;
      while (rawFaceOff < -Math.PI) rawFaceOff += Math.PI * 2;
      App.smoothWalkFaceOff = App.lerp(App.smoothWalkFaceOff, rawFaceOff, 0.04);
    } else {
      App.smoothWalkFaceOff = App.lerp(App.smoothWalkFaceOff, 0, 0.05);
    }
    // 心有灵犀：保持面向用户的注视，不做额外的背向偏转
    if (App.mutualGaze && !App.wasMutualGaze) {
      App.wasMutualGaze = true;
    }
    if (!App.mutualGaze) App.wasMutualGaze = false;
    const bodyMicroWobble = App.mutualGaze ? 0 : Math.sin(t * 0.35) * 0.008;
    // 行走时身体直接面向移动方向，避免相机角度变化导致漂移；停止后 smoothWalkFaceOff 自动过渡回看相机
    const isTurning = App.currentAction && App.currentAction.type === App.ActionType.TURN;
    const baseTargetY = walkProgress > 0 && App.idleWalkTarget ? App.walkFacingAngle : isTurning ? App.smoothRotY : camFaceY + App.smoothWalkFaceOff;
    const targetY = isTurning ? App.smoothRotY : baseTargetY + App.userRotY + App.gyroYaw * 0.15 + bodyMicroWobble;
    const targetX = App.userRotX + App.gyroPitch * 0.15;
    // 自适应旋转平滑：心有灵犀 / 行走转身都要柔和自然
    // 归一化角度差到 [-PI, PI]，确保走最短路径（修复转身后不自动回看的问题）
    let rotYDiff = targetY - App.smoothRotY;
    while (rotYDiff > Math.PI) rotYDiff -= Math.PI * 2;
    while (rotYDiff < -Math.PI) rotYDiff += Math.PI * 2;
    const baseRate = App.mutualGaze ? 0.035 : 0.03;
    const rotYRate = baseRate + 0.04 / (1 + Math.abs(rotYDiff) * 4);
    if (isTurning) {
      // 转圈动作自行控制 rotation.y，不拉回相机方向
    } else if (App.fpvJustExited) {
      App.smoothRotY = targetY;
      App.smoothRotX = targetX;
      App.fpvJustExited = false;
    } else {
      App.smoothRotY += rotYDiff * rotYRate;
      App.smoothRotX = App.lerp(App.smoothRotX, targetX, 0.06);
    }
    App.modelGroup.rotation.y = App.smoothRotY;
    App.modelGroup.rotation.x = App.smoothRotX;
    // 行走弹跳：与步数挂钩，幅度适中
    const stepsPerSegment = walkProgress > 0 ? Math.max(1, Math.hypot(App.idleWalkTarget.x - App.idleWalkStart.x, App.idleWalkTarget.z - App.idleWalkStart.z) / App.WALK_STEP_LENGTH) : 1;
    const walkBob = walkProgress > 0 ? Math.abs(Math.sin(walkProgressSmooth * Math.PI * 2 * stepsPerSegment)) * 0.025 : 0;
    App.modelGroup.position.y = Math.sin(t * 1.2) * 0.003 + walkBob;

    // --- 脊椎 / 呼吸 + 姿态偏移 + idle 活力摆动 ---
    const energy = App.currentState === App.State.IDLE ? 0.6 + Math.sin(App.idleEnergy) * 0.4 : 1.0;
    const breathAmp = 0.008 + (App.currentState === App.State.IDLE ? 0.006 : 0);
    const bodySwayY = App.currentState === App.State.IDLE ? Math.sin(App.idleEnergy * 0.7) * 0.012 * energy : 0;
    const bodySwayZ = App.currentState === App.State.IDLE ? Math.cos(App.idleEnergy * 0.5) * 0.006 * energy : 0;
    if (B.spine) B.spine.rotation.x = App.lerp(B.spine.rotation.x, poseVal('spine', 'x', Math.sin(t * 1.2) * breathAmp), 0.08);
    if (B.spine) B.spine.rotation.y = App.lerp(B.spine.rotation.y, poseVal('spine', 'y', bodySwayY), 0.08);
    if (B.spine) B.spine.rotation.z = App.lerp(B.spine.rotation.z, poseVal('spine', 'z', bodySwayZ), 0.08);
    if (B.chest) B.chest.rotation.x = App.lerp(B.chest.rotation.x, Math.sin(t * 1.2) * (breathAmp * 0.75) + poseValAxis('chest', 'x') * blend, 0.08);
    if (B.upperChest) B.upperChest.rotation.x = App.lerp(B.upperChest.rotation.x, Math.sin(t * 1.2) * (breathAmp * 0.5), 0.08);

    // --- 颈部 + 姿态偏移 ---
    if (B.neck) {
      let nz = Math.sin(t * 0.5) * 0.015 + poseValAxis('neck', 'z') * blend;
      B.neck.rotation.z = App.lerp(B.neck.rotation.z, nz, 0.06);
    }

    // --- 头部 (看向相机 + 状态微调 + 姿态偏移) ---
    // 心有灵犀：轻微歪头注视，幅度小、过渡慢
    if (App.mutualGaze) App.gazeHeadTiltAcc = App.lerp(App.gazeHeadTiltAcc, 0.05, 0.025);else App.gazeHeadTiltAcc = App.lerp(App.gazeHeadTiltAcc, 0, 0.04);
    if (B.head) {
      const look = App.computeHeadLookAt(App.modelGroup);
      let tY,
        tX,
        tZ = 0;
      const headMicroAmp = App.mutualGaze ? 0.008 : 0.03;
      if (look) {
        tY = look.y + Math.sin(t * 0.4) * headMicroAmp;
        tX = look.x + Math.sin(t * 0.6) * headMicroAmp * 0.5 + App.gazeHeadTiltAcc;
      } else {
        tY = Math.sin(t * 0.4) * 0.05;
        tX = Math.sin(t * 0.6) * 0.025 + App.gazeHeadTiltAcc;
      }
      if (App.currentState === App.State.THINKING) {
        tX += -0.1;
        tY += 0.08;
      } else if (App.currentState === App.State.LISTENING) {
        tX += 0.05;
        tY += -0.04;
      } else if (App.currentState === App.State.SPEAKING) {
        tY += Math.sin(t * 2.5) * 0.04;
        tX += Math.sin(t * 1.8) * 0.015;
      }
      // 姿态偏移（混合因子控制）
      tX += poseValAxis('head', 'x') * blend;
      tY += poseValAxis('head', 'y') * blend;
      tZ = App.lerp(tZ, poseValAxis('head', 'z') * blend, 0.06);
      B.head.rotation.y = App.lerp(B.head.rotation.y, tY, 0.08);
      B.head.rotation.x = App.lerp(B.head.rotation.x, tX, 0.08);
      if (Math.abs(poseValAxis('head', 'z')) > 0.001 || Math.abs(tZ) > 0.001) B.head.rotation.z = tZ;
    }

    // --- 行走摆臂（与腿部对侧，左臂配右腿，前后摆动，优雅小幅度） ---
    const walkCyclePhase = walkProgress > 0 ? walkProgressSmooth * Math.PI * 2 * stepsPerSegment : 0;
    const ARM_SWING_AMP = 0.18; // 前后摆臂幅度（rad），优雅风流
    // 左臂与左腿反相，右臂与左臂反相
    const leftArmSwing = walkProgress > 0 ? -Math.sin(walkCyclePhase) * ARM_SWING_AMP : 0;
    const rightArmSwing = walkProgress > 0 ? Math.sin(walkCyclePhase) * ARM_SWING_AMP : 0;
    const idleArmSwing = App.currentState === App.State.IDLE && walkProgress <= 0 ? Math.sin(App.idleEnergy * 0.9) * 0.035 * energy : 0;
    if (B.leftUpperArm) {
      // 摆臂主要用 rotation.x（前后方向），z 保持 rest pose 只做呼吸微动
      let tz = App.ARM_REST_Z + Math.sin(t * 1.2) * 0.012 + idleArmSwing;
      let tx = Math.sin(t * 1.2 + 0.3) * 0.015 + Math.sin(t * 0.7) * 0.008 * energy + leftArmSwing;
      tz += poseValAxis('leftUpperArm', 'z') * blend;
      tx += poseValAxis('leftUpperArm', 'x') * blend;
      if (App.currentState === App.State.SPEAKING) {
        tx += Math.sin(t * 3) * 0.04;
        tz += Math.sin(t * 2.5) * 0.015;
      }
      B.leftUpperArm.rotation.z = App.lerp(B.leftUpperArm.rotation.z, tz, 0.07);
      B.leftUpperArm.rotation.x = App.lerp(B.leftUpperArm.rotation.x, tx, 0.07);
    }
    if (B.leftLowerArm) {
      // 肘部随摆臂自然弯曲（前摆时微屈）
      let elbowBend = walkProgress > 0 ? Math.max(0, -Math.sin(walkCyclePhase)) * 0.18 : 0;
      let tx = -0.15 + Math.sin(t * 1.2) * 0.015 + elbowBend + idleArmSwing * 0.5;
      tx += poseValAxis('leftLowerArm', 'x') * blend;
      if (App.currentState === App.State.SPEAKING) tx += Math.sin(t * 3 + 0.5) * 0.03;
      B.leftLowerArm.rotation.x = App.lerp(B.leftLowerArm.rotation.x, tx, 0.07);
    }

    // --- 右臂 + 姿态 + 行走摆臂（与左臂反相） + idle 活力微摆 ---
    if (B.rightUpperArm) {
      let tz = -App.ARM_REST_Z + Math.sin(t * 1.2 + 0.5) * 0.012 - idleArmSwing;
      let tx = Math.sin(t * 1.2) * 0.015 + Math.sin(t * 0.65) * 0.008 * energy + rightArmSwing;
      tz += poseValAxis('rightUpperArm', 'z') * blend;
      tx += poseValAxis('rightUpperArm', 'x') * blend;
      if (App.currentState === App.State.SPEAKING) {
        tx += -Math.sin(t * 3) * 0.04;
        tz += -Math.sin(t * 2.5) * 0.015;
      }
      B.rightUpperArm.rotation.z = App.lerp(B.rightUpperArm.rotation.z, tz, 0.07);
      B.rightUpperArm.rotation.x = App.lerp(B.rightUpperArm.rotation.x, tx, 0.07);
    }
    if (B.rightLowerArm) {
      let elbowBend = walkProgress > 0 ? Math.max(0, Math.sin(walkCyclePhase)) * 0.18 : 0;
      let tx = -0.15 + Math.sin(t * 1.2) * 0.015 + elbowBend - idleArmSwing * 0.5;
      tx += poseValAxis('rightLowerArm', 'x') * blend;
      B.rightLowerArm.rotation.x = App.lerp(B.rightLowerArm.rotation.x, tx, 0.07);
    }

    // --- 手部 (姿态驱动 + 呼吸微动) ---
    // 姿态可同时控制 rotation.x(屈伸) / rotation.y(内外转) / rotation.z(旋转)
    if (B.leftHand) {
      let tx = Math.sin(t * 1.3) * 0.015 + poseValAxis('leftHand', 'x') * blend;
      let ty = Math.sin(t * 0.7) * 0.01 + poseValAxis('leftHand', 'y') * blend;
      let tz = Math.sin(t * 1.5) * 0.025 + poseValAxis('leftHand', 'z') * blend;
      B.leftHand.rotation.x = App.lerp(B.leftHand.rotation.x, tx, 0.08);
      B.leftHand.rotation.y = App.lerp(B.leftHand.rotation.y, ty, 0.08);
      B.leftHand.rotation.z = App.lerp(B.leftHand.rotation.z, tz, 0.08);
    }
    if (B.rightHand) {
      let tx = Math.sin(t * 1.3 + 0.5) * 0.015 + poseValAxis('rightHand', 'x') * blend;
      let ty = Math.sin(t * 0.7) * 0.01 + poseValAxis('rightHand', 'y') * blend;
      let tz = -Math.sin(t * 1.5) * 0.025 + poseValAxis('rightHand', 'z') * blend;
      B.rightHand.rotation.x = App.lerp(B.rightHand.rotation.x, tx, 0.08);
      B.rightHand.rotation.y = App.lerp(B.rightHand.rotation.y, ty, 0.08);
      B.rightHand.rotation.z = App.lerp(B.rightHand.rotation.z, tz, 0.08);
    }

    // --- 髋部 (行走时轻微摇摆 + 前倾，优雅小幅度) ---
    const walkHipSway = walkProgress > 0 ? Math.sin(walkCyclePhase) * 0.010 : 0;
    const walkHipForward = walkProgress > 0 ? Math.cos(walkCyclePhase) * 0.008 : 0;
    if (B.hips) {
      let hy = Math.sin(t * 0.35) * 0.01 + walkHipSway;
      B.hips.rotation.y = App.lerp(B.hips.rotation.y, hy, 0.06);
      // 髋部侧移（重心左右转移）幅度要小，避免左右晃
      if (B.hips.position) {
        let hx = walkProgress > 0 ? Math.cos(walkCyclePhase) * 0.005 : 0;
        B.hips.position.x = App.lerp(B.hips.position.x || 0, hx, 0.06);
      }
      let hz = walkHipForward + Math.sin(t * 1.2) * 0.004;
      // 髋部 rotation.x = 前后倾斜
      B.hips.rotation.x = App.lerp(B.hips.rotation.x || 0, hz, 0.06);
    }

    // --- 行走时躯干轻微反旋（平衡步态） ---
    const walkTorsoCounter = walkProgress > 0 ? -Math.cos(walkCyclePhase) * 0.008 : 0;
    if (B.spine) B.spine.rotation.y += walkTorsoCounter;

    // ==================== 行走腿部动画：小步、慢步、优雅 ====================
    // walkCyclePhase 随移动距离匀速增长，每 2π 完成一次左右腿交替步态周期
    const walkActive = walkProgress > 0 && walkProgress < 1;
    const LEG_SWING_AMP = 0.28; // 大腿前后摆动幅度，小步
    const KNEE_BEND_AMP = 0.35; // 摆动期膝盖微屈
    const FOOT_LIFT_AMP = 0.12; // 脚尖轻抬

    // 左腿
    if (B.leftUpperLeg) {
      let lx = walkActive ? Math.sin(walkCyclePhase) * LEG_SWING_AMP : 0;
      lx += poseValAxis('leftUpperLeg', 'x') * blend;
      B.leftUpperLeg.rotation.x = App.lerp(B.leftUpperLeg.rotation.x, lx, 0.08);
    }
    if (B.leftLowerLeg) {
      // 膝盖在左腿摆动期（大腿前移）弯曲，支撑期伸直
      const leftSwingBend = walkActive ? Math.max(0, Math.sin(walkCyclePhase)) * KNEE_BEND_AMP : 0;
      let lx = leftSwingBend + poseValAxis('leftLowerLeg', 'x') * blend;
      B.leftLowerLeg.rotation.x = App.lerp(B.leftLowerLeg.rotation.x, lx, 0.08);
    }
    if (B.leftFoot) {
      // 脚掌：左腿摆动期抬脚尖，支撑期放平
      const leftFootLift = walkActive ? Math.max(0, Math.sin(walkCyclePhase)) * FOOT_LIFT_AMP : 0;
      B.leftFoot.rotation.x = App.lerp(B.leftFoot.rotation.x || 0, leftFootLift, 0.08);
    }

    // 右腿（相位 +π）
    if (B.rightUpperLeg) {
      let rx = walkActive ? Math.sin(walkCyclePhase + Math.PI) * LEG_SWING_AMP : 0;
      rx += poseValAxis('rightUpperLeg', 'x') * blend;
      B.rightUpperLeg.rotation.x = App.lerp(B.rightUpperLeg.rotation.x, rx, 0.08);
    }
    if (B.rightLowerLeg) {
      // 膝盖在右腿摆动期（大腿前移）弯曲，支撑期伸直
      const rightSwingBend = walkActive ? Math.max(0, Math.sin(walkCyclePhase + Math.PI)) * KNEE_BEND_AMP : 0;
      let rx = rightSwingBend + poseValAxis('rightLowerLeg', 'x') * blend;
      B.rightLowerLeg.rotation.x = App.lerp(B.rightLowerLeg.rotation.x, rx, 0.08);
    }
    if (B.rightFoot) {
      // 脚掌：右腿摆动期抬脚尖，支撑期放平
      const rightFootLift = walkActive ? Math.max(0, Math.sin(walkCyclePhase + Math.PI)) * FOOT_LIFT_AMP : 0;
      B.rightFoot.rotation.x = App.lerp(B.rightFoot.rotation.x || 0, rightFootLift, 0.08);
    }

    // --- VRM 表情 + 口型同步 ---
    if (App.modelType === 'vrm' && App.vrm && App.vrm.expressionManager) {
      const exp = App.vrm.expressionManager;

      // 口型（说话时由音频驱动，mouthOpen 范围 0~1）
      // 不同 VRM 模型对 aa 表情敏感度不同，用 mouthScale 可适配
      const mouthScale = App.vrmMouthScale || 0.6;
      const targetMouth = App.currentState === App.State.SPEAKING ? Math.min(0.7, mouthOpen * mouthScale) : 0;
      // 快速衰减：张嘴慢一点，闭嘴快（确保字间闭合）
      const lerpK = targetMouth > (App.smoothMouth || 0) ? 0.25 : 0.4;
      App.smoothMouth = App.lerp(App.smoothMouth || 0, targetMouth, lerpK);
      if (Math.abs(App.smoothMouth - targetMouth) < 0.001) App.smoothMouth = targetMouth;
      if (App.smoothMouth < 0.005) App.smoothMouth = 0;
      if (App.exprNames.mouth) exp.setValue(App.exprNames.mouth, App.smoothMouth);

      // 调试：每2秒打印一次口型数据，确认分析器工作状态
      App._mouthLogTimer = (App._mouthLogTimer || 0) + dt;
      if (App.currentState === App.State.SPEAKING && App._mouthLogTimer > 2) {
        App._mouthLogTimer = 0;
        let rawVal = 0;
        if (App.analyserData && App.analyser) {
          App.analyser.getByteTimeDomainData(App.analyserData);
          let s = 0;
          for (let i = 0; i < App.analyserData.length; i++) { const v = (App.analyserData[i] - 128) / 128; s += v * v; }
          rawVal = Math.sqrt(s / App.analyserData.length);
        }
        console.log('[Mouth] raw=', rawVal.toFixed(4), 'mouthOpen=', mouthOpen.toFixed(3), 'smoothMouth=', App.smoothMouth.toFixed(3), 'hasAnalyser=', !!(App.analyserData && App.analyser));
      }

      // 眨眼（增强：普通/慢眨/双连眨/挤眼/全闭眼）
      // 挤眼和全闭眼由 updateIdleExpression 触发时设置 blinkType，这里统一处理
      App.blinkTimer += dt;
      // 挤眼/全闭眼优先——它们由 winkTimer/closeHoldTimer 触发，需要打断普通眨眼
      const isWink = (App.blinkType === 'winkLeft' || App.blinkType === 'winkRight');
      const isCloseHold = (App.blinkType === 'closeHold');
      if (isWink || isCloseHold || App.blinkTimer > App.nextBlinkAt) {
        const duration = App.blinkDuration;
        let elapsed = App.blinkPhase * duration;
        // 如果是挤眼/全闭眼首次触发，重置计时
        if ((isWink || isCloseHold) && App.blinkPhase === 0) {
          App.blinkTimer = App.nextBlinkAt; // 对齐普通眨眼计时，防止立即又触发普通眨眼
        }
        elapsed += dt;
        App.blinkPhase = Math.min(1, elapsed / duration);
        const p = App.blinkPhase;

        if (App.blinkType === 'double') {
          // 双连眨：闭→开→闭→开，两段完整的余弦波
          const t = p * 2; // 映射到 0~2
          let s = 0;
          if (t < 1) s = Math.abs(Math.cos(t * Math.PI)); // 第一段：0→闭→开
          else if (t < 2) s = Math.abs(Math.cos((t - 0.15) * Math.PI)); // 第二段：稍延迟再闭→开
          s = Math.max(0, Math.min(1, s));
          if (App.exprNames.blink) exp.setValue(App.exprNames.blink, s);
        } else if (App.blinkType === 'winkLeft') {
          // 左眼挤眼：仅左眼闭合，右眼保持睁开
          const s = Math.abs(Math.cos(p * Math.PI));
          if (App.exprNames.blinkLeft) exp.setValue(App.exprNames.blinkLeft, s);
          else if (App.exprNames.blink) exp.setValue(App.exprNames.blink, s);
        } else if (App.blinkType === 'winkRight') {
          // 右眼挤眼
          const s = Math.abs(Math.cos(p * Math.PI));
          if (App.exprNames.blinkRight) exp.setValue(App.exprNames.blinkRight, s);
          else if (App.exprNames.blink) exp.setValue(App.exprNames.blink, s);
        } else {
          // normal / slow / closeHold: 统一的单次睁闭
          const s = Math.abs(Math.cos(p * Math.PI));
          if (App.exprNames.blink) {
            exp.setValue(App.exprNames.blink, s);
          } else {
            // 回退：分别驱动左眼/右眼
            if (App.exprNames.blinkLeft) exp.setValue(App.exprNames.blinkLeft, s);
            if (App.exprNames.blinkRight) exp.setValue(App.exprNames.blinkRight, s);
          }
        }

        // 眨眼结束
        if (p >= 1) {
          // 清除所有眼睛表达式
          if (App.exprNames.blink) exp.setValue(App.exprNames.blink, 0);
          if (App.exprNames.blinkLeft) exp.setValue(App.exprNames.blinkLeft, 0);
          if (App.exprNames.blinkRight) exp.setValue(App.exprNames.blinkRight, 0);
          App.blinkPhase = 0;
          App.blinkTimer = 0;
          App.scheduleNextBlink();
          App.nextBlinkAt = App.blinkTimer + 2 + Math.random() * 4;
        }
      }

      // 丰富表情（根据状态自动平滑切换）
      App.updateExpressions(dt);
    } else if (App.modelType === 'gltf' && App.morphTargets.length > 0) {
      const v = App.currentState === App.State.SPEAKING ? mouthOpen : 0;
      for (const mt of App.morphTargets) {
        mt.mesh.morphTargetInfluences[mt.index] = v;
      }
    }

    // vrm.update 更新 humanoid + expressionManager + springBone
    // 跳舞动作覆盖：在姿态应用之后直接控制骨骼（不由姿态系统干扰）
    App.updateDanceAction(dt);
    if (App.modelType === 'vrm' && App.vrm) {
      App.vrm.update(dt);
    }
    // 点击摇摆
    App.applyClickWobble(App.modelGroup);
  };
  /* ============================================================
   *  状态切换
   * ============================================================ */
  /* ============================================================
   *  低功耗模式
   * ============================================================ */
});