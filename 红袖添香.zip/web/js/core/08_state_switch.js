export default (function init(App) {
  const {
    THREE: THREE,
    GLTFLoader: GLTFLoader,
    VRMLoaderPlugin: VRMLoaderPlugin,
    VRMUtils: VRMUtils
  } = App;
  /* ============================================================
   *  状态切换
   * ============================================================ */
  /* ============================================================
   *  低功耗模式
   * ============================================================ */
  App.enterLowPowerMode = function enterLowPowerMode() {
    App.lowPowerMode = true;
    localStorage.setItem(App.LP_KEY, '1');
    const app = document.getElementById('app');
    const stage = App.$('stage');

    // 退出FPV/移动模式
    if (App.fpvMode) {
      App.exitFPV();
    }
    if (App.moveMode) {
      App.setMoveMode(false);
    }

    // 禁用陀螺仪（冻结状态下无需视差）
    if (App.gyroEnabled) {
      App.gyroEnabled = false;
      window.removeEventListener('deviceorientation', App.onDeviceOrient);
    }

    // 停止3D动画循环 —— 角色冻结固定在最后一帧，保留场景/渲染器/模型不销毁
    // 这样角色形象持续可见，但GPU不再持续渲染，大幅降低功耗
    if (typeof cancelAnimationFrame !== 'undefined' && window._animFrame) {
      cancelAnimationFrame(window._animFrame);
      window._animFrame = null;
    }

    // 切换为全屏式布局：3D场景占满整屏，聊天框默认折叠
    app.classList.add('low-power');
    stage.classList.add('low-power');

    // 默认折叠聊天面板，聚焦角色；点击对话图标展开
    document.getElementById('chat-panel').classList.add('collapsed');
    document.getElementById('controls').classList.add('collapsed');

    // 隐藏3D专用按钮（保留低功耗/会话/TTS/全屏）
    [App.modelBtn, App.bgBtn, App.moveBtn, App.fpvBtn, App.resetCamBtn, App.camSettingsBtn, App.$('gyro-btn')].forEach(b => {
      if (b) b.style.display = 'none';
    });

    // 渲染一帧确保角色可见
    if (App.renderer && App.scene && App.camera) {
      App.renderer.render(App.scene, App.camera);
    }

    // 等待布局过渡完成后重新渲染，确保画布尺寸正确
    setTimeout(() => {
      if (App.lowPowerMode && App.renderer && App.scene && App.camera) {
        App.onResize();
        App.renderer.render(App.scene, App.camera);
      }
    }, 400);
    App.showToast('已进入低功耗模式 🔋 · 角色已固定');
    console.log('[LP] 低功耗模式已激活 —— 动画循环已停止，角色形象保持固定可见');
  };
  App.exitLowPowerMode = function exitLowPowerMode() {
    App.lowPowerMode = false;
    localStorage.removeItem(App.LP_KEY);
    const app = document.getElementById('app');
    const stage = App.$('stage');
    app.classList.remove('low-power');
    stage.classList.remove('low-power');

    // 退出低功耗后默认展示聊天面板
    document.getElementById('chat-panel').classList.remove('collapsed');
    document.getElementById('controls').classList.remove('collapsed');
    App.chatToggle.classList.remove('has-new');

    // 恢复3D专用按钮
    [App.modelBtn, App.bgBtn, App.moveBtn, App.fpvBtn, App.resetCamBtn, App.$('gyro-btn')].forEach(b => {
      if (b) b.style.display = '';
    });

    // 重新启动动画循环（场景/渲染器/模型一直保留，无需重新初始化）
    if (App.renderer && App.scene && App.camera && !window._animFrame) {
      if (App.clock) App.clock.getDelta(); // 重置时钟，避免恢复后 dt 过大导致跳变
      App.onResize();
      App.animate();
    }
    App.showToast('已退出低功耗模式');
    console.log('[LP] 低功耗模式已关闭 —— 动画循环已恢复');
  };
  App.toggleLowPowerMode = function toggleLowPowerMode() {
    if (App.lowPowerMode) {
      App.exitLowPowerMode();
    } else {
      App.enterLowPowerMode();
    }
    const lpBtn = App.$('low-power-btn');
    if (lpBtn) lpBtn.classList.toggle('active', App.lowPowerMode);
  };
  App.setState = function setState(s) {
    // 状态切换时重置口型平滑值，防止从 SPEAKING 切出后嘴部残留
    if (s !== App.State.SPEAKING && App.smoothMouth !== undefined) {
      App.smoothMouth = 0;
    }
    App.currentState = s;
    App.statusBadge.className = 'status-badge';
    const map = {
      [App.State.IDLE]: '在线',
      [App.State.THINKING]: {
        t: '思考中…',
        c: 'thinking'
      },
      [App.State.LISTENING]: {
        t: '聆听中…',
        c: 'listening'
      },
      [App.State.SPEAKING]: {
        t: '说话中…',
        c: 'speaking'
      }
    };
    const v = map[s];
    if (typeof v === 'string') App.statusBadge.textContent = v;else {
      App.statusBadge.textContent = v.t;
      App.statusBadge.classList.add(v.c);
    }
  };
  App.showSubtitle = function showSubtitle(text) {
    if (!text) {
      App.subtitle.classList.remove('show');
      return;
    }
    App.subtitle.textContent = text;
    App.subtitle.classList.add('show');
  };
  /* ============================================================
   *  WebSocket
   * ============================================================ */
  /* ============================================================
   *  场景状态持久化（相机/模型位置/缩放）
   * ============================================================ */
});