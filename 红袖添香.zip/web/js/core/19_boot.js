export default (function init(App) {
  const {
    THREE: THREE,
    GLTFLoader: GLTFLoader,
    VRMLoaderPlugin: VRMLoaderPlugin,
    VRMUtils: VRMUtils
  } = App;
  /* ============================================================
   *  启动
   * ============================================================ */
  window.addEventListener('load', async () => {
    // 检查是否上次为低功耗模式
    const savedLP = localStorage.getItem(App.LP_KEY);
    if (savedLP === '1') {
      App.lowPowerMode = true;
      const app = document.getElementById('app');
      const stage = App.$('stage');
      // 应用低功耗全屏式布局：3D场景占满整屏，聊天框默认折叠
      app.classList.add('low-power');
      stage.classList.add('low-power');
      document.getElementById('chat-panel').classList.add('collapsed');
      document.getElementById('controls').classList.add('collapsed');
      [App.modelBtn, App.bgBtn, App.moveBtn, App.fpvBtn, App.resetCamBtn, App.camSettingsBtn, App.$('gyro-btn')].forEach(b => {
        if (b) b.style.display = 'none';
      });
      App.$('low-power-btn').classList.add('active');
      console.log('[LP] 恢复低功耗模式（持久化）');
    }

    // 加载相机设置，必须在 initThree 之前
    App.loadCameraSettings();
    App.updateCameraSettingsUI();

    // 始终初始化3D场景（低功耗模式也需要渲染角色形象）
    App.initThree();
    App.restoreSceneState();
    setTimeout(() => {
      App.applySavedPositions();
    }, 500);
    App.bindEvents();
    App.initTTSConfig();
    App.connectWS();
    App.initSessionUI();
    App.addSystemMsg('正在连接服务器…');

    // 监听任意用户交互，用于 AI 自主触发计时
    ['click', 'touchstart', 'keydown', 'mousemove'].forEach(evt => {
      document.addEventListener(evt, () => {
        App.lastUserActivityTime = Date.now();
      }, {
        passive: true
      });
    });

    // 低功耗按钮事件
    const lpBtn = App.$('low-power-btn');
    if (lpBtn) lpBtn.addEventListener('click', App.toggleLowPowerMode);

    // 自动恢复上次使用的模型（低功耗模式也需加载，以便冻结显示角色）
    const saved = JSON.parse(localStorage.getItem('dabai.currentModel') || 'null');
    if (saved && saved.url) {
      try {
        const res = await fetch('/api/models');
        const data = await res.json();
        const exists = (data.models || []).some(m => m.url === saved.url);
        if (exists) {
          await App.loadModelFromUrl(saved.url, saved.name);
        } else {
          localStorage.removeItem('dabai.currentModel');
        }
      } catch {
        // 离线/出错则忽略，使用默认角色
      }
    }

    // 自动恢复上次使用的背景
    const savedBg = JSON.parse(localStorage.getItem('dabai.currentBackground') || 'null');
    if (savedBg && savedBg.url) {
      try {
        const res = await fetch('/api/backgrounds');
        const data = await res.json();
        const exists = (data.backgrounds || []).some(m => m.url === savedBg.url);
        if (exists) {
          await App.loadBackgroundFromUrl(savedBg.url, savedBg.name);
        } else {
          localStorage.removeItem('dabai.currentBackground');
        }
      } catch {
        // 离线/出错则忽略，使用默认背景
      }
    }

    // 启动完成，之后模型/背景切换可以正常触发 AI 动作
    App._isBooting = false;

    // 低功耗模式：模型加载完成后冻结角色（停止动画循环，保留最后一帧）
    if (App.lowPowerMode && window._animFrame) {
      cancelAnimationFrame(window._animFrame);
      window._animFrame = null;
      if (App.renderer && App.scene && App.camera) {
        App.onResize();
        App.renderer.render(App.scene, App.camera);
      }
      console.log('[LP] 角色已冻结固定');
    }
    setTimeout(() => {
      // 只有没有历史消息时才显示欢迎语
      if (App.messagesEl.children.length <= 1) {
        App.addAIMsg('嗨~ 我是小白！按住麦克风说话，点旁边的小按钮切到「自动对话」模式，说话即录、停顿即发，还能随时打断我~');
      }
    }, 1500);
  });

  // DEBUG expose（使用 getter 确保访问到 initThree 后创建的实例）
  Object.defineProperty(window, '_scene', {
    get: () => App.scene
  });
  Object.defineProperty(window, '_camera', {
    get: () => App.camera
  });
  Object.defineProperty(window, '_proceduralChar', {
    get: () => App.proceduralChar
  });
  Object.defineProperty(window, '_modelGroup', {
    get: () => App.modelGroup
  });
  Object.defineProperty(window, '_smoothRotY', {
    get: () => App.smoothRotY
  });
  Object.defineProperty(window, '_currentAvatar', {
    get: () => App.currentAvatar
  });
});