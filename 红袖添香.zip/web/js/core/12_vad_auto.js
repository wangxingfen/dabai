export default (function init(App) {
  const {
    THREE: THREE,
    GLTFLoader: GLTFLoader,
    VRMLoaderPlugin: VRMLoaderPlugin,
    VRMUtils: VRMUtils
  } = App;
  /* ============================================================
   *  VAD 自动对话模式（无需按住，说话即录、停顿即发）
   * ============================================================ */
  let vadEmaVol = 0;       // 指数移动平均音量（平滑）
  const VAD_EMA_ALPHA = 0.35;  // EMA 平滑系数（越低越平滑，越高越灵敏）

  App.startVADMode = async function startVADMode() {
    if (App.vadStream) return true;
    try {
      App.vadStream = await navigator.mediaDevices.getUserMedia({
        audio: App.MIC_CONSTRAINTS
      });
    } catch (err) {
      App.showToast('无法访问麦克风：' + (err.message || err.name));
      return false;
    }
    App.ensureAudioCtx();
    App.vadAnalyser = App.audioCtx.createAnalyser();
    App.vadAnalyser.fftSize = 1024;                   // 更大的分析窗口 → 更稳定
    App.vadAnalyser.smoothingTimeConstant = 0.2;       // 更快的响应
    App.vadData = new Uint8Array(App.vadAnalyser.frequencyBinCount);
    const src = App.audioCtx.createMediaStreamSource(App.vadStream);
    src.connect(App.vadAnalyser);
    // 注意：vadAnalyser 不连接到 destination，避免麦克风声音反馈到扬声器
    vadEmaVol = 0;
    console.log('[VAD] 自动对话模式已启动 (fftSize=1024)');
    return true;
  };
  App.stopVADMode = function stopVADMode() {
    if (App.vadRAF) {
      cancelAnimationFrame(App.vadRAF);
      App.vadRAF = null;
    }
    if (App.vadRecorder && App.vadRecorder.state !== 'inactive') {
      try {
        App.vadRecorder.stop();
      } catch (e) {}
    }
    if (App.vadStream) {
      App.vadStream.getTracks().forEach(t => t.stop());
      App.vadStream = null;
    }
    App.vadAnalyser = null;
    App.vadData = null;
    App.vadState = 'idle';
    App.vadSilenceStart = 0;
    App.vadInterruptStart = 0;
    vadEmaVol = 0;
  };
  App.setVoiceMode = function setVoiceMode(mode) {
    App.voiceMode = mode;
    localStorage.setItem('dabai.voiceMode', mode);
    const modeBtn = App.$('voice-mode-btn');
    if (mode === 'auto') {
      App.startVADMode().then(ok => {
        if (!ok) {
          App.voiceMode = 'press';
          return;
        }
        App.vadState = 'idle';
        App.vadLoop();
        App.voiceBtn.classList.add('auto');
        App.voiceBtn.title = '自动对话中（用左侧按钮切回按住说话）';
        if (modeBtn) modeBtn.classList.add('active');
        App.showToast('已切换为自动对话 · 直接说话即可');
        App.sendAIAction('（用户解放了双手，现在你能一直听到Ta的声音了，可以更自然随意地聊天）');
      });
    } else {
      App.stopVADMode();
      App.voiceBtn.classList.remove('auto');
      App.voiceBtn.title = '按住说话';
      if (modeBtn) modeBtn.classList.remove('active');
      App.showToast('已切换为按住说话');
      App.sendAIAction('（用户切换了对话方式，现在需要按住按钮才能听到Ta说话，等Ta准备好再说）');
    }
  };
  /* 频率域能量检测：比时域 RMS 更稳定，能综合捕捉全频段语音能量 */
  App.vadGetVolume = function vadGetVolume() {
    if (!App.vadAnalyser || !App.vadData) return 0;
    App.vadAnalyser.getByteFrequencyData(App.vadData);
    let sum = 0;
    // 只统计语音频段 (85Hz ~ 3500Hz ≈ 频段 bin 3~110，fftSize=1024 → 512 bins, 采样率48k → bin带宽≈93.75Hz)
    const minBin = 1;   // ~94Hz，跳过直流分量
    const maxBin = Math.min(110, App.vadData.length);
    for (let i = minBin; i < maxBin; i++) {
      sum += App.vadData[i];
    }
    const raw = sum / (maxBin - minBin) / 255;  // 归一化到 0~1
    // EMA 平滑，减少单帧抖动
    vadEmaVol = VAD_EMA_ALPHA * raw + (1 - VAD_EMA_ALPHA) * vadEmaVol;
    return vadEmaVol;
  };
  App.vadLoop = function vadLoop() {
    if (App.voiceMode !== 'auto') return;

    // 检查 AudioContext 是否被浏览器暂停（长时间空闲后浏览器会挂起音频上下文）
    if (App.audioCtx && App.audioCtx.state === 'suspended') {
      App.audioCtx.resume().then(() => console.log('[VAD] AudioContext 已自动恢复'));
      // 等待下一个周期再检测，让 resume 生效
      App.vadRAF = requestAnimationFrame(App.vadLoop);
      return;
    }
    if (!App.vadAnalyser) return;

    // 检查 vadStream 是否还活着（浏览器长时间后台可能回收麦克风流）
    if (App.vadStream && !App.vadStream.active) {
      console.warn('[VAD] 麦克风流已失效，尝试重建…');
      App.stopVADMode();
      App.startVADMode().then(ok => {
        if (ok) {
          App.vadState = 'idle';
          App.vadLoop();
        } else {
          App.showToast('自动对话已断开，请切回按住说话');
          App.voiceMode = 'press';
        }
      });
      return;
    }
    App.vadRAF = requestAnimationFrame(App.vadLoop);
    const vol = App.vadGetVolume();
    const now = performance.now();

    // AI 说话中：检测打断
    if (App.currentState === App.State.SPEAKING) {
      if (vol > App.VAD_INTERRUPT_THRESHOLD) {
        if (App.vadInterruptStart === 0) App.vadInterruptStart = now;
        if (now - App.vadInterruptStart > App.VAD_INTERRUPT_MS) {
          console.log('[VAD] 检测到打断 vol=', vol.toFixed(3));
          App.triggerInterrupt();
          App.vadInterruptStart = 0;
          // 立即切到 IDLE，防止本函数下一帧再次进打断分支
          App.currentState = App.State.IDLE;
          if (App.vadState === 'idle') App.startVADRecording();
        }
      } else {
        App.vadInterruptStart = 0;
      }
      return;
    }

    // AI 思考中：不录音（避免录到环境音/提示音）
    if (App.currentState === App.State.THINKING) {
      App.vadInterruptStart = 0;
      return;
    }

    // IDLE / LISTENING：自动检测说话开始/结束
    if (App.vadState === 'idle') {
      if (vol > App.VAD_THRESHOLD) {
        App.startVADRecording();
      }
    } else if (App.vadState === 'recording') {
      if (vol < App.VAD_THRESHOLD * 0.6) {
        if (App.vadSilenceStart === 0) App.vadSilenceStart = now;
        if (now - App.vadSilenceStart > App.VAD_SILENCE_MS) {
          App.stopVADRecording();
          App.vadSilenceStart = 0;
        }
      } else {
        App.vadSilenceStart = 0;
      }
    }
  };
  App.startVADRecording = function startVADRecording() {
    if (!App.vadStream) return;
    App.vadState = 'recording';
    App.vadChunks = [];
    App.vadSilenceStart = 0;
    try {
      const mime = App.pickRecorderMime();
      App.vadRecorder = mime ? new MediaRecorder(App.vadStream, {
        mimeType: mime,
        audioBitsPerSecond: 128000
      }) : new MediaRecorder(App.vadStream);
    } catch (e) {
      console.warn('[VAD] MediaRecorder 创建失败，尝试重建流:', e);
      // 流可能已失效，重建 VAD 模式
      App.stopVADMode();
      App.vadState = 'idle';
      App.startVADMode().then(ok => {
        if (ok) App.vadLoop();else {
          App.showToast('自动对话已断开，请切回按住说话');
          App.voiceMode = 'press';
        }
      });
      return;
    }
    App.vadRecorder.ondataavailable = e => {
      if (e.data && e.data.size > 0) App.vadChunks.push(e.data);
    };
    App.vadRecorder.onstop = () => {
      const chunks = App.vadChunks;
      App.vadChunks = [];
      const mimeType = App.vadRecorder.mimeType || 'audio/webm';
      const blob = new Blob(chunks, { type: mimeType });
      if (blob.size < 3000) {
        App.vadState = 'idle';
        // 太小说明录音太短或只有空 header
        App.showToast('声音太短，再说一次？');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        App.sendAudioBase64(reader.result, mimeType);
        App.showTyping();
      };
      reader.readAsDataURL(blob);
    };
    // 定时切片，便于及时停止
    App.vadRecorder.start(200);
    App.setState(App.State.LISTENING);
  };
  App.stopVADRecording = function stopVADRecording() {
    if (!App.vadRecorder || App.vadRecorder.state === 'inactive') {
      App.vadState = 'idle';
      return;
    }
    App.vadState = 'idle';
    try {
      // 强制刷新最后一帧数据，防止 webm 文件不完整
      if (App.vadRecorder.state === 'recording') {
        App.vadRecorder.requestData();
      }
      App.vadRecorder.stop();
    } catch (e) {}
  };
  /* AI 说完后恢复监听（VAD 自动模式）：重置计时避免把尾音当用户说话 */
  App.vadResumeAfterSpeak = function vadResumeAfterSpeak() {
    App.vadSilenceStart = 0;
    App.vadInterruptStart = 0;
    App.vadState = 'idle';
    vadEmaVol = 0;  // 重置 EMA 避免残留
  };
  /* ============================================================
   *  消息渲染
   * ============================================================ */
  // 聊天面板收起时新消息到达 → 提示切换按钮
});
