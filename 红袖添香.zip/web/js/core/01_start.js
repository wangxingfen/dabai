export default (function init(App) {
  const {
    THREE: THREE,
    GLTFLoader: GLTFLoader,
    VRMLoaderPlugin: VRMLoaderPlugin,
    VRMUtils: VRMUtils
  } = App;
  /* ---------- DOM ---------- */
  App.$ = id => document.getElementById(id);
  App.canvas = App.$('three-canvas');
  App.statusBadge = App.$('status-badge');
  App.subtitle = App.$('subtitle');
  App.messagesEl = App.$('messages');
  App.scrollHint = App.$('scroll-hint');
  App.textInput = App.$('text-input');
  App.sendBtn = App.$('send-btn');
  App.voiceBtn = App.$('voice-btn');
  App.toastEl = App.$('toast');
  App.modelBtn = App.$('model-btn');
  App.resetCamBtn = App.$('reset-cam-btn');
  App.fullscreenBtn = App.$('fullscreen-btn');
  App.chatToggle = App.$('chat-toggle');
  App.modelModal = App.$('model-modal');
  App.modalClose = App.$('modal-close');
  App.modelListEl = App.$('model-list');
  App.modelFileInput = App.$('model-file-input');
  App.dropHint = App.$('drop-hint');
  App.modelLoading = App.$('model-loading');
  App.modelLoadingText = App.$('model-loading-text'); // 背景场景
  App.bgBtn = App.$('bg-btn');
  App.bgModal = App.$('bg-modal');
  App.bgModalClose = App.$('bg-modal-close');
  App.bgListEl = App.$('bg-list');
  App.bgFileInput = App.$('bg-file-input'); // 移动模式
  App.moveBtn = App.$('move-btn'); // 第一人称探索
  App.fpvBtn = App.$('fpv-btn');
  App.fpvCrosshair = App.$('fpv-crosshair');
  App.fpvJoystick = App.$('fpv-joystick');
  App.fpvJoystickThumb = App.$('fpv-joystick-thumb');
  App.fpvExitBtn = App.$('fpv-exit'); // TTS 设置
  App.ttsBtn = App.$('tts-btn');
  App.ttsModal = App.$('tts-modal');
  App.ttsModalClose = App.$('tts-modal-close');
  App.ttsVoiceSelect = App.$('tts-voice-select');
  App.ttsRateRange = App.$('tts-rate-range');
  App.ttsRateVal = App.$('tts-rate-val');
  App.ttsEdgePanel = App.$('tts-edge-panel');
  App.ttsGsoPanel = App.$('tts-gso-panel');
  App.ttsGsoUrl = App.$('tts-gso-url');
  App.ttsGsoRef = App.$('tts-gso-ref');
  App.ttsGsoChar = App.$('tts-gso-char');
  App.ttsSaveBtn = App.$('tts-save-btn'); // 相机设置
  App.camSettingsBtn = App.$('cam-settings-btn');
  App.camSettingsModal = App.$('cam-settings-modal');
  App.camSettingsModalClose = App.$('cam-settings-modal-close');
  App.camHeightRange = App.$('cam-height-range');
  App.camHeightVal = App.$('cam-height-val');
  App.camTiltRange = App.$('cam-tilt-range');
  App.camTiltVal = App.$('cam-tilt-val');
  App.camSettingsSaveBtn = App.$('cam-settings-save-btn');
  // BGM
  App.bgmBtn = App.$('bgm-btn');
  App.bgmModal = App.$('bgm-modal');
  App.bgmModalClose = App.$('bgm-modal-close');
  App.bgmListEl = App.$('bgm-list');
  App.bgmFileInput = App.$('bgm-file-input');
  App.bgmEmptyMsg = App.$('bgm-empty-msg');
  /* ---------- 状态 ---------- */
  App.State = {
    IDLE: 'idle',
    THINKING: 'thinking',
    LISTENING: 'listening',
    SPEAKING: 'speaking'
  };
  App.currentState = App.State.IDLE;
  App.isRecording = false;
  App.mediaRecorder = null;
  App.audioChunks = [];
  App.ws = null;
  App.wsHeartbeat = null; // WebSocket 心跳定时器
  App.wsReconnectTimer = null; // 重连定时器
  App.wsConnTimeout = null; // 连接超时定时器
  App.currentAudio = null;
  App.audioCtx = null;
  App.analyser = null;
  App.analyserData = null; // --- 流式播放队列 ---
  App.audioQueue = []; // 待播放的句子 [{seq, text, audio_b64, audio_mime}]
  App.isPlayingQueue = false;
  App.currentReplyText = ''; // 当前回复累积文本
  App.currentReplySession = null; // 当前回复 session_id（用于判断过期消息）
  App.pendingAIMsgEl = null; // 流式回复占位 DOM
  // --- VAD 自动对话模式 ---
  App.voiceMode = 'press'; // 'press' 按住说话 | 'auto' 自动对话
  App.vadStream = null; // VAD 持续监听的 MediaStream
  App.vadAnalyser = null;
  App.vadData = null;
  App.vadRAF = null;
  App.vadState = 'idle'; // 'idle' | 'recording'
  App.vadSilenceStart = 0;
  App.vadInterruptStart = 0;
  App.vadRecorder = null;
  App.vadChunks = [];
  App.VAD_THRESHOLD = 0.05; // 普通说话音量阈值（降低让小声也能触发）
  App.VAD_INTERRUPT_THRESHOLD = 0.05; // AI 说话时打断阈值（使用 EMA 平滑后更稳定，可与说话阈值一致）
  App.VAD_SILENCE_MS = 1800; // 静音多久判定结束（加长避免说话停顿被切断）
  App.VAD_INTERRUPT_MS = 250; // AI 说话时持续多久高音量判定打断（缩短加快响应）
  App.VAD_MIN_RECORD_MS = 350; // 最短录音时长，避免短噪音触发
  // --- 低功耗模式 ---
  App.lowPowerMode = false; // 是否处于低功耗模式
  App.LP_KEY = 'dabai.lowPower';
  App.onDeviceOrient = null; // 陀螺仪回调（模块级引用，供低功耗模式移除监听）
  /* ============================================================
   *  Three.js 场景
   * ============================================================ */
});