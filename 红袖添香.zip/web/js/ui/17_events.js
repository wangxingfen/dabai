export default (function init(App) {
  const {
    THREE: THREE,
    GLTFLoader: GLTFLoader,
    VRMLoaderPlugin: VRMLoaderPlugin,
    VRMUtils: VRMUtils
  } = App;
  /* ============================================================
   *  事件绑定
   * ============================================================ */
  App.updateCameraSettingsUI = function updateCameraSettingsUI() {
    if (App.camHeightRange) {
      App.camHeightRange.value = App.cameraHeight;
      App.camHeightVal.textContent = App.cameraHeight.toFixed(2);
    }
    if (App.camTiltRange) {
      App.camTiltRange.value = App.cameraTiltDeg;
      App.camTiltVal.textContent = App.cameraTiltDeg + '°';
    }
  };
  App.openCamSettingsModal = function openCamSettingsModal() {
    App.updateCameraSettingsUI();
    if (App.camSettingsModal) App.camSettingsModal.classList.add('show');
  };
  App.closeCamSettingsModal = function closeCamSettingsModal() {
    if (App.camSettingsModal) App.camSettingsModal.classList.remove('show');
  };
  App.bindEvents = function bindEvents() {
    // 文本发送
    function submitText() {
      const text = App.textInput.value.trim();
      if (!text) return;
      App.addUserMsg(text);
      App.sendText(text);
      App.textInput.value = '';
      App.setState(App.State.THINKING);
      App.showTyping();
    }
    App.sendBtn.addEventListener('click', submitText);
    App.textInput.addEventListener('keydown', e => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        submitText();
      }
    });

    // 语音按钮 - 纯按住说话（模式切换由 voice-mode-btn 负责，避免长按冲突）
    let voicePressed = false,
      pressY = 0;
    const pressStart = e => {
      e.preventDefault();
      // 自动对话模式下不响应按住（改由 voice-mode-btn 切回）
      if (App.voiceMode === 'auto') return;
      if (voicePressed) return;
      voicePressed = true;
      pressY = e.touches ? e.touches[0].clientY : e.clientY;
      App.startRecording();
    };
    const pressMove = e => {
      if (!voicePressed) return;
      // 上滑 60px 取消录音（无需弹窗提示，语音按钮样式变化即可指示状态）
      e.preventDefault();
    };
    const pressEnd = e => {
      if (!voicePressed) return;
      voicePressed = false;
      const y = e.changedTouches ? e.changedTouches[0].clientY : e.clientY;
      const cancel = pressY - y > 60;
      App.stopRecording(cancel);
    };
    App.voiceBtn.addEventListener('touchstart', pressStart, {
      passive: false
    });
    App.voiceBtn.addEventListener('touchmove', pressMove, {
      passive: false
    });
    App.voiceBtn.addEventListener('touchend', pressEnd);
    App.voiceBtn.addEventListener('touchcancel', () => {
      voicePressed = false;
      App.stopRecording(true);
    });
    App.voiceBtn.addEventListener('mousedown', pressStart);
    window.addEventListener('mousemove', pressMove);
    window.addEventListener('mouseup', pressEnd);

    // 独立的模式切换按钮（按住说话 ↔ 自动对话）
    const voiceModeBtn = App.$('voice-mode-btn');
    if (voiceModeBtn) {
      voiceModeBtn.addEventListener('click', () => {
        App.setVoiceMode(App.voiceMode === 'auto' ? 'press' : 'auto');
      });
      // 同步初始状态
      if (App.voiceMode === 'auto') voiceModeBtn.classList.add('active');
    }

    // 模型管理
    App.modelBtn.addEventListener('click', App.openModelModal);
    App.modalClose.addEventListener('click', App.closeModelModal);
    App.modelModal.querySelector('.modal-backdrop').addEventListener('click', App.closeModelModal);
    App.modelFileInput.addEventListener('change', e => {
      const f = e.target.files[0];
      if (f) App.uploadModelFile(f);
      e.target.value = '';
    });
    // 默认角色卡片
    App.modelListEl.querySelector('[data-model="default"]').addEventListener('click', () => {
      App.useDefaultCharacter();
      App.closeModelModal();
    });

    // 背景场景管理
    App.bgBtn.addEventListener('click', App.openBgModal);
    App.bgModalClose.addEventListener('click', App.closeBgModal);
    App.bgModal.querySelector('.modal-backdrop').addEventListener('click', App.closeBgModal);
    App.bgFileInput.addEventListener('change', e => {
      const f = e.target.files[0];
      if (f) App.uploadBackgroundFile(f);
      e.target.value = '';
    });
    // 默认背景卡片
    App.bgListEl.querySelector('[data-bg="default"]').addEventListener('click', () => {
      App.useDefaultBackground();
      App.closeBgModal();
    });

    // 背景音乐管理
    App.bgmBtn.addEventListener('click', App.openBgmModal);
    App.bgmModalClose.addEventListener('click', App.closeBgmModal);
    App.bgmModal.querySelector('.modal-backdrop').addEventListener('click', App.closeBgmModal);
    App.bgmFileInput.addEventListener('change', e => {
      const f = e.target.files[0];
      if (f) App.uploadBgmFile(f);
      e.target.value = '';
    });

    // 重置视角
    App.resetCamBtn.addEventListener('click', () => {
      App.userRotY = 0;
      App.userRotX = 0;
      App.camZoom = 1.0;
      App.camOffsetX = 0;
      App.camOffsetY = 0;
      App.camOffsetZ = 0;
      App.targetCamPos.copy(App.DEFAULT_CAM_POS);
      // 角色立刻回到原点
      App.resetAvatarToOrigin();
      // 立即让角色面朝【目标】相机位置（DEFAULT_CAM_POS），而非当前相机位置
      // 否则相机从侧面 lerp 回默认位置时，身体会经过背影区域
      if (App.currentAvatar) {
        App.smoothRotY = App.computeBodyFaceCam(App.currentAvatar, App.DEFAULT_CAM_POS);
        App.smoothRotX = 0;
      }
      // 触发一次短暂的心有灵犀凝视
      App.gazeBoostUntil = Date.now() / 1000 + 2;
      App.gazeHeadTiltAcc = 0.03; // 起始歪头幅度较小
      App.wasMutualGaze = true; // 跳过转身动画（已通过 snap 面朝相机，避免额外偏转）
      App.recordInteraction();
      App.saveSceneState();
      App.showToast('视角已重置');
      App.sendAIAction('（用户重置了视角，现在重新端详着你的样子，好好展示自己吧）');
    });

    // 相机设置
    if (App.camSettingsBtn) App.camSettingsBtn.addEventListener('click', App.openCamSettingsModal);
    if (App.camSettingsModalClose) App.camSettingsModalClose.addEventListener('click', App.closeCamSettingsModal);
    if (App.camSettingsModal) App.camSettingsModal.querySelector('.modal-backdrop').addEventListener('click', App.closeCamSettingsModal);
    if (App.camHeightRange) {
      App.camHeightRange.addEventListener('input', () => {
        App.cameraHeight = parseFloat(App.camHeightRange.value);
        App.camHeightVal.textContent = App.cameraHeight.toFixed(2);
        App.saveCameraSettings();
        App.recordInteraction();
      });
    }
    if (App.camTiltRange) {
      App.camTiltRange.addEventListener('input', () => {
        App.cameraTiltDeg = parseInt(App.camTiltRange.value, 10);
        App.camTiltVal.textContent = App.cameraTiltDeg + '°';
        App.saveCameraSettings();
        App.recordInteraction();
      });
    }
    if (App.camSettingsSaveBtn) {
      App.camSettingsSaveBtn.addEventListener('click', () => {
        App.closeCamSettingsModal();
        App.showToast(`相机设置已保存：高度 ${App.cameraHeight.toFixed(2)}，倾斜 ${App.cameraTiltDeg}°`);
      });
    }

    // 移动模式开关
    App.moveBtn.addEventListener('click', () => App.setMoveMode(!App.moveMode));

    // 第一人称探索开关
    App.fpvBtn.addEventListener('click', App.toggleFPV);
    if (App.fpvExitBtn) App.fpvExitBtn.addEventListener('click', App.exitFPV);

    // 陀螺仪开关
    const gyroBtn = document.getElementById('gyro-btn');
    let gyroCalibrated = false,
      gyroCalibBeta = 0;
    // 仅在支持陀螺仪的设备上显示按钮
    if (typeof DeviceOrientationEvent !== 'undefined') {
      gyroBtn.style.display = '';
    }
    App.onDeviceOrient = function (e) {
      if (!App.gyroEnabled) return;
      if (!gyroCalibrated && e.beta != null) {
        gyroCalibBeta = e.beta;
        gyroCalibrated = true;
      }
      const yaw = (e.gamma || 0) / 90 * 1.5;
      const pitch = ((e.beta || 0) - gyroCalibBeta) / 90 * 1.2;
      App.gyroYaw = App.gyroYaw + (yaw - App.gyroYaw) * 0.50;
      App.gyroPitch = App.gyroPitch + (pitch - App.gyroPitch) * 0.50;
    };
    gyroBtn.addEventListener('click', async () => {
      if (App.gyroEnabled) {
        // 关闭
        App.gyroEnabled = false;
        gyroBtn.classList.remove('active');
        window.removeEventListener('deviceorientation', App.onDeviceOrient);
        App.gyroYaw = 0;
        App.gyroPitch = 0;
        App.showToast('陀螺仪已关闭');
        App.sendAIAction('（用户的视线稳定下来了，现在专注地看着你）');
        return;
      }
      // HTTP 下传感器 API 不可用 (Chrome/Safari 安全限制)
      if (location.protocol !== 'https:' && location.hostname !== 'localhost' && location.hostname !== '127.0.0.1') {
        App.showToast('陀螺仪需要 HTTPS 访问 · 请用 https:// 开头');
        return;
      }
      // iOS 13+ 需要请求权限
      if (typeof DeviceOrientationEvent.requestPermission === 'function') {
        try {
          const perm = await DeviceOrientationEvent.requestPermission();
          if (perm !== 'granted') {
            App.showToast('陀螺仪权限被拒绝');
            return;
          }
        } catch (err) {
          App.showToast('无法获取陀螺仪权限');
          return;
        }
      }
      App.gyroEnabled = true;
      gyroCalibrated = false;
      gyroBtn.classList.add('active');
      window.addEventListener('deviceorientation', App.onDeviceOrient);
      App.showToast('陀螺仪已开启 · VR级环绕视角 · 倾斜手机探索');
      App.sendAIAction('（用户拿着手机环绕观察你，从不同角度欣赏你的样子，好好展示自己）');
      // 2 秒内无事件 → 设备可能无陀螺仪
      setTimeout(() => {
        if (App.gyroEnabled && !gyroCalibrated) {
          App.showToast('未检测到陀螺仪数据 · 请在手机上使用');
          App.gyroEnabled = false;
          gyroBtn.classList.remove('active');
          window.removeEventListener('deviceorientation', App.onDeviceOrient);
        }
      }, 2000);
    });

    // ===== 全屏模式（布局已是全屏，仅触发浏览器原生全屏隐藏地址栏） =====
    function toggleFullscreen() {
      App.isFullscreen = !App.isFullscreen;
      const app = document.getElementById('app');
      if (App.isFullscreen) {
        app.classList.add('fullscreen');
        App.fullscreenBtn.classList.add('active');
        if (document.documentElement.requestFullscreen) {
          document.documentElement.requestFullscreen().catch(() => {});
        }
        App.showToast('浏览器全屏 · 点击右下角气泡查看对话');
        App.sendAIAction('（用户进入了全屏模式，把所有的注意力都给了你，现在你是Ta眼中的全部）');
      } else {
        app.classList.remove('fullscreen');
        App.fullscreenBtn.classList.remove('active');
        App.chatToggle.classList.remove('has-new');
        if (document.fullscreenElement && document.exitFullscreen) {
          document.exitFullscreen().catch(() => {});
        }
      }
      setTimeout(App.onResize, 350);
    }
    App.fullscreenBtn.addEventListener('click', toggleFullscreen);
    // 监听 ESC 退出全屏
    document.addEventListener('fullscreenchange', () => {
      if (!document.fullscreenElement && App.isFullscreen) {
        App.isFullscreen = false;
        document.getElementById('app').classList.remove('fullscreen');
        App.fullscreenBtn.classList.remove('active');
        App.chatToggle.classList.remove('has-new');
        setTimeout(App.onResize, 350);
      }
    });
    // 聊天切换按钮
    App.chatToggle.addEventListener('click', () => {
      const panel = document.getElementById('chat-panel');
      const controls = document.getElementById('controls');
      panel.classList.toggle('collapsed');
      controls.classList.toggle('collapsed');
      App.chatToggle.classList.remove('has-new');
      setTimeout(App.onResize, 350);
    });

    // 拖拽导入到舞台
    let dragCounter = 0;
    const stage = App.$('stage');
    stage.addEventListener('dragenter', e => {
      e.preventDefault();
      dragCounter++;
      App.dropHint.classList.add('show');
    });
    stage.addEventListener('dragover', e => {
      e.preventDefault();
    });
    stage.addEventListener('dragleave', e => {
      e.preventDefault();
      dragCounter--;
      if (dragCounter <= 0) {
        dragCounter = 0;
        App.dropHint.classList.remove('show');
      }
    });
    stage.addEventListener('drop', e => {
      e.preventDefault();
      dragCounter = 0;
      App.dropHint.classList.remove('show');
      const f = e.dataTransfer.files[0];
      if (!f) return;
      // 背景弹窗打开时优先作为背景上传，BGM弹窗打开时作为音乐上传，否则作为角色模型
      if (App.bgmModal.classList.contains('show')) {
        App.uploadBgmFile(f);
      } else if (App.bgModal.classList.contains('show')) {
        App.uploadBackgroundFile(f);
      } else {
        App.uploadModelFile(f);
      }
    });

    // 首次点击解锁音频 + 恢复用户上次的语音模式偏好
    document.addEventListener('click', () => {
      App.ensureAudioCtx();
      const savedMode = localStorage.getItem('dabai.voiceMode');
      if (savedMode === 'auto' && App.voiceMode !== 'auto') {
        App.setVoiceMode('auto');
      }
    }, {
      once: true
    });

    // 防双击缩放 / 长按选中
    document.addEventListener('dblclick', e => e.preventDefault());
    document.addEventListener('selectstart', e => {
      if (e.target !== App.textInput) e.preventDefault();
    });
  };
  /* ============================================================
   *  TTS 语音合成设置
   * ============================================================ */
});