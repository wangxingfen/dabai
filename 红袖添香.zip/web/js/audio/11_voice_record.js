export default (function init(App) {
  const {
    THREE: THREE,
    GLTFLoader: GLTFLoader,
    VRMLoaderPlugin: VRMLoaderPlugin,
    VRMUtils: VRMUtils
  } = App;
  /* ============================================================
   *  语音录制
   * ============================================================ */
  /* 录音格式优先级：兼容 iOS Safari（mp4）+ Chrome/Firefox（webm） */
  App.pickRecorderMime = function pickRecorderMime() {
    const candidates = ['audio/webm;codecs=opus', 'audio/webm', 'audio/ogg;codecs=opus', 'audio/mp4' // iOS Safari
    ];
    for (const m of candidates) {
      if (m && MediaRecorder.isTypeSupported(m)) return m;
    }
    return '';
  };
  /* 麦克风约束：单声道 + 强降噪/回声消除，提升识别准确率 */
  App.MIC_CONSTRAINTS = {
    echoCancellation: true,
    noiseSuppression: true,
    autoGainControl: true,
    channelCount: 1,
    sampleRate: 16000
  };
  App.startRecording = async function startRecording() {
    // 按下麦克风即打断当前 AI 回复（让用户随时插话）
    App.triggerInterrupt();
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: App.MIC_CONSTRAINTS
      });
      App.audioChunks = [];
      const mime = App.pickRecorderMime();
      App.mediaRecorder = mime ? new MediaRecorder(stream, {
        mimeType: mime,
        audioBitsPerSecond: 128000
      }) : new MediaRecorder(stream);
      App.mediaRecorder.ondataavailable = e => {
        if (e.data && e.data.size > 0) App.audioChunks.push(e.data);
      };
      App.mediaRecorder.onstop = () => {
        const mimeType = App.mediaRecorder.mimeType || 'audio/webm';
        const blob = new Blob(App.audioChunks, { type: mimeType });
        stream.getTracks().forEach(tr => tr.stop());
        if (blob.size < 3000) {
          App.showToast('录音太短，请按住多说一下');
          return;
        }
        const reader = new FileReader();
        reader.onloadend = () => App.sendAudioBase64(reader.result, mimeType);
        reader.readAsDataURL(blob);
      };
      App.mediaRecorder.start();
      App.isRecording = true;
      App.voiceBtn.classList.add('recording');
      App.setState(App.State.LISTENING);
    } catch (err) {
      App.showToast('无法访问麦克风：' + (err.message || err.name));
    }
  };
  App.stopRecording = function stopRecording(cancel = false) {
    if (!App.mediaRecorder || App.mediaRecorder.state === 'inactive') {
      App.isRecording = false;
      App.voiceBtn.classList.remove('recording');
      return;
    }
    if (cancel) {
      App.audioChunks = [];
      App.mediaRecorder.ondataavailable = null;
      App.mediaRecorder.onstop = () => {
        if (App.mediaRecorder.stream) App.mediaRecorder.stream.getTracks().forEach(tr => tr.stop());
      };
    }
    // 强制刷新最后一帧数据，防止 webm 文件不完整
    if (App.mediaRecorder.state === 'recording') {
      App.mediaRecorder.requestData();
    }
    App.mediaRecorder.stop();
    App.isRecording = false;
    App.voiceBtn.classList.remove('recording');
    if (!cancel) {
      // 发送后进入「思考中」状态（服务端流式回复会接力 thinking/listening）
      App.setState(App.State.THINKING);
      App.showTyping();
    } else {
      App.setState(App.State.IDLE);
    }
  };
  /* ============================================================
   *  VAD 自动对话模式（无需按住，说话即录、停顿即发）
   * ============================================================ */
});