import { App } from './js/core/app-state.js';

import init_01_start from './js/core/01_start.js';
import init_02_three_scene from './js/core/02_three_scene.js';
import init_03_model_load_gltf_vrm from './js/core/03_model_load_gltf_vrm.js';
import init_04_bg_load from './js/character/04_bg_load.js';
import init_05_move_mode from './js/core/05_move_mode.js';
import init_06_fpv_mode from './js/character/06_fpv_mode.js';
import init_07_click_interact from './js/character/07_click_interact.js';
import init_08_state_switch from './js/core/08_state_switch.js';
import init_09_websocket from './js/network/09_websocket.js';
import init_10_tts_lipsync from './js/core/10_tts_lipsync.js';
import init_11_voice_record from './js/audio/11_voice_record.js';
import init_12_vad_auto from './js/core/12_vad_auto.js';
import init_13_messages from './js/ui/13_messages.js';
import init_14_toast from './js/ui/14_toast.js';
import init_15_model_ui from './js/ui/15_model_ui.js';
import init_16_bg_ui from './js/ui/16_bg_ui.js';
import init_17_events from './js/ui/17_events.js';
import init_18_tts_settings from './js/audio/18_tts_settings.js';
import init_19_boot from './js/core/19_boot.js';
import init_20_bgm_player from './js/audio/20_bgm_player.js';
import init_21_bgm_ui from './js/audio/21_bgm_ui.js';

init_01_start(App);
init_02_three_scene(App);
init_03_model_load_gltf_vrm(App);
init_04_bg_load(App);
init_05_move_mode(App);
init_06_fpv_mode(App);
init_07_click_interact(App);
init_08_state_switch(App);
init_09_websocket(App);
init_10_tts_lipsync(App);
init_11_voice_record(App);
init_12_vad_auto(App);
init_13_messages(App);
init_14_toast(App);
init_15_model_ui(App);
init_16_bg_ui(App);
init_17_events(App);
init_18_tts_settings(App);
init_19_boot(App);
init_20_bgm_player(App);
init_21_bgm_ui(App);

// DEBUG expose
Object.defineProperty(window, '_App', { get: () => App });
