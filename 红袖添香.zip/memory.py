"""长期记忆模块 —— SQLite 持久化对话历史、会话管理、记忆检索与摘要。

特性：
- SQLite 本地存储，无需额外数据库服务
- 按 user_id 管理多用户会话
- 自动生成对话摘要（长对话压缩）
- 智能记忆检索：最近 N 条 + 相关历史摘要
- 支持异步操作（线程池执行同步 SQLite）
"""
import asyncio
import json
import logging
import sqlite3
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

logger = logging.getLogger("memory")

BASE_DIR = Path(__file__).parent.resolve()
DB_PATH = BASE_DIR / "chat_memory.db"

# 摘要触发阈值：单会话超过此消息数后自动生成摘要
SUMMARY_THRESHOLD = 20
# 摘要间隔：每隔多少条消息生成一次摘要
SUMMARY_INTERVAL = 10
# 检索时返回的最近消息数
RECENT_MESSAGE_COUNT = 10
# 检索时返回的最大摘要数
MAX_SUMMARIES = 3


def _get_db() -> sqlite3.Connection:
    """获取数据库连接（线程安全）。"""
    conn = sqlite3.connect(str(DB_PATH), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def _init_db():
    """初始化数据库表结构。"""
    conn = _get_db()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS sessions (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL DEFAULT 'default',
            title TEXT DEFAULT '',
            created_at REAL NOT NULL,
            updated_at REAL NOT NULL,
            is_active INTEGER NOT NULL DEFAULT 1
        );

        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            role TEXT NOT NULL,
            content TEXT NOT NULL DEFAULT '',
            tool_calls TEXT DEFAULT NULL,
            tool_results TEXT DEFAULT NULL,
            created_at REAL NOT NULL,
            FOREIGN KEY (session_id) REFERENCES sessions(id)
        );

        CREATE INDEX IF NOT EXISTS idx_messages_session
            ON messages(session_id, created_at);
        CREATE INDEX IF NOT EXISTS idx_sessions_user
            ON sessions(user_id, updated_at DESC);

        CREATE TABLE IF NOT EXISTS summaries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            summary_text TEXT NOT NULL,
            range_start INTEGER NOT NULL,
            range_end INTEGER NOT NULL,
            created_at REAL NOT NULL,
            FOREIGN KEY (session_id) REFERENCES sessions(id)
        );

        CREATE INDEX IF NOT EXISTS idx_summaries_session
            ON summaries(session_id, created_at DESC);

        -- 用户记忆：跨会话的长期记忆片段
        CREATE TABLE IF NOT EXISTS user_memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT NOT NULL,
            memory_text TEXT NOT NULL,
            source_session_id TEXT,
            importance REAL DEFAULT 0.5,
            created_at REAL NOT NULL,
            last_accessed REAL NOT NULL
        );

        CREATE INDEX IF NOT EXISTS idx_user_memories
            ON user_memories(user_id, importance DESC);
    """)
    conn.commit()
    conn.close()


# 模块加载时自动初始化
_init_db()


class ChatMemory:
    """对话记忆管理器。

    每个实例关联一个用户和一个会话，提供消息存储、检索和摘要功能。
    """

    def __init__(self, user_id: str = "default", session_id: str = None):
        self.user_id = user_id
        self.session_id = session_id
        self._message_count = 0  # 当前会话消息计数缓存

    # ==================== 会话管理 ====================

    async def get_or_create_session(self, title: str = "") -> str:
        """获取或创建当前用户的活动会话。

        Returns:
            session_id
        """
        if self.session_id:
            return self.session_id

        def _do():
            conn = _get_db()
            now = time.time()
            # 查找近期活动会话（15 分钟内）
            recent = now - 900
            row = conn.execute(
                "SELECT id FROM sessions WHERE user_id=? AND is_active=1 AND updated_at>? "
                "ORDER BY updated_at DESC LIMIT 1",
                (self.user_id, recent),
            ).fetchone()
            if row:
                self.session_id = row["id"]
                conn.execute(
                    "UPDATE sessions SET updated_at=? WHERE id=?",
                    (now, self.session_id),
                )
                conn.commit()
                conn.close()
                return self.session_id

            # 创建新会话
            import uuid
            sid = uuid.uuid4().hex[:12]
            conn.execute(
                "INSERT INTO sessions (id, user_id, title, created_at, updated_at) "
                "VALUES (?, ?, ?, ?, ?)",
                (sid, self.user_id, title or f"对话 {datetime.now():%m-%d %H:%M}", now, now),
            )
            conn.commit()
            conn.close()
            self.session_id = sid
            return sid

        return await asyncio.to_thread(_do)

    async def set_session_id(self, session_id: str):
        """手动设置会话 ID（用于恢复历史会话）。"""
        self.session_id = session_id
        # 更新会话活动时间
        def _do():
            conn = _get_db()
            conn.execute(
                "UPDATE sessions SET updated_at=?, is_active=1 WHERE id=?",
                (time.time(), session_id),
            )
            conn.commit()
            conn.close()
        await asyncio.to_thread(_do)

    async def list_sessions(self, limit: int = 20) -> list:
        """列出用户的所有会话。"""
        def _do():
            conn = _get_db()
            rows = conn.execute(
                "SELECT id, title, created_at, updated_at, is_active "
                "FROM sessions WHERE user_id=? ORDER BY updated_at DESC LIMIT ?",
                (self.user_id, limit),
            ).fetchall()
            sessions = [dict(r) for r in rows]
            for s in sessions:
                s["created_at"] = datetime.fromtimestamp(s["created_at"]).isoformat()
                s["updated_at"] = datetime.fromtimestamp(s["updated_at"]).isoformat()
            conn.close()
            return sessions
        return await asyncio.to_thread(_do)

    async def update_title(self, title: str):
        """更新当前会话标题。"""
        if not self.session_id:
            return
        def _do():
            conn = _get_db()
            conn.execute("UPDATE sessions SET title=? WHERE id=?", (title, self.session_id))
            conn.commit()
            conn.close()
        await asyncio.to_thread(_do)

    # ==================== 消息存储 ====================

    async def add_message(self, role: str, content: str,
                          tool_calls: list = None, tool_results: list = None):
        """添加一条消息到当前会话。

        Args:
            role: user / assistant / system / tool
            content: 消息内容
            tool_calls: tool_call 信息列表（assistant 消息可能携带）
            tool_results: 工具调用结果列表（tool 消息）
        """
        if not self.session_id:
            await self.get_or_create_session()

        def _do():
            conn = _get_db()
            now = time.time()
            conn.execute(
                "INSERT INTO messages (session_id, role, content, tool_calls, tool_results, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (
                    self.session_id, role, content,
                    json.dumps(tool_calls, ensure_ascii=False) if tool_calls else None,
                    json.dumps(tool_results, ensure_ascii=False) if tool_results else None,
                    now,
                ),
            )
            conn.execute(
                "UPDATE sessions SET updated_at=? WHERE id=?",
                (now, self.session_id),
            )
            conn.commit()
            conn.close()
            self._message_count += 1

        await asyncio.to_thread(_do)

        # 检查是否需要生成摘要
        if self._message_count > 0 and self._message_count % SUMMARY_INTERVAL == 0:
            await self.maybe_summarize()

    async def maybe_summarize(self):
        """检查并在需要时生成对话摘要。"""
        def _check():
            conn = _get_db()
            count = conn.execute(
                "SELECT COUNT(*) as cnt FROM messages WHERE session_id=?",
                (self.session_id,),
            ).fetchone()["cnt"]
            conn.close()
            return count

        count = await asyncio.to_thread(_check)
        if count >= SUMMARY_THRESHOLD:
            # 检查最新的摘要覆盖范围
            def _get_last_summary_range():
                conn = _get_db()
                row = conn.execute(
                    "SELECT range_end FROM summaries WHERE session_id=? ORDER BY range_end DESC LIMIT 1",
                    (self.session_id,),
                ).fetchone()
                conn.close()
                return row["range_end"] if row else 0

            last_end = await asyncio.to_thread(_get_last_summary_range)

            def _get_messages_since(start_id):
                conn = _get_db()
                rows = conn.execute(
                    "SELECT id, role, content FROM messages "
                    "WHERE session_id=? AND id > ? ORDER BY id",
                    (self.session_id, start_id),
                ).fetchall()
                conn.close()
                return [dict(r) for r in rows]

            msgs = await asyncio.to_thread(_get_messages_since, last_end)
            if len(msgs) >= SUMMARY_INTERVAL * 2:
                await self._generate_summary(msgs)

    async def _generate_summary(self, messages: list):
        """生成对话摘要并存储。使用 LLM 生成摘要。"""
        # 构建简要对话文本
        dialog_text = ""
        for m in messages[-SUMMARY_INTERVAL * 2:]:
            role_tag = "用户" if m["role"] == "user" else "AI"
            dialog_text += f"{role_tag}: {m['content'][:200]}\n"

        # 使用简单方法生成摘要（后续可接入 LLM 生成更高质量的摘要）
        # 这里先做关键词提取式摘要
        lines = dialog_text.strip().split("\n")
        summary_parts = []
        for line in lines:
            if len(line) > 10:
                summary_parts.append(line[:100])
        summary = " | ".join(summary_parts[:8]) if summary_parts else "对话摘要"

        # 截断过长摘要
        if len(summary) > 500:
            summary = summary[:497] + "..."

        def _save():
            if not messages:
                return
            conn = _get_db()
            conn.execute(
                "INSERT INTO summaries (session_id, summary_text, range_start, range_end, created_at) "
                "VALUES (?, ?, ?, ?, ?)",
                (
                    self.session_id,
                    summary,
                    messages[0]["id"],
                    messages[-1]["id"],
                    time.time(),
                ),
            )
            conn.commit()
            conn.close()
            logger.info(f"会话 {self.session_id} 生成摘要: {summary[:100]}...")

        await asyncio.to_thread(_save)

    # ==================== 记忆检索 ====================

    async def get_context_messages(self, recent_n: int = None) -> list:
        """获取最近的消息列表，结合摘要提供上下文。

        Returns:
            OpenAI 消息格式的列表: [{"role": ..., "content": ...}, ...]
        """
        if not self.session_id:
            return []

        recent_n = recent_n or RECENT_MESSAGE_COUNT

        def _do():
            conn = _get_db()
            # 获取最新摘要
            summary_rows = conn.execute(
                "SELECT summary_text FROM summaries WHERE session_id=? "
                "ORDER BY created_at DESC LIMIT ?",
                (self.session_id, MAX_SUMMARIES),
            ).fetchall()

            # 获取最近消息
            msg_rows = conn.execute(
                "SELECT role, content, tool_calls, tool_results FROM messages "
                "WHERE session_id=? ORDER BY created_at DESC LIMIT ?",
                (self.session_id, recent_n),
            ).fetchall()[::-1]  # 反转为正序

            conn.close()

            messages = []
            if summary_rows:
                summary_text = "以下是之前的对话摘要：\n" + "\n".join(
                    [s["summary_text"] for s in summary_rows]
                )
                messages.append({
                    "role": "system",
                    "content": summary_text,
                })

            for row in msg_rows:
                msg = {"role": row["role"], "content": row["content"]}
                if row["tool_calls"]:
                    try:
                        msg["tool_calls"] = json.loads(row["tool_calls"])
                    except (json.JSONDecodeError, TypeError):
                        pass
                if row["tool_results"]:
                    try:
                        msg["tool_results"] = json.loads(row["tool_results"])
                    except (json.JSONDecodeError, TypeError):
                        pass
                messages.append(msg)

            return messages

        return await asyncio.to_thread(_do)

    async def get_history_for_llm(self, max_messages: int = 10) -> list:
        """获取用于 LLM 上下文的历史消息（简化格式）。

        Returns:
            [{"user": "...", "ai": "..."}, ...]  兼容现有的 history 格式
        """
        if not self.session_id:
            return []

        def _do():
            conn = _get_db()
            rows = conn.execute(
                "SELECT role, content FROM messages WHERE session_id=? "
                "ORDER BY created_at DESC LIMIT ?",
                (self.session_id, max_messages * 2),
            ).fetchall()[::-1]
            conn.close()

            history = []
            pending_user = None
            for row in rows:
                if row["role"] == "user":
                    pending_user = row["content"]
                elif row["role"] == "assistant" and pending_user is not None:
                    history.append({"user": pending_user, "ai": row["content"]})
                    pending_user = None
            return history[-max_messages:]  # 只保留最近 N 轮

        return await asyncio.to_thread(_do)

    # ==================== 用户长期记忆 ====================

    async def save_user_memory(self, memory_text: str, importance: float = 0.5):
        """保存用户相关的长期记忆片段。

        Args:
            memory_text: 记忆内容
            importance: 重要性评分 (0.0-1.0)
        """
        def _do():
            conn = _get_db()
            now = time.time()
            conn.execute(
                "INSERT INTO user_memories (user_id, memory_text, source_session_id, "
                "importance, created_at, last_accessed) VALUES (?, ?, ?, ?, ?, ?)",
                (self.user_id, memory_text, self.session_id, importance, now, now),
            )
            conn.commit()
            conn.close()

        await asyncio.to_thread(_do)

    async def get_user_memories(self, limit: int = 5) -> list:
        """获取用户最重要的长期记忆片段。"""
        def _do():
            conn = _get_db()
            rows = conn.execute(
                "SELECT memory_text, importance FROM user_memories "
                "WHERE user_id=? ORDER BY importance DESC, last_accessed DESC LIMIT ?",
                (self.user_id, limit),
            ).fetchall()
            # 更新访问时间
            ids = [r["id"] for r in rows] if rows and "id" in (rows[0].keys() if rows else []) else []
            conn.close()
            return [dict(r) for r in rows]

        return await asyncio.to_thread(_do)

    async def extract_and_save_memories(self, user_message: str, ai_response: str):
        """从对话中提取用户偏好/信息并保存为长期记忆。

        简单规则提取，后续可升级为 LLM 驱动的智能提取。
        """
        # 关键词匹配提取用户信息
        patterns = {
            "我叫": "用户自称",
            "我是": "用户身份",
            "我喜欢": "用户偏好-喜欢",
            "我不喜欢": "用户偏好-不喜欢",
            "我的": "用户信息",
            "我住": "用户住址",
            "我工作": "用户工作",
            "我从事": "用户职业",
        }

        for keyword, category in patterns.items():
            if keyword in user_message:
                # 提取关键词后的内容
                idx = user_message.find(keyword)
                snippet = user_message[idx:idx + 80].strip()
                memory = f"[{category}] {snippet}"
                await self.save_user_memory(memory, importance=0.7)
                logger.info(f"提取用户记忆: {memory}")

    # ==================== 清理 ====================

    async def close_session(self):
        """关闭当前会话（标记为非活跃）。"""
        if not self.session_id:
            return
        def _do():
            conn = _get_db()
            conn.execute(
                "UPDATE sessions SET is_active=0, updated_at=? WHERE id=?",
                (time.time(), self.session_id),
            )
            conn.commit()
            conn.close()
        await asyncio.to_thread(_do)
        self.session_id = None
        self._message_count = 0

    async def delete_session(self, session_id: str = None):
        """删除指定会话及其所有消息。"""
        sid = session_id or self.session_id
        if not sid:
            return
        def _do():
            conn = _get_db()
            conn.execute("DELETE FROM summaries WHERE session_id=?", (sid,))
            conn.execute("DELETE FROM messages WHERE session_id=?", (sid,))
            conn.execute("DELETE FROM sessions WHERE id=?", (sid,))
            conn.commit()
            conn.close()
        await asyncio.to_thread(_do)
        if sid == self.session_id:
            self.session_id = None
            self._message_count = 0
